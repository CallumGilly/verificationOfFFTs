{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wno-overlapping-patterns #-}

module MAlonzo.Code.Real where

import MAlonzo.RTE (coe, erased, AgdaAny, addInt, subInt, mulInt,
                    quotInt, remInt, geqInt, ltInt, eqInt, add64, sub64, mul64, quot64,
                    rem64, lt64, eq64, word64FromNat, word64ToNat)
import qualified MAlonzo.RTE
import qualified Data.Text
import qualified MAlonzo.Code.Agda.Builtin.Equality
import qualified MAlonzo.Code.Algebra.Structures

-- Real.Real
d_Real_2 = ()
data T_Real_2
  = C_Real'46'constructor_37887 (Integer -> AgdaAny) AgdaAny
                                (AgdaAny -> AgdaAny -> AgdaAny) (AgdaAny -> AgdaAny -> AgdaAny)
                                (AgdaAny -> AgdaAny -> AgdaAny) (AgdaAny -> AgdaAny -> AgdaAny)
                                (AgdaAny -> AgdaAny) (AgdaAny -> AgdaAny) (AgdaAny -> AgdaAny)
                                MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818
-- Real._.IsCommutativeRing
d_IsCommutativeRing_46 a0 a1 a2 a3 a4 a5 a6 a7 a8 a9 a10 a11 a12
                       a13 a14
  = ()
-- Real._.IsCommutativeRing.*-comm
d_'42''45'comm_460 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  AgdaAny ->
  AgdaAny -> MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'comm_460 = erased
-- Real._.IsCommutativeRing.isRing
d_isRing_548 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672
d_isRing_548 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0)
-- Real.Real.ℝ
d_ℝ_2698 :: T_Real_2 -> ()
d_ℝ_2698 = erased
-- Real.Real._ᵣ
d__'7523'_2700 :: T_Real_2 -> Integer -> AgdaAny
d__'7523'_2700 v0
  = case coe v0 of
      C_Real'46'constructor_37887 v2 v3 v4 v5 v6 v7 v8 v9 v10 v11
        -> coe v2
      _ -> MAlonzo.RTE.mazUnreachableError
-- Real.Real.π
d_π_2702 :: T_Real_2 -> AgdaAny
d_π_2702 v0
  = case coe v0 of
      C_Real'46'constructor_37887 v2 v3 v4 v5 v6 v7 v8 v9 v10 v11
        -> coe v3
      _ -> MAlonzo.RTE.mazUnreachableError
-- Real.Real._+_
d__'43'__2704 :: T_Real_2 -> AgdaAny -> AgdaAny -> AgdaAny
d__'43'__2704 v0
  = case coe v0 of
      C_Real'46'constructor_37887 v2 v3 v4 v5 v6 v7 v8 v9 v10 v11
        -> coe v4
      _ -> MAlonzo.RTE.mazUnreachableError
-- Real.Real._-_
d__'45'__2706 :: T_Real_2 -> AgdaAny -> AgdaAny -> AgdaAny
d__'45'__2706 v0
  = case coe v0 of
      C_Real'46'constructor_37887 v2 v3 v4 v5 v6 v7 v8 v9 v10 v11
        -> coe v5
      _ -> MAlonzo.RTE.mazUnreachableError
-- Real.Real._*_
d__'42'__2708 :: T_Real_2 -> AgdaAny -> AgdaAny -> AgdaAny
d__'42'__2708 v0
  = case coe v0 of
      C_Real'46'constructor_37887 v2 v3 v4 v5 v6 v7 v8 v9 v10 v11
        -> coe v6
      _ -> MAlonzo.RTE.mazUnreachableError
-- Real.Real._/_
d__'47'__2710 :: T_Real_2 -> AgdaAny -> AgdaAny -> AgdaAny
d__'47'__2710 v0
  = case coe v0 of
      C_Real'46'constructor_37887 v2 v3 v4 v5 v6 v7 v8 v9 v10 v11
        -> coe v7
      _ -> MAlonzo.RTE.mazUnreachableError
-- Real.Real.-_
d_'45'__2712 :: T_Real_2 -> AgdaAny -> AgdaAny
d_'45'__2712 v0
  = case coe v0 of
      C_Real'46'constructor_37887 v2 v3 v4 v5 v6 v7 v8 v9 v10 v11
        -> coe v8
      _ -> MAlonzo.RTE.mazUnreachableError
-- Real.Real.cos
d_cos_2714 :: T_Real_2 -> AgdaAny -> AgdaAny
d_cos_2714 v0
  = case coe v0 of
      C_Real'46'constructor_37887 v2 v3 v4 v5 v6 v7 v8 v9 v10 v11
        -> coe v9
      _ -> MAlonzo.RTE.mazUnreachableError
-- Real.Real.sin
d_sin_2716 :: T_Real_2 -> AgdaAny -> AgdaAny
d_sin_2716 v0
  = case coe v0 of
      C_Real'46'constructor_37887 v2 v3 v4 v5 v6 v7 v8 v9 v10 v11
        -> coe v10
      _ -> MAlonzo.RTE.mazUnreachableError
-- Real.Real.0ℝ
d_0ℝ_2718 :: T_Real_2 -> AgdaAny
d_0ℝ_2718 v0 = coe d__'7523'_2700 v0 (0 :: Integer)
-- Real.Real.-1ℝ
d_'45'1ℝ_2720 :: T_Real_2 -> AgdaAny
d_'45'1ℝ_2720 v0
  = coe d_'45'__2712 v0 (coe d__'7523'_2700 v0 (1 :: Integer))
-- Real.Real.1ℝ
d_1ℝ_2722 :: T_Real_2 -> AgdaAny
d_1ℝ_2722 v0 = coe d__'7523'_2700 v0 (1 :: Integer)
-- Real.Real.+-*-isCommutativeRing
d_'43''45''42''45'isCommutativeRing_5390 ::
  T_Real_2 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818
d_'43''45''42''45'isCommutativeRing_5390 v0
  = case coe v0 of
      C_Real'46'constructor_37887 v2 v3 v4 v5 v6 v7 v8 v9 v10 v11
        -> coe v11
      _ -> MAlonzo.RTE.mazUnreachableError
