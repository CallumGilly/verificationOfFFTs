{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wno-overlapping-patterns #-}

module MAlonzo.Code.Matrix.Reshape where

import MAlonzo.RTE (coe, erased, AgdaAny, addInt, subInt, mulInt,
                    quotInt, remInt, geqInt, ltInt, eqInt, add64, sub64, mul64, quot64,
                    rem64, lt64, eq64, word64FromNat, word64ToNat)
import qualified MAlonzo.RTE
import qualified Data.Text
import qualified MAlonzo.Code.Agda.Builtin.Equality
import qualified MAlonzo.Code.Agda.Builtin.Sigma
import qualified MAlonzo.Code.Data.Fin.Base
import qualified MAlonzo.Code.Matrix

-- Matrix.Reshape.Reshape
d_Reshape_24 a0 a1 = ()
data T_Reshape_24
  = C_eq_26 |
    C__'8729'__28 MAlonzo.Code.Matrix.T_Shape_12 T_Reshape_24
                  T_Reshape_24 |
    C__'8853'__30 T_Reshape_24 T_Reshape_24 | C_split_32 | C_flat_34 |
    C_swap_36
-- Matrix.Reshape._⟨_⟩
d__'10216'_'10217'_38 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  T_Reshape_24 -> MAlonzo.Code.Matrix.T_Position_22
d__'10216'_'10217'_38 v0 v1 v2 v3
  = case coe v3 of
      C_eq_26 -> coe v2
      C__'8729'__28 v4 v7 v8
        -> coe
             d__'10216'_'10217'_38 (coe v4) (coe v1)
             (coe d__'10216'_'10217'_38 (coe v0) (coe v4) (coe v2) (coe v7))
             (coe v8)
      C__'8853'__30 v8 v9
        -> case coe v0 of
             MAlonzo.Code.Matrix.C__'8855'__16 v10 v11
               -> case coe v1 of
                    MAlonzo.Code.Matrix.C__'8855'__16 v12 v13
                      -> case coe v2 of
                           MAlonzo.Code.Matrix.C__'8855'__26 v16 v17
                             -> coe
                                  MAlonzo.Code.Matrix.C__'8855'__26
                                  (d__'10216'_'10217'_38 (coe v10) (coe v12) (coe v16) (coe v8))
                                  (d__'10216'_'10217'_38 (coe v11) (coe v13) (coe v17) (coe v9))
                           _ -> MAlonzo.RTE.mazUnreachableError
                    _ -> MAlonzo.RTE.mazUnreachableError
             _ -> MAlonzo.RTE.mazUnreachableError
      C_split_32
        -> case coe v0 of
             MAlonzo.Code.Matrix.C__'8855'__16 v6 v7
               -> case coe v7 of
                    MAlonzo.Code.Matrix.C_ι_14 v8
                      -> case coe v2 of
                           MAlonzo.Code.Matrix.C__'8855'__26 v11 v12
                             -> case coe v11 of
                                  MAlonzo.Code.Matrix.C_ι_24 v14
                                    -> case coe v12 of
                                         MAlonzo.Code.Matrix.C_ι_24 v16
                                           -> coe
                                                MAlonzo.Code.Matrix.C_ι_24
                                                (coe
                                                   MAlonzo.Code.Data.Fin.Base.du_combine_208
                                                   (coe v8) (coe v14) (coe v16))
                                         _ -> MAlonzo.RTE.mazUnreachableError
                                  _ -> MAlonzo.RTE.mazUnreachableError
                           _ -> MAlonzo.RTE.mazUnreachableError
                    _ -> MAlonzo.RTE.mazUnreachableError
             _ -> MAlonzo.RTE.mazUnreachableError
      C_flat_34
        -> case coe v1 of
             MAlonzo.Code.Matrix.C__'8855'__16 v6 v7
               -> case coe v7 of
                    MAlonzo.Code.Matrix.C_ι_14 v8
                      -> case coe v2 of
                           MAlonzo.Code.Matrix.C_ι_24 v10
                             -> coe
                                  MAlonzo.Code.Matrix.C__'8855'__26
                                  (coe
                                     MAlonzo.Code.Matrix.C_ι_24
                                     (MAlonzo.Code.Agda.Builtin.Sigma.d_fst_28
                                        (coe
                                           MAlonzo.Code.Data.Fin.Base.du_remQuot_190 (coe v8)
                                           (coe v10))))
                                  (coe
                                     MAlonzo.Code.Matrix.C_ι_24
                                     (MAlonzo.Code.Agda.Builtin.Sigma.d_snd_30
                                        (coe
                                           MAlonzo.Code.Data.Fin.Base.du_remQuot_190 (coe v8)
                                           (coe v10))))
                           _ -> MAlonzo.RTE.mazUnreachableError
                    _ -> MAlonzo.RTE.mazUnreachableError
             _ -> MAlonzo.RTE.mazUnreachableError
      C_swap_36
        -> case coe v2 of
             MAlonzo.Code.Matrix.C__'8855'__26 v8 v9
               -> coe MAlonzo.Code.Matrix.C__'8855'__26 v9 v8
             _ -> MAlonzo.RTE.mazUnreachableError
      _ -> MAlonzo.RTE.mazUnreachableError
-- Matrix.Reshape.reshape
d_reshape_70 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Matrix.T_Shape_12 ->
  () ->
  T_Reshape_24 ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny
d_reshape_70 v0 v1 ~v2 v3 v4 v5 = du_reshape_70 v0 v1 v3 v4 v5
du_reshape_70 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Matrix.T_Shape_12 ->
  T_Reshape_24 ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny
du_reshape_70 v0 v1 v2 v3 v4
  = coe
      v3 (d__'10216'_'10217'_38 (coe v1) (coe v0) (coe v4) (coe v2))
-- Matrix.Reshape.rev
d_rev_78 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Matrix.T_Shape_12 -> T_Reshape_24 -> T_Reshape_24
d_rev_78 v0 v1 v2
  = case coe v2 of
      C_eq_26 -> coe C_eq_26
      C__'8729'__28 v3 v6 v7
        -> coe
             C__'8729'__28 v3 (d_rev_78 (coe v0) (coe v3) (coe v7))
             (d_rev_78 (coe v3) (coe v1) (coe v6))
      C__'8853'__30 v7 v8
        -> case coe v0 of
             MAlonzo.Code.Matrix.C__'8855'__16 v9 v10
               -> case coe v1 of
                    MAlonzo.Code.Matrix.C__'8855'__16 v11 v12
                      -> coe
                           C__'8853'__30 (d_rev_78 (coe v9) (coe v11) (coe v7))
                           (d_rev_78 (coe v10) (coe v12) (coe v8))
                    _ -> MAlonzo.RTE.mazUnreachableError
             _ -> MAlonzo.RTE.mazUnreachableError
      C_split_32 -> coe C_flat_34
      C_flat_34 -> coe C_split_32
      C_swap_36 -> coe C_swap_36
      _ -> MAlonzo.RTE.mazUnreachableError
-- Matrix.Reshape.rev-eq
d_rev'45'eq_92 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Matrix.T_Shape_12 ->
  T_Reshape_24 ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_rev'45'eq_92 = erased
-- Matrix.Reshape.rev-rev
d_rev'45'rev_168 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Matrix.T_Shape_12 ->
  T_Reshape_24 ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_rev'45'rev_168 = erased
-- Matrix.Reshape.transpose
d_transpose_208 ::
  MAlonzo.Code.Matrix.T_Shape_12 -> MAlonzo.Code.Matrix.T_Shape_12
d_transpose_208 v0
  = case coe v0 of
      MAlonzo.Code.Matrix.C_ι_14 v1 -> coe v0
      MAlonzo.Code.Matrix.C__'8855'__16 v1 v2
        -> coe MAlonzo.Code.Matrix.C__'8855'__16 (coe v2) (coe v1)
      _ -> MAlonzo.RTE.mazUnreachableError
-- Matrix.Reshape.transposeᵣ
d_transpose'7523'_216 ::
  MAlonzo.Code.Matrix.T_Shape_12 -> T_Reshape_24
d_transpose'7523'_216 v0
  = case coe v0 of
      MAlonzo.Code.Matrix.C_ι_14 v1 -> coe C_eq_26
      MAlonzo.Code.Matrix.C__'8855'__16 v1 v2 -> coe C_swap_36
      _ -> MAlonzo.RTE.mazUnreachableError
-- Matrix.Reshape.transp-inv
d_transp'45'inv_224 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_transp'45'inv_224 = erased
-- Matrix.Reshape.recursive-transpose
d_recursive'45'transpose_232 ::
  MAlonzo.Code.Matrix.T_Shape_12 -> MAlonzo.Code.Matrix.T_Shape_12
d_recursive'45'transpose_232 v0
  = case coe v0 of
      MAlonzo.Code.Matrix.C_ι_14 v1 -> coe v0
      MAlonzo.Code.Matrix.C__'8855'__16 v1 v2
        -> coe
             MAlonzo.Code.Matrix.C__'8855'__16
             (coe d_recursive'45'transpose_232 (coe v2))
             (coe d_recursive'45'transpose_232 (coe v1))
      _ -> MAlonzo.RTE.mazUnreachableError
-- Matrix.Reshape.recursive-transposeᵣ
d_recursive'45'transpose'7523'_240 ::
  MAlonzo.Code.Matrix.T_Shape_12 -> T_Reshape_24
d_recursive'45'transpose'7523'_240 v0
  = case coe v0 of
      MAlonzo.Code.Matrix.C_ι_14 v1 -> coe C_eq_26
      MAlonzo.Code.Matrix.C__'8855'__16 v1 v2
        -> coe
             C__'8729'__28
             (coe
                MAlonzo.Code.Matrix.C__'8855'__16
                (coe d_recursive'45'transpose_232 (coe v1))
                (coe d_recursive'45'transpose_232 (coe v2)))
             (coe C_swap_36)
             (coe
                C__'8853'__30 (d_recursive'45'transpose'7523'_240 (coe v1))
                (d_recursive'45'transpose'7523'_240 (coe v2)))
      _ -> MAlonzo.RTE.mazUnreachableError
-- Matrix.Reshape.recursive-transpose-inv
d_recursive'45'transpose'45'inv_248 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_recursive'45'transpose'45'inv_248 = erased
-- Matrix.Reshape.|s|≡|sᵗ|
d_'124's'124''8801''124's'7511''124'_264 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'124's'124''8801''124's'7511''124'_264 = erased
-- Matrix.Reshape.♭
d_'9837'_284 :: MAlonzo.Code.Matrix.T_Shape_12 -> T_Reshape_24
d_'9837'_284 v0
  = case coe v0 of
      MAlonzo.Code.Matrix.C_ι_14 v1 -> coe C_eq_26
      MAlonzo.Code.Matrix.C__'8855'__16 v1 v2
        -> coe
             C__'8729'__28
             (coe
                MAlonzo.Code.Matrix.C__'8855'__16
                (coe
                   MAlonzo.Code.Matrix.C_ι_14
                   (coe MAlonzo.Code.Matrix.d_length_48 (coe v1)))
                (coe
                   MAlonzo.Code.Matrix.C_ι_14
                   (coe MAlonzo.Code.Matrix.d_length_48 (coe v2))))
             (coe C_flat_34)
             (coe C__'8853'__30 (d_'9837'_284 (coe v1)) (d_'9837'_284 (coe v2)))
      _ -> MAlonzo.RTE.mazUnreachableError
-- Matrix.Reshape.♯
d_'9839'_292 :: MAlonzo.Code.Matrix.T_Shape_12 -> T_Reshape_24
d_'9839'_292 v0
  = coe
      d_rev_78 (coe v0)
      (coe
         MAlonzo.Code.Matrix.C_ι_14
         (coe MAlonzo.Code.Matrix.d_length_48 (coe v0)))
      (coe d_'9837'_284 (coe v0))
-- Matrix.Reshape.reindex
d_reindex_294 ::
  Integer ->
  Integer ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 -> T_Reshape_24
d_reindex_294 ~v0 ~v1 ~v2 = du_reindex_294
du_reindex_294 :: T_Reshape_24
du_reindex_294 = coe C_eq_26
-- Matrix.Reshape.reindex-cast
d_reindex'45'cast_308 ::
  Integer ->
  Integer ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Data.Fin.Base.T_Fin_10 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reindex'45'cast_308 = erased
-- Matrix.Reshape.ext
d_ext_324 ::
  Integer ->
  () ->
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_ext_324 = erased
-- Matrix.Reshape.reindex-reindex
d_reindex'45'reindex_334 ::
  Integer ->
  Integer ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reindex'45'reindex_334 = erased
-- Matrix.Reshape.flatten-reindex
d_flatten'45'reindex_338 ::
  MAlonzo.Code.Matrix.T_Shape_12 -> T_Reshape_24
d_flatten'45'reindex_338 v0
  = coe
      C__'8729'__28
      (coe
         MAlonzo.Code.Matrix.C_ι_14
         (coe MAlonzo.Code.Matrix.d_length_48 (coe v0)))
      (coe du_reindex_294) (d_'9837'_284 (coe v0))
