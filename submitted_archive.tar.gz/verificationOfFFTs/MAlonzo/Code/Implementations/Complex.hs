{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wno-overlapping-patterns #-}

module MAlonzo.Code.Implementations.Complex where

import MAlonzo.RTE (coe, erased, AgdaAny, addInt, subInt, mulInt,
                    quotInt, remInt, geqInt, ltInt, eqInt, add64, sub64, mul64, quot64,
                    rem64, lt64, eq64, word64FromNat, word64ToNat)
import qualified MAlonzo.RTE
import qualified Data.Text
import qualified MAlonzo.Code.Complex
import qualified MAlonzo.Code.Data.Nat.Base
import qualified MAlonzo.Code.Real

-- Implementations.Complex.Base.ℂ₁
d_ℂ'8321'_30 a0 = ()
data T_ℂ'8321'_30 = C__'43'_i_40 AgdaAny AgdaAny
-- Implementations.Complex.Base.ℂ₁.real-component
d_real'45'component_36 :: T_ℂ'8321'_30 -> AgdaAny
d_real'45'component_36 v0
  = case coe v0 of
      C__'43'_i_40 v1 v2 -> coe v1
      _ -> MAlonzo.RTE.mazUnreachableError
-- Implementations.Complex.Base.ℂ₁.imaginary-component
d_imaginary'45'component_38 :: T_ℂ'8321'_30 -> AgdaAny
d_imaginary'45'component_38 v0
  = case coe v0 of
      C__'43'_i_40 v1 v2 -> coe v2
      _ -> MAlonzo.RTE.mazUnreachableError
-- Implementations.Complex.Base.0ℂ
d_0ℂ_42 :: MAlonzo.Code.Real.T_Real_2 -> T_ℂ'8321'_30
d_0ℂ_42 v0
  = coe
      C__'43'_i_40
      (coe MAlonzo.Code.Real.d__'7523'_2700 v0 (0 :: Integer))
      (coe MAlonzo.Code.Real.d__'7523'_2700 v0 (0 :: Integer))
-- Implementations.Complex.Base.-1ℂ
d_'45'1ℂ_44 :: MAlonzo.Code.Real.T_Real_2 -> T_ℂ'8321'_30
d_'45'1ℂ_44 v0
  = coe
      C__'43'_i_40
      (coe
         MAlonzo.Code.Real.d_'45'__2712 v0
         (coe MAlonzo.Code.Real.d__'7523'_2700 v0 (1 :: Integer)))
      (coe MAlonzo.Code.Real.d__'7523'_2700 v0 (0 :: Integer))
-- Implementations.Complex.Base.1ℂ
d_1ℂ_46 :: MAlonzo.Code.Real.T_Real_2 -> T_ℂ'8321'_30
d_1ℂ_46 v0
  = coe
      C__'43'_i_40
      (coe MAlonzo.Code.Real.d__'7523'_2700 v0 (1 :: Integer))
      (coe MAlonzo.Code.Real.d__'7523'_2700 v0 (0 :: Integer))
-- Implementations.Complex.Base._+_
d__'43'__48 ::
  MAlonzo.Code.Real.T_Real_2 ->
  T_ℂ'8321'_30 -> T_ℂ'8321'_30 -> T_ℂ'8321'_30
d__'43'__48 v0 v1 v2
  = case coe v1 of
      C__'43'_i_40 v3 v4
        -> case coe v2 of
             C__'43'_i_40 v5 v6
               -> coe
                    C__'43'_i_40 (coe MAlonzo.Code.Real.d__'43'__2704 v0 v3 v5)
                    (coe MAlonzo.Code.Real.d__'43'__2704 v0 v4 v6)
             _ -> MAlonzo.RTE.mazUnreachableError
      _ -> MAlonzo.RTE.mazUnreachableError
-- Implementations.Complex.Base._-_
d__'45'__58 ::
  MAlonzo.Code.Real.T_Real_2 ->
  T_ℂ'8321'_30 -> T_ℂ'8321'_30 -> T_ℂ'8321'_30
d__'45'__58 v0 v1 v2
  = case coe v1 of
      C__'43'_i_40 v3 v4
        -> case coe v2 of
             C__'43'_i_40 v5 v6
               -> coe
                    C__'43'_i_40 (coe MAlonzo.Code.Real.d__'45'__2706 v0 v3 v5)
                    (coe MAlonzo.Code.Real.d__'45'__2706 v0 v4 v6)
             _ -> MAlonzo.RTE.mazUnreachableError
      _ -> MAlonzo.RTE.mazUnreachableError
-- Implementations.Complex.Base.-_
d_'45'__68 ::
  MAlonzo.Code.Real.T_Real_2 -> T_ℂ'8321'_30 -> T_ℂ'8321'_30
d_'45'__68 v0 v1
  = case coe v1 of
      C__'43'_i_40 v2 v3
        -> coe
             C__'43'_i_40 (coe MAlonzo.Code.Real.d_'45'__2712 v0 v2)
             (coe MAlonzo.Code.Real.d_'45'__2712 v0 v3)
      _ -> MAlonzo.RTE.mazUnreachableError
-- Implementations.Complex.Base._*_
d__'42'__74 ::
  MAlonzo.Code.Real.T_Real_2 ->
  T_ℂ'8321'_30 -> T_ℂ'8321'_30 -> T_ℂ'8321'_30
d__'42'__74 v0 v1 v2
  = case coe v1 of
      C__'43'_i_40 v3 v4
        -> case coe v2 of
             C__'43'_i_40 v5 v6
               -> coe
                    C__'43'_i_40
                    (coe
                       MAlonzo.Code.Real.d__'45'__2706 v0
                       (coe MAlonzo.Code.Real.d__'42'__2708 v0 v3 v5)
                       (coe MAlonzo.Code.Real.d__'42'__2708 v0 v4 v6))
                    (coe
                       MAlonzo.Code.Real.d__'43'__2704 v0
                       (coe MAlonzo.Code.Real.d__'42'__2708 v0 v3 v6)
                       (coe MAlonzo.Code.Real.d__'42'__2708 v0 v4 v5))
             _ -> MAlonzo.RTE.mazUnreachableError
      _ -> MAlonzo.RTE.mazUnreachableError
-- Implementations.Complex.Base.fromℝ
d_fromℝ_84 :: MAlonzo.Code.Real.T_Real_2 -> AgdaAny -> T_ℂ'8321'_30
d_fromℝ_84 v0 v1
  = coe
      C__'43'_i_40 (coe v1)
      (coe MAlonzo.Code.Real.d__'7523'_2700 v0 (0 :: Integer))
-- Implementations.Complex.Base.ℂfromℕ
d_ℂfromℕ_88 ::
  MAlonzo.Code.Real.T_Real_2 -> Integer -> T_ℂ'8321'_30
d_ℂfromℕ_88 v0 v1
  = coe
      d_fromℝ_84 (coe v0) (coe MAlonzo.Code.Real.d__'7523'_2700 v0 v1)
-- Implementations.Complex.Base.e^i_
d_e'94'i__90 ::
  MAlonzo.Code.Real.T_Real_2 -> AgdaAny -> T_ℂ'8321'_30
d_e'94'i__90 v0 v1
  = coe
      C__'43'_i_40 (coe MAlonzo.Code.Real.d_cos_2714 v0 v1)
      (coe MAlonzo.Code.Real.d_sin_2716 v0 v1)
-- Implementations.Complex.Base.ℂ-conjugate
d_ℂ'45'conjugate_94 ::
  MAlonzo.Code.Real.T_Real_2 -> T_ℂ'8321'_30 -> T_ℂ'8321'_30
d_ℂ'45'conjugate_94 v0 v1
  = case coe v1 of
      C__'43'_i_40 v2 v3
        -> coe
             C__'43'_i_40 (coe v2) (coe MAlonzo.Code.Real.d_'45'__2712 v0 v3)
      _ -> MAlonzo.RTE.mazUnreachableError
-- Implementations.Complex.Base.-ω
d_'45'ω_106 ::
  MAlonzo.Code.Real.T_Real_2 ->
  Integer ->
  MAlonzo.Code.Data.Nat.Base.T_NonZero_112 -> Integer -> T_ℂ'8321'_30
d_'45'ω_106 v0 v1 ~v2 v3 = du_'45'ω_106 v0 v1 v3
du_'45'ω_106 ::
  MAlonzo.Code.Real.T_Real_2 -> Integer -> Integer -> T_ℂ'8321'_30
du_'45'ω_106 v0 v1 v2
  = coe
      d_e'94'i__90 (coe v0)
      (coe
         MAlonzo.Code.Real.d__'47'__2710 v0
         (coe
            MAlonzo.Code.Real.d__'42'__2708 v0
            (coe
               MAlonzo.Code.Real.d__'42'__2708 v0
               (coe
                  MAlonzo.Code.Real.d_'45'__2712 v0
                  (coe MAlonzo.Code.Real.d__'7523'_2700 v0 (2 :: Integer)))
               (MAlonzo.Code.Real.d_π_2702 (coe v0)))
            (coe MAlonzo.Code.Real.d__'7523'_2700 v0 v2))
         (coe MAlonzo.Code.Real.d__'7523'_2700 v0 v1))
-- Implementations.Complex.Base.isCommutativeRing
d_isCommutativeRing_112
  = error
      "MAlonzo Runtime Error: postulate evaluated: Implementations.Complex.Base.isCommutativeRing"
-- Implementations.Complex.Base.ω-N-0
d_ω'45'N'45'0_118
  = error
      "MAlonzo Runtime Error: postulate evaluated: Implementations.Complex.Base.\969-N-0"
-- Implementations.Complex.Base.ω-N-mN
d_ω'45'N'45'mN_126
  = error
      "MAlonzo Runtime Error: postulate evaluated: Implementations.Complex.Base.\969-N-mN"
-- Implementations.Complex.Base.ω-r₁x-r₁y
d_ω'45'r'8321'x'45'r'8321'y_138
  = error
      "MAlonzo Runtime Error: postulate evaluated: Implementations.Complex.Base.\969-r\8321x-r\8321y"
-- Implementations.Complex.Base.ω-N-k₀+k₁
d_ω'45'N'45'k'8320''43'k'8321'_148
  = error
      "MAlonzo Runtime Error: postulate evaluated: Implementations.Complex.Base.\969-N-k\8320+k\8321"
-- Implementations.Complex.Base.complexImplementation
d_complexImplementation_150 ::
  MAlonzo.Code.Real.T_Real_2 -> MAlonzo.Code.Complex.T_Cplx_14
d_complexImplementation_150 v0
  = coe
      MAlonzo.Code.Complex.C_Cplx'46'constructor_40271
      (d__'43'__48 (coe v0)) (d__'45'__58 (coe v0)) (d_'45'__68 (coe v0))
      (d__'42'__74 (coe v0)) (d_fromℝ_84 (coe v0))
      (d_e'94'i__90 (coe v0)) (d_ℂ'45'conjugate_94 (coe v0))
      (\ v1 v2 v3 -> coe du_'45'ω_106 (coe v0) v1 v3)
      (coe d_isCommutativeRing_112 v0)
