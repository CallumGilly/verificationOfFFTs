{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wno-overlapping-patterns #-}

module MAlonzo.Code.Matrix where

import MAlonzo.RTE (coe, erased, AgdaAny, addInt, subInt, mulInt,
                    quotInt, remInt, geqInt, ltInt, eqInt, add64, sub64, mul64, quot64,
                    rem64, lt64, eq64, word64FromNat, word64ToNat)
import qualified MAlonzo.RTE
import qualified Data.Text
import qualified MAlonzo.Code.Agda.Builtin.Sigma
import qualified MAlonzo.Code.Data.Fin.Base
import qualified MAlonzo.Code.Data.Sum.Base

-- Matrix.Shape
d_Shape_12 = ()
data T_Shape_12
  = C_ι_14 Integer | C__'8855'__16 T_Shape_12 T_Shape_12
-- Matrix.Position
d_Position_22 a0 = ()
data T_Position_22
  = C_ι_24 MAlonzo.Code.Data.Fin.Base.T_Fin_10 |
    C__'8855'__26 T_Position_22 T_Position_22
-- Matrix.Ar
d_Ar_28 :: T_Shape_12 -> () -> ()
d_Ar_28 = erased
-- Matrix.nil
d_nil_34 :: () -> T_Position_22 -> AgdaAny
d_nil_34 ~v0 ~v1 = du_nil_34
du_nil_34 :: AgdaAny
du_nil_34 = MAlonzo.RTE.mazUnreachableError
-- Matrix.ι-cons
d_ι'45'cons_36 ::
  () ->
  Integer ->
  AgdaAny -> (T_Position_22 -> AgdaAny) -> T_Position_22 -> AgdaAny
d_ι'45'cons_36 ~v0 ~v1 v2 v3 v4 = du_ι'45'cons_36 v2 v3 v4
du_ι'45'cons_36 ::
  AgdaAny -> (T_Position_22 -> AgdaAny) -> T_Position_22 -> AgdaAny
du_ι'45'cons_36 v0 v1 v2
  = case coe v2 of
      C_ι_24 v4
        -> case coe v4 of
             MAlonzo.Code.Data.Fin.Base.C_zero_12 -> coe v0
             MAlonzo.Code.Data.Fin.Base.C_suc_16 v6 -> coe v1 (coe C_ι_24 v6)
             _ -> MAlonzo.RTE.mazUnreachableError
      _ -> MAlonzo.RTE.mazUnreachableError
-- Matrix.length
d_length_48 :: T_Shape_12 -> Integer
d_length_48 v0
  = case coe v0 of
      C_ι_14 v1 -> coe v1
      C__'8855'__16 v1 v2
        -> coe mulInt (coe d_length_48 (coe v1)) (coe d_length_48 (coe v2))
      _ -> MAlonzo.RTE.mazUnreachableError
-- Matrix.map
d_map_56 ::
  () ->
  () ->
  T_Shape_12 ->
  (AgdaAny -> AgdaAny) ->
  (T_Position_22 -> AgdaAny) -> T_Position_22 -> AgdaAny
d_map_56 ~v0 ~v1 ~v2 v3 v4 v5 = du_map_56 v3 v4 v5
du_map_56 ::
  (AgdaAny -> AgdaAny) ->
  (T_Position_22 -> AgdaAny) -> T_Position_22 -> AgdaAny
du_map_56 v0 v1 v2 = coe v0 (coe v1 v2)
-- Matrix.nest
d_nest_64 ::
  T_Shape_12 ->
  T_Shape_12 ->
  () ->
  (T_Position_22 -> AgdaAny) ->
  T_Position_22 -> T_Position_22 -> AgdaAny
d_nest_64 ~v0 ~v1 ~v2 v3 v4 v5 = du_nest_64 v3 v4 v5
du_nest_64 ::
  (T_Position_22 -> AgdaAny) ->
  T_Position_22 -> T_Position_22 -> AgdaAny
du_nest_64 v0 v1 v2 = coe v0 (coe C__'8855'__26 v1 v2)
-- Matrix.unnest
d_unnest_72 ::
  T_Shape_12 ->
  T_Shape_12 ->
  () ->
  (T_Position_22 -> T_Position_22 -> AgdaAny) ->
  T_Position_22 -> AgdaAny
d_unnest_72 ~v0 ~v1 ~v2 v3 v4 = du_unnest_72 v3 v4
du_unnest_72 ::
  (T_Position_22 -> T_Position_22 -> AgdaAny) ->
  T_Position_22 -> AgdaAny
du_unnest_72 v0 v1
  = case coe v1 of
      C__'8855'__26 v4 v5 -> coe v0 v4 v5
      _ -> MAlonzo.RTE.mazUnreachableError
-- Matrix.mapLeft
d_mapLeft_86 ::
  () ->
  () ->
  T_Shape_12 ->
  T_Shape_12 ->
  T_Shape_12 ->
  ((T_Position_22 -> AgdaAny) -> T_Position_22 -> AgdaAny) ->
  (T_Position_22 -> AgdaAny) -> T_Position_22 -> AgdaAny
d_mapLeft_86 ~v0 ~v1 ~v2 ~v3 ~v4 v5 v6 = du_mapLeft_86 v5 v6
du_mapLeft_86 ::
  ((T_Position_22 -> AgdaAny) -> T_Position_22 -> AgdaAny) ->
  (T_Position_22 -> AgdaAny) -> T_Position_22 -> AgdaAny
du_mapLeft_86 v0 v1
  = coe
      du_unnest_72 (coe du_map_56 (coe v0) (coe du_nest_64 (coe v1)))
-- Matrix.head₁
d_head'8321'_92 ::
  Integer -> () -> (T_Position_22 -> AgdaAny) -> AgdaAny
d_head'8321'_92 ~v0 ~v1 v2 = du_head'8321'_92 v2
du_head'8321'_92 :: (T_Position_22 -> AgdaAny) -> AgdaAny
du_head'8321'_92 v0
  = coe v0 (coe C_ι_24 (coe MAlonzo.Code.Data.Fin.Base.C_zero_12))
-- Matrix.tail₁
d_tail'8321'_96 ::
  Integer ->
  () -> (T_Position_22 -> AgdaAny) -> T_Position_22 -> AgdaAny
d_tail'8321'_96 ~v0 ~v1 v2 v3 = du_tail'8321'_96 v2 v3
du_tail'8321'_96 ::
  (T_Position_22 -> AgdaAny) -> T_Position_22 -> AgdaAny
du_tail'8321'_96 v0 v1
  = case coe v1 of
      C_ι_24 v3
        -> coe v0 (coe C_ι_24 (coe MAlonzo.Code.Data.Fin.Base.C_suc_16 v3))
      _ -> MAlonzo.RTE.mazUnreachableError
-- Matrix.splitArₗ
d_splitAr'8343'_102 ::
  Integer ->
  Integer ->
  () -> (T_Position_22 -> AgdaAny) -> T_Position_22 -> AgdaAny
d_splitAr'8343'_102 v0 ~v1 ~v2 v3 v4
  = du_splitAr'8343'_102 v0 v3 v4
du_splitAr'8343'_102 ::
  Integer -> (T_Position_22 -> AgdaAny) -> T_Position_22 -> AgdaAny
du_splitAr'8343'_102 v0 v1 v2
  = case coe v2 of
      C_ι_24 v4
        -> coe
             v1
             (coe
                C_ι_24
                (coe
                   MAlonzo.Code.Data.Fin.Base.du_join_166 v0
                   (coe MAlonzo.Code.Data.Sum.Base.C_inj'8321'_38 (coe v4))))
      _ -> MAlonzo.RTE.mazUnreachableError
-- Matrix.splitArᵣ
d_splitAr'7523'_112 ::
  Integer ->
  Integer ->
  () -> (T_Position_22 -> AgdaAny) -> T_Position_22 -> AgdaAny
d_splitAr'7523'_112 v0 ~v1 ~v2 v3 v4
  = du_splitAr'7523'_112 v0 v3 v4
du_splitAr'7523'_112 ::
  Integer -> (T_Position_22 -> AgdaAny) -> T_Position_22 -> AgdaAny
du_splitAr'7523'_112 v0 v1 v2
  = case coe v2 of
      C_ι_24 v4
        -> coe
             v1
             (coe
                C_ι_24
                (coe
                   MAlonzo.Code.Data.Fin.Base.du_join_166 v0
                   (coe MAlonzo.Code.Data.Sum.Base.C_inj'8322'_42 (coe v4))))
      _ -> MAlonzo.RTE.mazUnreachableError
-- Matrix.splitAr
d_splitAr_122 ::
  Integer ->
  Integer ->
  () ->
  (T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_splitAr_122 v0 ~v1 ~v2 v3 = du_splitAr_122 v0 v3
du_splitAr_122 ::
  Integer ->
  (T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
du_splitAr_122 v0 v1
  = coe
      MAlonzo.Code.Agda.Builtin.Sigma.C__'44'__32
      (coe du_splitAr'8343'_102 (coe v0) (coe v1))
      (coe du_splitAr'7523'_112 (coe v0) (coe v1))
-- Matrix.foldr
d_foldr_132 ::
  Integer ->
  () ->
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny -> (T_Position_22 -> AgdaAny) -> AgdaAny
d_foldr_132 v0 ~v1 ~v2 v3 v4 v5 = du_foldr_132 v0 v3 v4 v5
du_foldr_132 ::
  Integer ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny -> (T_Position_22 -> AgdaAny) -> AgdaAny
du_foldr_132 v0 v1 v2 v3
  = case coe v0 of
      0 -> coe v2
      _ -> let v4 = subInt (coe v0) (coe (1 :: Integer)) in
           coe
             (coe
                du_foldr_132 (coe v4) (coe v1)
                (coe v1 (coe du_head'8321'_92 (coe v3)) v2)
                (coe du_tail'8321'_96 (coe v3)))
-- Matrix.zip
d_zip_148 ::
  Integer ->
  () ->
  () ->
  (T_Position_22 -> AgdaAny) ->
  (T_Position_22 -> AgdaAny) ->
  T_Position_22 -> MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_zip_148 ~v0 ~v1 ~v2 v3 v4 v5 = du_zip_148 v3 v4 v5
du_zip_148 ::
  (T_Position_22 -> AgdaAny) ->
  (T_Position_22 -> AgdaAny) ->
  T_Position_22 -> MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
du_zip_148 v0 v1 v2
  = coe
      MAlonzo.Code.Agda.Builtin.Sigma.C__'44'__32 (coe v0 v2) (coe v1 v2)
-- Matrix.zipWith
d_zipWith_156 ::
  () ->
  () ->
  () ->
  T_Shape_12 ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  (T_Position_22 -> AgdaAny) ->
  (T_Position_22 -> AgdaAny) -> T_Position_22 -> AgdaAny
d_zipWith_156 ~v0 ~v1 ~v2 ~v3 v4 v5 v6 v7
  = du_zipWith_156 v4 v5 v6 v7
du_zipWith_156 ::
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  (T_Position_22 -> AgdaAny) ->
  (T_Position_22 -> AgdaAny) -> T_Position_22 -> AgdaAny
du_zipWith_156 v0 v1 v2 v3 = coe v0 (coe v1 v3) (coe v2 v3)
-- Matrix.iterate
d_iterate_168 ::
  () ->
  Integer ->
  (AgdaAny -> AgdaAny) -> AgdaAny -> T_Position_22 -> AgdaAny
d_iterate_168 ~v0 v1 v2 v3 = du_iterate_168 v1 v2 v3
du_iterate_168 ::
  Integer ->
  (AgdaAny -> AgdaAny) -> AgdaAny -> T_Position_22 -> AgdaAny
du_iterate_168 v0 v1 v2
  = case coe v0 of
      0 -> coe (\ v3 -> coe du_nil_34)
      _ -> let v3 = subInt (coe v0) (coe (1 :: Integer)) in
           coe
             (coe
                du_ι'45'cons_36 (coe v2)
                (coe du_iterate_168 (coe v3) (coe v1) (coe v1 v2)))
