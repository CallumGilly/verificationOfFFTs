{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wno-overlapping-patterns #-}

module MAlonzo.Code.Implementations.FFT where

import MAlonzo.RTE (coe, erased, AgdaAny, addInt, subInt, mulInt,
                    quotInt, remInt, geqInt, ltInt, eqInt, add64, sub64, mul64, quot64,
                    rem64, lt64, eq64, word64FromNat, word64ToNat)
import qualified MAlonzo.RTE
import qualified Data.Text
import qualified MAlonzo.Code.Agda.Builtin.Float
import qualified MAlonzo.Code.Agda.Builtin.IO
import qualified MAlonzo.Code.Agda.Builtin.String
import qualified MAlonzo.Code.Agda.Primitive
import qualified MAlonzo.Code.Complex
import qualified MAlonzo.Code.FFT
import qualified MAlonzo.Code.IO.Base
import qualified MAlonzo.Code.IO.Finite
import qualified MAlonzo.Code.Implementations.Complex
import qualified MAlonzo.Code.Implementations.Real
import qualified MAlonzo.Code.Level
import qualified MAlonzo.Code.Matrix
import qualified MAlonzo.Code.Matrix.Reshape
import qualified MAlonzo.Code.Matrix.Show

-- Implementations.FFT._.ℂ₁
d_ℂ'8321'_1 = ()
-- Implementations.FFT._.complexImplementation
d_complexImplementation_8 :: MAlonzo.Code.Complex.T_Cplx_14
d_complexImplementation_8
  = coe
      MAlonzo.Code.Implementations.Complex.d_complexImplementation_150
      (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
-- Implementations.FFT._._ᵣ
d__'7523'_12 ::
  Integer -> MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d__'7523'_12
  = coe MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
-- Implementations.FFT._.-_
d_'45'__14 ::
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d_'45'__14
  = coe MAlonzo.Code.Agda.Builtin.Float.d_primFloatNegate_58
-- Implementations.FFT._.ℝ
d_ℝ_16 :: ()
d_ℝ_16 = erased
-- Implementations.FFT._.fromℝ
d_fromℝ_20 ::
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Implementations.Complex.T_ℂ'8321'_30
d_fromℝ_20
  = coe
      MAlonzo.Code.Implementations.Complex.d_fromℝ_84
      (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
-- Implementations.FFT._.ℂ
d_ℂ_22 :: ()
d_ℂ_22 = erased
-- Implementations.FFT._.DFT
d_DFT_26 ::
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 ->
   MAlonzo.Code.Implementations.Complex.T_ℂ'8321'_30) ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Implementations.Complex.T_ℂ'8321'_30
d_DFT_26
  = coe
      MAlonzo.Code.FFT.d_DFT_2650
      (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
      (coe
         MAlonzo.Code.Implementations.Complex.d_complexImplementation_150
         (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544))
-- Implementations.FFT._.FFT
d_FFT_28 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  (MAlonzo.Code.Matrix.T_Position_22 ->
   MAlonzo.Code.Implementations.Complex.T_ℂ'8321'_30) ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Implementations.Complex.T_ℂ'8321'_30
d_FFT_28
  = coe
      MAlonzo.Code.FFT.d_FFT_2674
      (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
      (coe
         MAlonzo.Code.Implementations.Complex.d_complexImplementation_150
         (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544))
-- Implementations.FFT._++_
d__'43''43'__32 ::
  MAlonzo.Code.Agda.Builtin.String.T_String_6 ->
  MAlonzo.Code.Agda.Builtin.String.T_String_6 ->
  MAlonzo.Code.Agda.Builtin.String.T_String_6
d__'43''43'__32
  = coe MAlonzo.Code.Agda.Builtin.String.d_primStringAppend_16
-- Implementations.FFT.showℂ
d_showℂ_34 ::
  MAlonzo.Code.Implementations.Complex.T_ℂ'8321'_30 ->
  MAlonzo.Code.Agda.Builtin.String.T_String_6
d_showℂ_34 v0
  = case coe v0 of
      MAlonzo.Code.Implementations.Complex.C__'43'_i_40 v1 v2
        -> coe
             d__'43''43'__32
             (coe
                d__'43''43'__32
                (coe
                   d__'43''43'__32
                   (coe MAlonzo.Code.Implementations.Real.d_showℝ_2576 v1)
                   (" + " :: Data.Text.Text))
                (coe MAlonzo.Code.Implementations.Real.d_showℝ_2576 v2))
             (" i" :: Data.Text.Text)
      _ -> MAlonzo.RTE.mazUnreachableError
-- Implementations.FFT.showDemoℂ
d_showDemoℂ_40 ::
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.IO.Base.T_IO_20
d_showDemoℂ_40 v0
  = coe
      MAlonzo.Code.IO.Finite.d_putStrLn_28 (coe v0)
      (coe
         d_showℂ_34
         (coe
            MAlonzo.Code.Implementations.Complex.C__'43'_i_40
            (coe
               MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24 (4 :: Integer))
            (coe
               MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
               (2 :: Integer))))
-- Implementations.FFT.demo-mat₁
d_demo'45'mat'8321'_42 ::
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Implementations.Complex.T_ℂ'8321'_30
d_demo'45'mat'8321'_42
  = coe
      MAlonzo.Code.Matrix.Reshape.du_reshape_70
      (coe
         MAlonzo.Code.Matrix.C_ι_14
         (coe mulInt (coe (4 :: Integer)) (coe (4 :: Integer))))
      (coe
         MAlonzo.Code.Matrix.C__'8855'__16
         (coe MAlonzo.Code.Matrix.C_ι_14 (coe (4 :: Integer)))
         (coe MAlonzo.Code.Matrix.C_ι_14 (coe (4 :: Integer))))
      (coe MAlonzo.Code.Matrix.Reshape.C_split_32)
      (coe d_demo'45'mat'8321''45'vec_48)
-- Implementations.FFT._.demo-mat₁-vec
d_demo'45'mat'8321''45'vec_48 ::
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Implementations.Complex.T_ℂ'8321'_30
d_demo'45'mat'8321''45'vec_48
  = coe
      MAlonzo.Code.Matrix.du_ι'45'cons_36
      (coe
         MAlonzo.Code.Implementations.Complex.d_fromℝ_84
         (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
         (coe
            MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
            (87 :: Integer)))
      (coe
         MAlonzo.Code.Matrix.du_ι'45'cons_36
         (coe
            MAlonzo.Code.Implementations.Complex.d_fromℝ_84
            (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
            (coe
               MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
               (13 :: Integer)))
         (coe
            MAlonzo.Code.Matrix.du_ι'45'cons_36
            (coe
               MAlonzo.Code.Implementations.Complex.d_fromℝ_84
               (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
               (coe
                  MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                  (72 :: Integer)))
            (coe
               MAlonzo.Code.Matrix.du_ι'45'cons_36
               (coe
                  MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                  (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                  (coe
                     MAlonzo.Code.Agda.Builtin.Float.d_primFloatNegate_58
                     (coe
                        MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                        (44 :: Integer))))
               (coe
                  MAlonzo.Code.Matrix.du_ι'45'cons_36
                  (coe
                     MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                     (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                     (coe
                        MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                        (99 :: Integer)))
                  (coe
                     MAlonzo.Code.Matrix.du_ι'45'cons_36
                     (coe
                        MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                        (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                        (coe
                           MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                           (8 :: Integer)))
                     (coe
                        MAlonzo.Code.Matrix.du_ι'45'cons_36
                        (coe
                           MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                           (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                           (coe
                              MAlonzo.Code.Agda.Builtin.Float.d_primFloatNegate_58
                              (coe
                                 MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                 (63 :: Integer))))
                        (coe
                           MAlonzo.Code.Matrix.du_ι'45'cons_36
                           (coe
                              MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                              (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                              (coe
                                 MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                 (25 :: Integer)))
                           (coe
                              MAlonzo.Code.Matrix.du_ι'45'cons_36
                              (coe
                                 MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                 (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                 (coe
                                    MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                    (90 :: Integer)))
                              (coe
                                 MAlonzo.Code.Matrix.du_ι'45'cons_36
                                 (coe
                                    MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                    (coe
                                       MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                    (coe
                                       MAlonzo.Code.Agda.Builtin.Float.d_primFloatNegate_58
                                       (coe
                                          MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                          (31 :: Integer))))
                                 (coe
                                    MAlonzo.Code.Matrix.du_ι'45'cons_36
                                    (coe
                                       MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                       (coe
                                          MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                       (coe
                                          MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                          (56 :: Integer)))
                                    (coe
                                       MAlonzo.Code.Matrix.du_ι'45'cons_36
                                       (coe
                                          MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                          (coe
                                             MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                          (coe
                                             MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                             (19 :: Integer)))
                                       (coe
                                          MAlonzo.Code.Matrix.du_ι'45'cons_36
                                          (coe
                                             MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                             (coe
                                                MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                             (coe
                                                MAlonzo.Code.Agda.Builtin.Float.d_primFloatNegate_58
                                                (coe
                                                   MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                   (100 :: Integer))))
                                          (coe
                                             MAlonzo.Code.Matrix.du_ι'45'cons_36
                                             (coe
                                                MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                (coe
                                                   MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                (coe
                                                   MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                   (37 :: Integer)))
                                             (coe
                                                MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                (coe
                                                   MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                   (coe
                                                      MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                   (coe
                                                      MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                      (4 :: Integer)))
                                                (coe
                                                   MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                   (coe
                                                      MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                      (coe
                                                         MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                      (coe
                                                         MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                         (61 :: Integer)))
                                                   (\ v0 ->
                                                      coe
                                                        MAlonzo.Code.Matrix.du_nil_34))))))))))))))))
-- Implementations.FFT.demo-mat₂
d_demo'45'mat'8322'_50 ::
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Implementations.Complex.T_ℂ'8321'_30
d_demo'45'mat'8322'_50
  = coe
      MAlonzo.Code.Matrix.Reshape.du_reshape_70
      (coe
         MAlonzo.Code.Matrix.C_ι_14
         (coe
            mulInt (coe (12 :: Integer))
            (coe mulInt (coe (4 :: Integer)) (coe (3 :: Integer)))))
      (coe
         MAlonzo.Code.Matrix.C__'8855'__16
         (coe MAlonzo.Code.Matrix.C_ι_14 (coe (12 :: Integer)))
         (coe
            MAlonzo.Code.Matrix.C__'8855'__16
            (coe MAlonzo.Code.Matrix.C_ι_14 (coe (4 :: Integer)))
            (coe MAlonzo.Code.Matrix.C_ι_14 (coe (3 :: Integer)))))
      (coe
         MAlonzo.Code.Matrix.Reshape.C__'8729'__28
         (coe
            MAlonzo.Code.Matrix.C__'8855'__16
            (coe MAlonzo.Code.Matrix.C_ι_14 (coe (12 :: Integer)))
            (coe
               MAlonzo.Code.Matrix.C_ι_14
               (coe mulInt (coe (4 :: Integer)) (coe (3 :: Integer)))))
         (coe
            MAlonzo.Code.Matrix.Reshape.C__'8853'__30
            (coe MAlonzo.Code.Matrix.Reshape.C_eq_26)
            (coe MAlonzo.Code.Matrix.Reshape.C_split_32))
         (coe MAlonzo.Code.Matrix.Reshape.C_split_32))
      (coe d_demo'45'mat'8322''45'vec_56)
-- Implementations.FFT._.demo-mat₂-vec
d_demo'45'mat'8322''45'vec_56 ::
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Implementations.Complex.T_ℂ'8321'_30
d_demo'45'mat'8322''45'vec_56
  = coe
      MAlonzo.Code.Matrix.du_ι'45'cons_36
      (coe
         MAlonzo.Code.Implementations.Complex.d_fromℝ_84
         (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
         (coe
            MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
            (1 :: Integer)))
      (coe
         MAlonzo.Code.Matrix.du_ι'45'cons_36
         (coe
            MAlonzo.Code.Implementations.Complex.d_fromℝ_84
            (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
            (coe
               MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
               (3 :: Integer)))
         (coe
            MAlonzo.Code.Matrix.du_ι'45'cons_36
            (coe
               MAlonzo.Code.Implementations.Complex.d_fromℝ_84
               (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
               (coe
                  MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                  (5 :: Integer)))
            (coe
               MAlonzo.Code.Matrix.du_ι'45'cons_36
               (coe
                  MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                  (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                  (coe
                     MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                     (3 :: Integer)))
               (coe
                  MAlonzo.Code.Matrix.du_ι'45'cons_36
                  (coe
                     MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                     (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                     (coe
                        MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                        (1 :: Integer)))
                  (coe
                     MAlonzo.Code.Matrix.du_ι'45'cons_36
                     (coe
                        MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                        (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                        (coe
                           MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                           (3 :: Integer)))
                     (coe
                        MAlonzo.Code.Matrix.du_ι'45'cons_36
                        (coe
                           MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                           (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                           (coe
                              MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                              (5 :: Integer)))
                        (coe
                           MAlonzo.Code.Matrix.du_ι'45'cons_36
                           (coe
                              MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                              (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                              (coe
                                 MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                 (3 :: Integer)))
                           (coe
                              MAlonzo.Code.Matrix.du_ι'45'cons_36
                              (coe
                                 MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                 (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                 (coe
                                    MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                    (1 :: Integer)))
                              (coe
                                 MAlonzo.Code.Matrix.du_ι'45'cons_36
                                 (coe
                                    MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                    (coe
                                       MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                    (coe
                                       MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                       (5 :: Integer)))
                                 (coe
                                    MAlonzo.Code.Matrix.du_ι'45'cons_36
                                    (coe
                                       MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                       (coe
                                          MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                       (coe
                                          MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                          (10 :: Integer)))
                                    (coe
                                       MAlonzo.Code.Matrix.du_ι'45'cons_36
                                       (coe
                                          MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                          (coe
                                             MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                          (coe
                                             MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                             (5 :: Integer)))
                                       (coe
                                          MAlonzo.Code.Matrix.du_ι'45'cons_36
                                          (coe
                                             MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                             (coe
                                                MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                             (coe
                                                MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                (1 :: Integer)))
                                          (coe
                                             MAlonzo.Code.Matrix.du_ι'45'cons_36
                                             (coe
                                                MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                (coe
                                                   MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                (coe
                                                   MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                   (3 :: Integer)))
                                             (coe
                                                MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                (coe
                                                   MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                   (coe
                                                      MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                   (coe
                                                      MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                      (5 :: Integer)))
                                                (coe
                                                   MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                   (coe
                                                      MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                      (coe
                                                         MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                      (coe
                                                         MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                         (3 :: Integer)))
                                                   (coe
                                                      MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                      (coe
                                                         MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                         (coe
                                                            MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                         (coe
                                                            MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                            (1 :: Integer)))
                                                      (coe
                                                         MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                         (coe
                                                            MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                            (coe
                                                               MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                            (coe
                                                               MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                               (3 :: Integer)))
                                                         (coe
                                                            MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                            (coe
                                                               MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                               (coe
                                                                  MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                               (coe
                                                                  MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                  (5 :: Integer)))
                                                            (coe
                                                               MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                               (coe
                                                                  MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                  (coe
                                                                     MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                  (coe
                                                                     MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                     (3 :: Integer)))
                                                               (coe
                                                                  MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                  (coe
                                                                     MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                     (coe
                                                                        MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                     (coe
                                                                        MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                        (1 :: Integer)))
                                                                  (coe
                                                                     MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                     (coe
                                                                        MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                        (coe
                                                                           MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                        (coe
                                                                           MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                           (5 :: Integer)))
                                                                     (coe
                                                                        MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                        (coe
                                                                           MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                           (coe
                                                                              MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                           (coe
                                                                              MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                              (10 :: Integer)))
                                                                        (coe
                                                                           MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                           (coe
                                                                              MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                              (coe
                                                                                 MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                              (coe
                                                                                 MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                 (5 :: Integer)))
                                                                           (coe
                                                                              MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                              (coe
                                                                                 MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                 (coe
                                                                                    MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                 (coe
                                                                                    MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                    (1 :: Integer)))
                                                                              (coe
                                                                                 MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                 (coe
                                                                                    MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                    (coe
                                                                                       MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                    (coe
                                                                                       MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                       (3 ::
                                                                                          Integer)))
                                                                                 (coe
                                                                                    MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                    (coe
                                                                                       MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                       (coe
                                                                                          MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                       (coe
                                                                                          MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                          (5 ::
                                                                                             Integer)))
                                                                                    (coe
                                                                                       MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                       (coe
                                                                                          MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                          (coe
                                                                                             MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                          (coe
                                                                                             MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                             (3 ::
                                                                                                Integer)))
                                                                                       (coe
                                                                                          MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                          (coe
                                                                                             MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                             (coe
                                                                                                MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                             (coe
                                                                                                MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                (1 ::
                                                                                                   Integer)))
                                                                                          (coe
                                                                                             MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                             (coe
                                                                                                MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                (coe
                                                                                                   MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                (coe
                                                                                                   MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                   (3 ::
                                                                                                      Integer)))
                                                                                             (coe
                                                                                                MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                (coe
                                                                                                   MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                   (coe
                                                                                                      MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                   (coe
                                                                                                      MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                      (5 ::
                                                                                                         Integer)))
                                                                                                (coe
                                                                                                   MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                   (coe
                                                                                                      MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                      (coe
                                                                                                         MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                      (coe
                                                                                                         MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                         (3 ::
                                                                                                            Integer)))
                                                                                                   (coe
                                                                                                      MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                      (coe
                                                                                                         MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                         (coe
                                                                                                            MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                         (coe
                                                                                                            MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                            (1 ::
                                                                                                               Integer)))
                                                                                                      (coe
                                                                                                         MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                         (coe
                                                                                                            MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                            (coe
                                                                                                               MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                            (coe
                                                                                                               MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                               (5 ::
                                                                                                                  Integer)))
                                                                                                         (coe
                                                                                                            MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                            (coe
                                                                                                               MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                               (coe
                                                                                                                  MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                               (coe
                                                                                                                  MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                  (10 ::
                                                                                                                     Integer)))
                                                                                                            (coe
                                                                                                               MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                               (coe
                                                                                                                  MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                  (coe
                                                                                                                     MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                  (coe
                                                                                                                     MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                     (5 ::
                                                                                                                        Integer)))
                                                                                                               (coe
                                                                                                                  MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                  (coe
                                                                                                                     MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                     (coe
                                                                                                                        MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                     (coe
                                                                                                                        MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                        (1 ::
                                                                                                                           Integer)))
                                                                                                                  (coe
                                                                                                                     MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                     (coe
                                                                                                                        MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                        (coe
                                                                                                                           MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                        (coe
                                                                                                                           MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                           (3 ::
                                                                                                                              Integer)))
                                                                                                                     (coe
                                                                                                                        MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                        (coe
                                                                                                                           MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                           (coe
                                                                                                                              MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                           (coe
                                                                                                                              MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                              (5 ::
                                                                                                                                 Integer)))
                                                                                                                        (coe
                                                                                                                           MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                           (coe
                                                                                                                              MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                              (coe
                                                                                                                                 MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                              (coe
                                                                                                                                 MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                 (3 ::
                                                                                                                                    Integer)))
                                                                                                                           (coe
                                                                                                                              MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                              (coe
                                                                                                                                 MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                 (coe
                                                                                                                                    MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                 (coe
                                                                                                                                    MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                    (1 ::
                                                                                                                                       Integer)))
                                                                                                                              (coe
                                                                                                                                 MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                 (coe
                                                                                                                                    MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                    (coe
                                                                                                                                       MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                    (coe
                                                                                                                                       MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                       (3 ::
                                                                                                                                          Integer)))
                                                                                                                                 (coe
                                                                                                                                    MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                    (coe
                                                                                                                                       MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                       (coe
                                                                                                                                          MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                       (coe
                                                                                                                                          MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                          (5 ::
                                                                                                                                             Integer)))
                                                                                                                                    (coe
                                                                                                                                       MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                       (coe
                                                                                                                                          MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                          (coe
                                                                                                                                             MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                          (coe
                                                                                                                                             MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                             (3 ::
                                                                                                                                                Integer)))
                                                                                                                                       (coe
                                                                                                                                          MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                          (coe
                                                                                                                                             MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                             (coe
                                                                                                                                                MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                             (coe
                                                                                                                                                MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                (1 ::
                                                                                                                                                   Integer)))
                                                                                                                                          (coe
                                                                                                                                             MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                             (coe
                                                                                                                                                MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                (coe
                                                                                                                                                   MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                (coe
                                                                                                                                                   MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                   (5 ::
                                                                                                                                                      Integer)))
                                                                                                                                             (coe
                                                                                                                                                MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                (coe
                                                                                                                                                   MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                   (coe
                                                                                                                                                      MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                   (coe
                                                                                                                                                      MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                      (10 ::
                                                                                                                                                         Integer)))
                                                                                                                                                (coe
                                                                                                                                                   MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                   (coe
                                                                                                                                                      MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                      (coe
                                                                                                                                                         MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                      (coe
                                                                                                                                                         MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                         (5 ::
                                                                                                                                                            Integer)))
                                                                                                                                                   (coe
                                                                                                                                                      MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                      (coe
                                                                                                                                                         MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                         (coe
                                                                                                                                                            MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                         (coe
                                                                                                                                                            MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                            (1 ::
                                                                                                                                                               Integer)))
                                                                                                                                                      (coe
                                                                                                                                                         MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                         (coe
                                                                                                                                                            MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                            (coe
                                                                                                                                                               MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                            (coe
                                                                                                                                                               MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                               (3 ::
                                                                                                                                                                  Integer)))
                                                                                                                                                         (coe
                                                                                                                                                            MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                            (coe
                                                                                                                                                               MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                               (coe
                                                                                                                                                                  MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                               (coe
                                                                                                                                                                  MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                  (5 ::
                                                                                                                                                                     Integer)))
                                                                                                                                                            (coe
                                                                                                                                                               MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                               (coe
                                                                                                                                                                  MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                  (coe
                                                                                                                                                                     MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                  (coe
                                                                                                                                                                     MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                     (3 ::
                                                                                                                                                                        Integer)))
                                                                                                                                                               (coe
                                                                                                                                                                  MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                  (coe
                                                                                                                                                                     MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                     (coe
                                                                                                                                                                        MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                     (coe
                                                                                                                                                                        MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                        (1 ::
                                                                                                                                                                           Integer)))
                                                                                                                                                                  (coe
                                                                                                                                                                     MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                     (coe
                                                                                                                                                                        MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                        (coe
                                                                                                                                                                           MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                        (coe
                                                                                                                                                                           MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                           (3 ::
                                                                                                                                                                              Integer)))
                                                                                                                                                                     (coe
                                                                                                                                                                        MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                        (coe
                                                                                                                                                                           MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                           (coe
                                                                                                                                                                              MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                           (coe
                                                                                                                                                                              MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                              (5 ::
                                                                                                                                                                                 Integer)))
                                                                                                                                                                        (coe
                                                                                                                                                                           MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                           (coe
                                                                                                                                                                              MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                              (coe
                                                                                                                                                                                 MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                              (coe
                                                                                                                                                                                 MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                 (3 ::
                                                                                                                                                                                    Integer)))
                                                                                                                                                                           (coe
                                                                                                                                                                              MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                              (coe
                                                                                                                                                                                 MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                 (coe
                                                                                                                                                                                    MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                 (coe
                                                                                                                                                                                    MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                    (1 ::
                                                                                                                                                                                       Integer)))
                                                                                                                                                                              (coe
                                                                                                                                                                                 MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                 (coe
                                                                                                                                                                                    MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                    (coe
                                                                                                                                                                                       MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                    (coe
                                                                                                                                                                                       MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                       (5 ::
                                                                                                                                                                                          Integer)))
                                                                                                                                                                                 (coe
                                                                                                                                                                                    MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                    (coe
                                                                                                                                                                                       MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                       (coe
                                                                                                                                                                                          MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                       (coe
                                                                                                                                                                                          MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                          (10 ::
                                                                                                                                                                                             Integer)))
                                                                                                                                                                                    (coe
                                                                                                                                                                                       MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                       (coe
                                                                                                                                                                                          MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                          (coe
                                                                                                                                                                                             MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                          (coe
                                                                                                                                                                                             MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                             (5 ::
                                                                                                                                                                                                Integer)))
                                                                                                                                                                                       (coe
                                                                                                                                                                                          MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                          (coe
                                                                                                                                                                                             MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                             (coe
                                                                                                                                                                                                MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                             (coe
                                                                                                                                                                                                MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                (1 ::
                                                                                                                                                                                                   Integer)))
                                                                                                                                                                                          (coe
                                                                                                                                                                                             MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                             (coe
                                                                                                                                                                                                MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                (coe
                                                                                                                                                                                                   MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                (coe
                                                                                                                                                                                                   MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                   (3 ::
                                                                                                                                                                                                      Integer)))
                                                                                                                                                                                             (coe
                                                                                                                                                                                                MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                (coe
                                                                                                                                                                                                   MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                   (coe
                                                                                                                                                                                                      MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                   (coe
                                                                                                                                                                                                      MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                      (5 ::
                                                                                                                                                                                                         Integer)))
                                                                                                                                                                                                (coe
                                                                                                                                                                                                   MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                   (coe
                                                                                                                                                                                                      MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                      (coe
                                                                                                                                                                                                         MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                      (coe
                                                                                                                                                                                                         MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                         (3 ::
                                                                                                                                                                                                            Integer)))
                                                                                                                                                                                                   (coe
                                                                                                                                                                                                      MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                      (coe
                                                                                                                                                                                                         MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                         (coe
                                                                                                                                                                                                            MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                         (coe
                                                                                                                                                                                                            MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                            (1 ::
                                                                                                                                                                                                               Integer)))
                                                                                                                                                                                                      (coe
                                                                                                                                                                                                         MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                         (coe
                                                                                                                                                                                                            MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                            (coe
                                                                                                                                                                                                               MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                            (coe
                                                                                                                                                                                                               MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                               (3 ::
                                                                                                                                                                                                                  Integer)))
                                                                                                                                                                                                         (coe
                                                                                                                                                                                                            MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                            (coe
                                                                                                                                                                                                               MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                  MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                  MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                  (5 ::
                                                                                                                                                                                                                     Integer)))
                                                                                                                                                                                                            (coe
                                                                                                                                                                                                               MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                  MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                     MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                     MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                     (3 ::
                                                                                                                                                                                                                        Integer)))
                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                  MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                     MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                        MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                        MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                        (1 ::
                                                                                                                                                                                                                           Integer)))
                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                     MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                        MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                           MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                           MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                           (5 ::
                                                                                                                                                                                                                              Integer)))
                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                        MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                           MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                              MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                              MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                              (10 ::
                                                                                                                                                                                                                                 Integer)))
                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                           MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                              MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                 MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                 MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                 (5 ::
                                                                                                                                                                                                                                    Integer)))
                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                              MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                 MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                    MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                    MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                    (1 ::
                                                                                                                                                                                                                                       Integer)))
                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                 MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                    MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                       MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                       MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                       (3 ::
                                                                                                                                                                                                                                          Integer)))
                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                    MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                       MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                          MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                          MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                          (5 ::
                                                                                                                                                                                                                                             Integer)))
                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                       MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                          MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                             MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                             MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                             (3 ::
                                                                                                                                                                                                                                                Integer)))
                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                          MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                             MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                (1 ::
                                                                                                                                                                                                                                                   Integer)))
                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                             MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                   MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                   MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                   (3 ::
                                                                                                                                                                                                                                                      Integer)))
                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                   MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                      MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                      MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                      (5 ::
                                                                                                                                                                                                                                                         Integer)))
                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                   MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                      MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                         MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                         MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                         (3 ::
                                                                                                                                                                                                                                                            Integer)))
                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                      MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                         MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                         (coe
                                                                                                                                                                                                                                                            MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                         (coe
                                                                                                                                                                                                                                                            MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                            (1 ::
                                                                                                                                                                                                                                                               Integer)))
                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                         MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                         (coe
                                                                                                                                                                                                                                                            MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                            (coe
                                                                                                                                                                                                                                                               MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                            (coe
                                                                                                                                                                                                                                                               MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                               (5 ::
                                                                                                                                                                                                                                                                  Integer)))
                                                                                                                                                                                                                                                         (coe
                                                                                                                                                                                                                                                            MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                            (coe
                                                                                                                                                                                                                                                               MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                                                                  MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                                                                  MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                  (10 ::
                                                                                                                                                                                                                                                                     Integer)))
                                                                                                                                                                                                                                                            (coe
                                                                                                                                                                                                                                                               MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                                                                  MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                                                                     MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                                                                     MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                     (5 ::
                                                                                                                                                                                                                                                                        Integer)))
                                                                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                                                                  MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                                                                     MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                                                                        MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                                                                        MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                        (1 ::
                                                                                                                                                                                                                                                                           Integer)))
                                                                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                                                                     MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                                                                        MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                                                                           MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                                                                           MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                           (3 ::
                                                                                                                                                                                                                                                                              Integer)))
                                                                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                                                                        MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                                                                           MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                                                                              MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                                                                              MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                              (5 ::
                                                                                                                                                                                                                                                                                 Integer)))
                                                                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                                                                           MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                                                                              MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                                                                 MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                                                                 MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                 (3 ::
                                                                                                                                                                                                                                                                                    Integer)))
                                                                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                                                                              MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                                                                 MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                                                                    MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                                                                    MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                    (1 ::
                                                                                                                                                                                                                                                                                       Integer)))
                                                                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                                                                 MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                                                                    MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                                                                       MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                                                                       MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                       (3 ::
                                                                                                                                                                                                                                                                                          Integer)))
                                                                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                                                                    MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                                                                       MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                                                                          MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                                                                          MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                          (5 ::
                                                                                                                                                                                                                                                                                             Integer)))
                                                                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                                                                       MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                                                                          MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                                                                             MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                                                                             MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                             (3 ::
                                                                                                                                                                                                                                                                                                Integer)))
                                                                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                                                                          MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                                                                             MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                                                                MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                                                                MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                (1 ::
                                                                                                                                                                                                                                                                                                   Integer)))
                                                                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                                                                             MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                                                                MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                                                                   MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                                                                   MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                   (5 ::
                                                                                                                                                                                                                                                                                                      Integer)))
                                                                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                                                                MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                                                                   MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                                                                      MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                                                                      MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                      (10 ::
                                                                                                                                                                                                                                                                                                         Integer)))
                                                                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                                                                   MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                                                                      MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                                                                         MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                                                                         MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                         (5 ::
                                                                                                                                                                                                                                                                                                            Integer)))
                                                                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                                                                      MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                                                                         MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                         (coe
                                                                                                                                                                                                                                                                                                            MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                         (coe
                                                                                                                                                                                                                                                                                                            MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                            (1 ::
                                                                                                                                                                                                                                                                                                               Integer)))
                                                                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                                                                         MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                         (coe
                                                                                                                                                                                                                                                                                                            MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                            (coe
                                                                                                                                                                                                                                                                                                               MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                            (coe
                                                                                                                                                                                                                                                                                                               MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                               (3 ::
                                                                                                                                                                                                                                                                                                                  Integer)))
                                                                                                                                                                                                                                                                                                         (coe
                                                                                                                                                                                                                                                                                                            MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                            (coe
                                                                                                                                                                                                                                                                                                               MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                                                                                                                  MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                                                                                                                  MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                  (5 ::
                                                                                                                                                                                                                                                                                                                     Integer)))
                                                                                                                                                                                                                                                                                                            (coe
                                                                                                                                                                                                                                                                                                               MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                                                                                                                  MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                                                                                                                     MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                                                                                                                     MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                     (3 ::
                                                                                                                                                                                                                                                                                                                        Integer)))
                                                                                                                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                                                                                                                  MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                                                                                                                     MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                                                                                                                        MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                                                                                                                        MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                        (1 ::
                                                                                                                                                                                                                                                                                                                           Integer)))
                                                                                                                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                                                                                                                     MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                                                                                                                        MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                                                                                                                           MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                                                                                                                           MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                           (3 ::
                                                                                                                                                                                                                                                                                                                              Integer)))
                                                                                                                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                                                                                                                        MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                                                                                                                           MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                                                                                                                              MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                                                                                                                              MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                              (5 ::
                                                                                                                                                                                                                                                                                                                                 Integer)))
                                                                                                                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                                                                                                                           MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                                                                                                                              MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                                                                                                                 MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                                                                                                                 MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                 (3 ::
                                                                                                                                                                                                                                                                                                                                    Integer)))
                                                                                                                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                                                                                                                              MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                                                                                                                 MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                                                                                                                    MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                                                                                                                    MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                    (1 ::
                                                                                                                                                                                                                                                                                                                                       Integer)))
                                                                                                                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                                                                                                                 MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                                                                                                                    MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                                                                                                                       MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                                                                                                                       MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                       (5 ::
                                                                                                                                                                                                                                                                                                                                          Integer)))
                                                                                                                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                                                                                                                    MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                                                                                                                       MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                                                                                                                          MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                                                                                                                          MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                          (10 ::
                                                                                                                                                                                                                                                                                                                                             Integer)))
                                                                                                                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                                                                                                                       MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                                                                                                                          MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                                                                                                                             MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                                                                                                                             MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                             (5 ::
                                                                                                                                                                                                                                                                                                                                                Integer)))
                                                                                                                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                                                                                                                          MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                                                                                                                             MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                                                                                                                MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                                                                                                                MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                (1 ::
                                                                                                                                                                                                                                                                                                                                                   Integer)))
                                                                                                                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                                                                                                                             MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                                                                                                                MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                                                                                                                   MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                                                                                                                   MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                   (3 ::
                                                                                                                                                                                                                                                                                                                                                      Integer)))
                                                                                                                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                                                                                                                MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                                                                                                                   MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                                                                                                                      MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                                                                                                                      MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                      (5 ::
                                                                                                                                                                                                                                                                                                                                                         Integer)))
                                                                                                                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                                                                                                                   MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                                                                                                                      MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                                                                                                                         MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                                                                                                                         MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                         (3 ::
                                                                                                                                                                                                                                                                                                                                                            Integer)))
                                                                                                                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                                                                                                                      MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                                                                                                                         MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                         (coe
                                                                                                                                                                                                                                                                                                                                                            MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                         (coe
                                                                                                                                                                                                                                                                                                                                                            MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                            (1 ::
                                                                                                                                                                                                                                                                                                                                                               Integer)))
                                                                                                                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                                                                                                                         MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                         (coe
                                                                                                                                                                                                                                                                                                                                                            MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                            (coe
                                                                                                                                                                                                                                                                                                                                                               MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                            (coe
                                                                                                                                                                                                                                                                                                                                                               MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                               (3 ::
                                                                                                                                                                                                                                                                                                                                                                  Integer)))
                                                                                                                                                                                                                                                                                                                                                         (coe
                                                                                                                                                                                                                                                                                                                                                            MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                            (coe
                                                                                                                                                                                                                                                                                                                                                               MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                                                                                                                                                                  MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                                                                                                                                                                  MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                  (5 ::
                                                                                                                                                                                                                                                                                                                                                                     Integer)))
                                                                                                                                                                                                                                                                                                                                                            (coe
                                                                                                                                                                                                                                                                                                                                                               MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                                                                                                                                                                  MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                                                                                                                                                                     MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                                                                                                                                                                     MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                     (3 ::
                                                                                                                                                                                                                                                                                                                                                                        Integer)))
                                                                                                                                                                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                                                                                                                                                                  MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                                                                                                                                                                     MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                                                                                                                                                                        MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                                                                                                                                                                        MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                        (1 ::
                                                                                                                                                                                                                                                                                                                                                                           Integer)))
                                                                                                                                                                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                                                                                                                                                                     MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                                                                                                                                                                        MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                                                                                                                                                                           MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                                                                                                                                                                           MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                           (5 ::
                                                                                                                                                                                                                                                                                                                                                                              Integer)))
                                                                                                                                                                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                                                                                                                                                                        MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                                                                                                                                                                           MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                                                                                                                                                                              MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                                                                                                                                                                              MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                              (10 ::
                                                                                                                                                                                                                                                                                                                                                                                 Integer)))
                                                                                                                                                                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                                                                                                                                                                           MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                                                                                                                                                                              MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                                                                                                                                                                 MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                                                                                                                                                                 MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                 (5 ::
                                                                                                                                                                                                                                                                                                                                                                                    Integer)))
                                                                                                                                                                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                                                                                                                                                                              MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                                                                                                                                                                 MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                                                                                                                                                                    MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                                                                                                                                                                    MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                    (1 ::
                                                                                                                                                                                                                                                                                                                                                                                       Integer)))
                                                                                                                                                                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                                                                                                                                                                 MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                                                                                                                                                                    MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                                                                                                                                                                       MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                                                                                                                                                                       MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                       (3 ::
                                                                                                                                                                                                                                                                                                                                                                                          Integer)))
                                                                                                                                                                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                                                                                                                                                                    MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                                                                                                                                                                       MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                                                                                                                                                                          MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                                                                                                                                                                          MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                          (5 ::
                                                                                                                                                                                                                                                                                                                                                                                             Integer)))
                                                                                                                                                                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                                                                                                                                                                       MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                                                                                                                                                                          MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                                                                                                                                                                             MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                                                                                                                                                                             MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                             (3 ::
                                                                                                                                                                                                                                                                                                                                                                                                Integer)))
                                                                                                                                                                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                                                                                                                                                                          MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                                                                                                                                                                             MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                                                                                                                                                                MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                                                                                                                                                                MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                (1 ::
                                                                                                                                                                                                                                                                                                                                                                                                   Integer)))
                                                                                                                                                                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                                                                                                                                                                             MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                                                                                                                                                                MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                                                                                                                                                                   MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                                                                                                                                                                   MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                   (3 ::
                                                                                                                                                                                                                                                                                                                                                                                                      Integer)))
                                                                                                                                                                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                                                                                                                                                                MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                                                                                                                                                                   MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                                                                                                                                                                      MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                                                                                                                                                                      MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                      (5 ::
                                                                                                                                                                                                                                                                                                                                                                                                         Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                                                                                                                                                                   MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                                                                                                                                                                      MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                                                                                                                                                                         MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                                                                                                                                                                         MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                         (3 ::
                                                                                                                                                                                                                                                                                                                                                                                                            Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                                                                                                                                                                      MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                                                                                                                                                                         MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                         (coe
                                                                                                                                                                                                                                                                                                                                                                                                            MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                         (coe
                                                                                                                                                                                                                                                                                                                                                                                                            MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                            (1 ::
                                                                                                                                                                                                                                                                                                                                                                                                               Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                                                                                                                                                                         MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                         (coe
                                                                                                                                                                                                                                                                                                                                                                                                            MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                            (coe
                                                                                                                                                                                                                                                                                                                                                                                                               MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                            (coe
                                                                                                                                                                                                                                                                                                                                                                                                               MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                               (5 ::
                                                                                                                                                                                                                                                                                                                                                                                                                  Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                         (coe
                                                                                                                                                                                                                                                                                                                                                                                                            MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                            (coe
                                                                                                                                                                                                                                                                                                                                                                                                               MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                                                                                                                                                                                                                  MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                                                                                                                                                                                                                  MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                                  (10 ::
                                                                                                                                                                                                                                                                                                                                                                                                                     Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                            (coe
                                                                                                                                                                                                                                                                                                                                                                                                               MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                                                                                                                                                                                                                  MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                                                                                                                                                                                                                     MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                                                                                                                                                                                                                     MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                                     (5 ::
                                                                                                                                                                                                                                                                                                                                                                                                                        Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                               (coe
                                                                                                                                                                                                                                                                                                                                                                                                                  MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                                                                                                                                                                                                                     MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                                                                                                                                                                                                                        MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                                                                                                                                                                                                                        MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                                        (1 ::
                                                                                                                                                                                                                                                                                                                                                                                                                           Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                                  (coe
                                                                                                                                                                                                                                                                                                                                                                                                                     MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                                                                                                                                                                                                                        MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                                                                                                                                                                                                                           MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                                                                                                                                                                                                                           MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                                           (3 ::
                                                                                                                                                                                                                                                                                                                                                                                                                              Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                                     (coe
                                                                                                                                                                                                                                                                                                                                                                                                                        MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                                                                                                                                                                                                                           MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                                                                                                                                                                                                                              MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                                                                                                                                                                                                                              MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                                              (5 ::
                                                                                                                                                                                                                                                                                                                                                                                                                                 Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                                        (coe
                                                                                                                                                                                                                                                                                                                                                                                                                           MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                                                                                                                                                                                                                              MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                 MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                 MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                                                 (3 ::
                                                                                                                                                                                                                                                                                                                                                                                                                                    Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                                           (coe
                                                                                                                                                                                                                                                                                                                                                                                                                              MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                 MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                    MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                    MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                                                    (1 ::
                                                                                                                                                                                                                                                                                                                                                                                                                                       Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                                              (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                 MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                    MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                       MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                       MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                                                       (3 ::
                                                                                                                                                                                                                                                                                                                                                                                                                                          Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                                                 (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                    MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                       MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                          MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                          MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                                                          (5 ::
                                                                                                                                                                                                                                                                                                                                                                                                                                             Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                                                    (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                       MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                          MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                             MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                             MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                                                             (3 ::
                                                                                                                                                                                                                                                                                                                                                                                                                                                Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                                                       (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                          MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                             MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                                MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                                MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                                                                (1 ::
                                                                                                                                                                                                                                                                                                                                                                                                                                                   Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                                                          (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                             MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                                MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                                   MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                                   MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                                                                   (5 ::
                                                                                                                                                                                                                                                                                                                                                                                                                                                      Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                                                             (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                                MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                                   MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                                      MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                                      MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                                                                      (10 ::
                                                                                                                                                                                                                                                                                                                                                                                                                                                         Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                                                                (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                                   MAlonzo.Code.Matrix.du_ι'45'cons_36
                                                                                                                                                                                                                                                                                                                                                                                                                                                   (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                                      MAlonzo.Code.Implementations.Complex.d_fromℝ_84
                                                                                                                                                                                                                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                                         MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                                                                                                                                                                                                                                                                                                                                                                                                                                                      (coe
                                                                                                                                                                                                                                                                                                                                                                                                                                                         MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
                                                                                                                                                                                                                                                                                                                                                                                                                                                         (5 ::
                                                                                                                                                                                                                                                                                                                                                                                                                                                            Integer)))
                                                                                                                                                                                                                                                                                                                                                                                                                                                   (\ v0 ->
                                                                                                                                                                                                                                                                                                                                                                                                                                                      coe
                                                                                                                                                                                                                                                                                                                                                                                                                                                        MAlonzo.Code.Matrix.du_nil_34))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))
-- Implementations.FFT.show-arr
d_show'45'arr_58 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  (MAlonzo.Code.Matrix.T_Position_22 ->
   MAlonzo.Code.Implementations.Complex.T_ℂ'8321'_30) ->
  MAlonzo.Code.IO.Base.T_IO_20
d_show'45'arr_58 v0 v1 v2
  = coe
      MAlonzo.Code.IO.Finite.d_putStrLn_28 (coe v1)
      (coe
         d__'43''43'__32 ("Tensor:     " :: Data.Text.Text)
         (coe
            MAlonzo.Code.Matrix.Show.du_show_34 (coe v0) (coe d_showℂ_34)
            (coe v2)))
-- Implementations.FFT.show-flat-arr
d_show'45'flat'45'arr_60 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  (MAlonzo.Code.Matrix.T_Position_22 ->
   MAlonzo.Code.Implementations.Complex.T_ℂ'8321'_30) ->
  MAlonzo.Code.IO.Base.T_IO_20
d_show'45'flat'45'arr_60 v0 v1 v2
  = coe
      MAlonzo.Code.IO.Finite.d_putStrLn_28 (coe v1)
      (coe
         d__'43''43'__32 ("Flat Tensor:" :: Data.Text.Text)
         (coe
            MAlonzo.Code.Matrix.Show.du_show_34
            (coe
               MAlonzo.Code.Matrix.C_ι_14
               (coe
                  MAlonzo.Code.Matrix.d_length_48
                  (coe
                     MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232
                     (coe v0))))
            (coe d_showℂ_34)
            (coe
               MAlonzo.Code.Matrix.Reshape.du_reshape_70 (coe v0)
               (coe
                  MAlonzo.Code.Matrix.C_ι_14
                  (coe
                     MAlonzo.Code.Matrix.d_length_48
                     (coe
                        MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232
                        (coe v0))))
               (coe MAlonzo.Code.Matrix.Reshape.d_flatten'45'reindex_338 (coe v0))
               (coe v2))))
-- Implementations.FFT.show-flat-FFT-result
d_show'45'flat'45'FFT'45'result_62 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  (MAlonzo.Code.Matrix.T_Position_22 ->
   MAlonzo.Code.Implementations.Complex.T_ℂ'8321'_30) ->
  MAlonzo.Code.IO.Base.T_IO_20
d_show'45'flat'45'FFT'45'result_62 v0 v1 v2
  = coe
      MAlonzo.Code.IO.Finite.d_putStrLn_28 (coe v1)
      (coe
         d__'43''43'__32 ("FFT Result: " :: Data.Text.Text)
         (coe
            MAlonzo.Code.Matrix.Show.du_show_34
            (coe
               MAlonzo.Code.Matrix.C_ι_14
               (coe
                  MAlonzo.Code.Matrix.d_length_48
                  (coe
                     MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232
                     (coe v0))))
            (coe d_showℂ_34)
            (coe
               MAlonzo.Code.Matrix.Reshape.du_reshape_70
               (coe
                  MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232 (coe v0))
               (coe
                  MAlonzo.Code.Matrix.C_ι_14
                  (coe
                     MAlonzo.Code.Matrix.d_length_48
                     (coe
                        MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232
                        (coe v0))))
               (coe
                  MAlonzo.Code.Matrix.Reshape.d_rev_78
                  (coe
                     MAlonzo.Code.Matrix.C_ι_14
                     (coe
                        MAlonzo.Code.Matrix.d_length_48
                        (coe
                           MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232
                           (coe v0))))
                  (coe
                     MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232 (coe v0))
                  (coe
                     MAlonzo.Code.Matrix.Reshape.d_'9839'_292
                     (coe
                        MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232
                        (coe v0))))
               (coe
                  MAlonzo.Code.FFT.d_FFT_2674
                  (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
                  (coe
                     MAlonzo.Code.Implementations.Complex.d_complexImplementation_150
                     (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544))
                  (coe v0) (coe v2)))))
-- Implementations.FFT.show-flat-DFT-result
d_show'45'flat'45'DFT'45'result_64 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  (MAlonzo.Code.Matrix.T_Position_22 ->
   MAlonzo.Code.Implementations.Complex.T_ℂ'8321'_30) ->
  MAlonzo.Code.IO.Base.T_IO_20
d_show'45'flat'45'DFT'45'result_64 v0 v1 v2
  = coe
      MAlonzo.Code.IO.Finite.d_putStrLn_28 (coe v1)
      (coe
         d__'43''43'__32 ("DFT Result: " :: Data.Text.Text)
         (coe
            MAlonzo.Code.Matrix.Show.du_show_34
            (coe
               MAlonzo.Code.Matrix.C_ι_14
               (coe
                  MAlonzo.Code.Matrix.d_length_48
                  (coe
                     MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232
                     (coe v0))))
            (coe d_showℂ_34)
            (coe
               MAlonzo.Code.FFT.d_DFT_2650
               (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544)
               (coe
                  MAlonzo.Code.Implementations.Complex.d_complexImplementation_150
                  (coe MAlonzo.Code.Implementations.Real.d_realImplementation_2544))
               (coe
                  MAlonzo.Code.Matrix.d_length_48
                  (coe
                     MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232 (coe v0)))
               (coe
                  MAlonzo.Code.Matrix.Reshape.du_reshape_70 (coe v0)
                  (coe
                     MAlonzo.Code.Matrix.C_ι_14
                     (coe
                        MAlonzo.Code.Matrix.d_length_48
                        (coe
                           MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232
                           (coe v0))))
                  (coe MAlonzo.Code.Matrix.Reshape.d_flatten'45'reindex_338 (coe v0))
                  (coe v2)))))
-- Implementations.FFT.show-full-stack
d_show'45'full'45'stack_74 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  (MAlonzo.Code.Matrix.T_Position_22 ->
   MAlonzo.Code.Implementations.Complex.T_ℂ'8321'_30) ->
  MAlonzo.Code.IO.Base.T_IO_20
d_show'45'full'45'stack_74 v0 v1 v2
  = coe
      MAlonzo.Code.IO.Base.du__'62''62'__114
      (coe d_show'45'arr_58 (coe v0) (coe v1) (coe v2))
      (coe
         MAlonzo.Code.IO.Base.du__'62''62'__114
         (coe d_show'45'flat'45'arr_60 (coe v0) (coe v1) (coe v2))
         (coe
            MAlonzo.Code.IO.Base.du__'62''62'__114
            (coe d_show'45'flat'45'FFT'45'result_62 (coe v0) (coe v1) (coe v2))
            (coe
               d_show'45'flat'45'DFT'45'result_64 (coe v0) (coe v1) (coe v2))))
main = coe d_main_78
-- Implementations.FFT.main
d_main_78 ::
  MAlonzo.Code.Agda.Builtin.IO.T_IO_8
    AgdaAny MAlonzo.Code.Level.T_Lift_8
d_main_78
  = coe
      MAlonzo.Code.IO.Base.du_run_122 (coe MAlonzo.Code.Level.d_0ℓ_22)
      (coe
         d_show'45'full'45'stack_74
         (coe
            MAlonzo.Code.Matrix.C__'8855'__16
            (coe MAlonzo.Code.Matrix.C_ι_14 (coe (12 :: Integer)))
            (coe
               MAlonzo.Code.Matrix.C__'8855'__16
               (coe MAlonzo.Code.Matrix.C_ι_14 (coe (4 :: Integer)))
               (coe MAlonzo.Code.Matrix.C_ι_14 (coe (3 :: Integer)))))
         (coe MAlonzo.Code.Level.d_0ℓ_22) (coe d_demo'45'mat'8322'_50))
