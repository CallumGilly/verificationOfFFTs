{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wno-overlapping-patterns #-}

module MAlonzo.Code.Matrix.Sum where

import MAlonzo.RTE (coe, erased, AgdaAny, addInt, subInt, mulInt,
                    quotInt, remInt, geqInt, ltInt, eqInt, add64, sub64, mul64, quot64,
                    rem64, lt64, eq64, word64FromNat, word64ToNat)
import qualified MAlonzo.RTE
import qualified Data.Text
import qualified MAlonzo.Code.Agda.Builtin.Equality
import qualified MAlonzo.Code.Algebra.Structures
import qualified MAlonzo.Code.Data.Fin.Base
import qualified MAlonzo.Code.Matrix

-- Matrix.Sum._.LeftIdentity
d_LeftIdentity_82 ::
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  AgdaAny -> (AgdaAny -> AgdaAny -> AgdaAny) -> ()
d_LeftIdentity_82 = erased
-- Matrix.Sum._.RightIdentity
d_RightIdentity_112 ::
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  AgdaAny -> (AgdaAny -> AgdaAny -> AgdaAny) -> ()
d_RightIdentity_112 = erased
-- Matrix.Sum.identityˡ
d_identity'737'_150 ::
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  AgdaAny -> MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_150 = erased
-- Matrix.Sum.identityʳ
d_identity'691'_152 ::
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  AgdaAny -> MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_152 = erased
-- Matrix.Sum.sum
d_sum_160 ::
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) -> AgdaAny
d_sum_160 ~v0 v1 v2 ~v3 v4 v5 = du_sum_160 v1 v2 v4 v5
du_sum_160 ::
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) -> AgdaAny
du_sum_160 v0 v1 v2 v3
  = case coe v2 of
      0 -> coe v1
      _ -> let v4 = subInt (coe v2) (coe (1 :: Integer)) in
           coe
             (coe
                v0
                (coe
                   v3
                   (coe
                      MAlonzo.Code.Matrix.C_ι_24
                      (coe MAlonzo.Code.Data.Fin.Base.C_zero_12)))
                (coe
                   du_sum_160 (coe v0) (coe v1) (coe v4)
                   (coe MAlonzo.Code.Matrix.du_tail'8321'_96 (coe v3))))
-- Matrix.Sum.sum-nil
d_sum'45'nil_172 ::
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sum'45'nil_172 = erased
-- Matrix.Sum.sum-cong
d_sum'45'cong_182 ::
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  (MAlonzo.Code.Matrix.T_Position_22 ->
   MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12) ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sum'45'cong_182 = erased
-- Matrix.Sum.sum-reindex
d_sum'45'reindex_206 ::
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  Integer ->
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sum'45'reindex_206 = erased
-- Matrix.Sum.sum-zeros
d_sum'45'zeros_210 ::
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  Integer -> MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sum'45'zeros_210 = erased
-- Matrix.Sum.sum-distrib-tail₁
d_sum'45'distrib'45'tail'8321'_234 ::
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sum'45'distrib'45'tail'8321'_234 = erased
-- Matrix.Sum.split-sum
d_split'45'sum_252 ::
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  Integer ->
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_split'45'sum_252 = erased
-- Matrix.Sum.expand-sum
d_expand'45'sum_294 ::
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_expand'45'sum_294 = erased
-- Matrix.Sum.sum-swap
d_sum'45'swap_350 ::
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  Integer ->
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 ->
   MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sum'45'swap_350 = erased
-- Matrix.Sum.sum-swap-helperˡ
d_sum'45'swap'45'helper'737'_362 ::
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  Integer ->
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 ->
   MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sum'45'swap'45'helper'737'_362 = erased
-- Matrix.Sum.sum-swap-helperʳ
d_sum'45'swap'45'helper'691'_390 ::
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  Integer ->
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 ->
   MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sum'45'swap'45'helper'691'_390 = erased
-- Matrix.Sum.merge-sum
d_merge'45'sum_512 ::
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  Integer ->
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_merge'45'sum_512 = erased
-- Matrix.Sum.merge-sumₗ
d_merge'45'sum'8343'_518 ::
  () ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  AgdaAny ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  Integer ->
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_merge'45'sum'8343'_518 = erased
