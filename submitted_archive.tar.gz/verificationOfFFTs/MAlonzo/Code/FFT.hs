{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wno-overlapping-patterns #-}

module MAlonzo.Code.FFT where

import MAlonzo.RTE (coe, erased, AgdaAny, addInt, subInt, mulInt,
                    quotInt, remInt, geqInt, ltInt, eqInt, add64, sub64, mul64, quot64,
                    rem64, lt64, eq64, word64FromNat, word64ToNat)
import qualified MAlonzo.RTE
import qualified Data.Text
import qualified MAlonzo.Code.Complex
import qualified MAlonzo.Code.Data.Fin.Base
import qualified MAlonzo.Code.Data.Nat.Base
import qualified MAlonzo.Code.Data.Nat.Properties
import qualified MAlonzo.Code.Matrix
import qualified MAlonzo.Code.Matrix.NonZ90Zero
import qualified MAlonzo.Code.Matrix.Reshape
import qualified MAlonzo.Code.Matrix.Sum
import qualified MAlonzo.Code.Real
import qualified MAlonzo.Code.Relation.Nullary.Decidable.Core
import qualified MAlonzo.Code.Relation.Nullary.Reflects

-- FFT.iota
d_iota_2572 ::
  MAlonzo.Code.Real.T_Real_2 ->
  MAlonzo.Code.Complex.T_Cplx_14 ->
  Integer -> MAlonzo.Code.Matrix.T_Position_22 -> Integer
d_iota_2572 ~v0 ~v1 ~v2 v3 = du_iota_2572 v3
du_iota_2572 :: MAlonzo.Code.Matrix.T_Position_22 -> Integer
du_iota_2572 v0
  = case coe v0 of
      MAlonzo.Code.Matrix.C_ι_24 v2
        -> coe MAlonzo.Code.Data.Fin.Base.du_toℕ_18 (coe v2)
      _ -> MAlonzo.RTE.mazUnreachableError
-- FFT.offset-prod
d_offset'45'prod_2576 ::
  MAlonzo.Code.Real.T_Real_2 ->
  MAlonzo.Code.Complex.T_Cplx_14 ->
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Matrix.T_Position_22 -> Integer
d_offset'45'prod_2576 ~v0 ~v1 v2 v3 v4
  = du_offset'45'prod_2576 v2 v3 v4
du_offset'45'prod_2576 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Matrix.T_Position_22 -> Integer
du_offset'45'prod_2576 v0 v1 v2
  = case coe v2 of
      MAlonzo.Code.Matrix.C__'8855'__26 v5 v6
        -> coe
             mulInt
             (coe
                du_iota_2572
                (coe
                   MAlonzo.Code.Matrix.Reshape.d__'10216'_'10217'_38 (coe v0)
                   (coe
                      MAlonzo.Code.Matrix.C_ι_14
                      (coe MAlonzo.Code.Matrix.d_length_48 (coe v0)))
                   (coe v5) (coe MAlonzo.Code.Matrix.Reshape.d_'9839'_292 (coe v0))))
             (coe
                du_iota_2572
                (coe
                   MAlonzo.Code.Matrix.Reshape.d__'10216'_'10217'_38 (coe v1)
                   (coe
                      MAlonzo.Code.Matrix.C_ι_14
                      (coe MAlonzo.Code.Matrix.d_length_48 (coe v1)))
                   (coe v6) (coe MAlonzo.Code.Matrix.Reshape.d_'9839'_292 (coe v1))))
      _ -> MAlonzo.RTE.mazUnreachableError
-- FFT.twiddles
d_twiddles_2584 ::
  MAlonzo.Code.Real.T_Real_2 ->
  MAlonzo.Code.Complex.T_Cplx_14 ->
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Matrix.NonZ90Zero.T_NonZero'8347'_14 ->
  MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny
d_twiddles_2584 ~v0 v1 v2 v3 ~v4 v5 = du_twiddles_2584 v1 v2 v3 v5
du_twiddles_2584 ::
  MAlonzo.Code.Complex.T_Cplx_14 ->
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny
du_twiddles_2584 v0 v1 v2 v3
  = coe
      MAlonzo.Code.Complex.d_'45'ω_2772 v0
      (MAlonzo.Code.Matrix.d_length_48
         (coe MAlonzo.Code.Matrix.C__'8855'__16 (coe v1) (coe v2)))
      erased (coe du_offset'45'prod_2576 (coe v1) (coe v2) (coe v3))
-- FFT.DFT′
d_DFT'8242'_2598 ::
  MAlonzo.Code.Real.T_Real_2 ->
  MAlonzo.Code.Complex.T_Cplx_14 ->
  Integer ->
  MAlonzo.Code.Data.Nat.Base.T_NonZero_112 ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny
d_DFT'8242'_2598 v0 v1 v2 ~v3 v4 v5
  = du_DFT'8242'_2598 v0 v1 v2 v4 v5
du_DFT'8242'_2598 ::
  MAlonzo.Code.Real.T_Real_2 ->
  MAlonzo.Code.Complex.T_Cplx_14 ->
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny
du_DFT'8242'_2598 v0 v1 v2 v3 v4
  = coe
      MAlonzo.Code.Matrix.Sum.du_sum_160
      (coe MAlonzo.Code.Complex.d__'43'__2752 (coe v1))
      (coe MAlonzo.Code.Complex.d_0ℂ_2774 (coe v0) (coe v1)) (coe v2)
      (coe
         (\ v5 ->
            coe
              MAlonzo.Code.Complex.d__'42'__2758 v1 (coe v3 v5)
              (coe
                 MAlonzo.Code.Complex.d_'45'ω_2772 v1 v2 erased
                 (mulInt (coe du_iota_2572 (coe v5)) (coe du_iota_2572 (coe v4))))))
-- FFT.FFT′
d_FFT'8242'_2614 ::
  MAlonzo.Code.Real.T_Real_2 ->
  MAlonzo.Code.Complex.T_Cplx_14 ->
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Matrix.NonZ90Zero.T_NonZero'8347'_14 ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny
d_FFT'8242'_2614 v0 v1 v2 v3 v4
  = case coe v2 of
      MAlonzo.Code.Matrix.C_ι_14 v5
        -> coe
             seq (coe v3)
             (coe du_DFT'8242'_2598 (coe v0) (coe v1) (coe v5) (coe v4))
      MAlonzo.Code.Matrix.C__'8855'__16 v5 v6
        -> case coe v3 of
             MAlonzo.Code.Matrix.NonZ90Zero.C__'8855'__18 v9 v10
               -> coe
                    MAlonzo.Code.Matrix.Reshape.du_reshape_70
                    (coe
                       MAlonzo.Code.Matrix.C__'8855'__16
                       (coe
                          MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232 (coe v5))
                       (coe
                          MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232 (coe v6)))
                    (coe
                       MAlonzo.Code.Matrix.C__'8855'__16
                       (coe
                          MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232 (coe v6))
                       (coe
                          MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232 (coe v5)))
                    (coe MAlonzo.Code.Matrix.Reshape.C_swap_36)
                    (coe
                       MAlonzo.Code.Matrix.du_mapLeft_86
                       (coe d_FFT'8242'_2614 (coe v0) (coe v1) (coe v6) (coe v10))
                       (coe
                          MAlonzo.Code.Matrix.Reshape.du_reshape_70
                          (coe
                             MAlonzo.Code.Matrix.C__'8855'__16 (coe v6)
                             (coe
                                MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232 (coe v5)))
                          (coe
                             MAlonzo.Code.Matrix.C__'8855'__16
                             (coe
                                MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232 (coe v5))
                             (coe v6))
                          (coe MAlonzo.Code.Matrix.Reshape.C_swap_36)
                          (coe
                             MAlonzo.Code.Matrix.du_zipWith_156
                             (coe MAlonzo.Code.Complex.d__'42'__2758 (coe v1))
                             (coe
                                MAlonzo.Code.Matrix.du_mapLeft_86
                                (coe d_FFT'8242'_2614 (coe v0) (coe v1) (coe v5) (coe v9))
                                (coe
                                   MAlonzo.Code.Matrix.Reshape.du_reshape_70 (coe v2)
                                   (coe MAlonzo.Code.Matrix.C__'8855'__16 (coe v6) (coe v5))
                                   (coe MAlonzo.Code.Matrix.Reshape.C_swap_36) (coe v4)))
                             (coe
                                du_twiddles_2584 (coe v1) (coe v6)
                                (coe
                                   MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232
                                   (coe v5))))))
             _ -> MAlonzo.RTE.mazUnreachableError
      _ -> MAlonzo.RTE.mazUnreachableError
-- FFT.DFT
d_DFT_2650 ::
  MAlonzo.Code.Real.T_Real_2 ->
  MAlonzo.Code.Complex.T_Cplx_14 ->
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny
d_DFT_2650 v0 v1 v2 v3
  = let v4
          = MAlonzo.Code.Data.Nat.Properties.d_nonZero'63'_2674 (coe v2) in
    coe
      (case coe v4 of
         MAlonzo.Code.Relation.Nullary.Decidable.Core.C__because__32 v5 v6
           -> if coe v5
                then coe
                       seq (coe v6)
                       (coe du_DFT'8242'_2598 (coe v0) (coe v1) (coe v2) (coe v3))
                else coe seq (coe v6) (coe v3)
         _ -> MAlonzo.RTE.mazUnreachableError)
-- FFT.FFT
d_FFT_2674 ::
  MAlonzo.Code.Real.T_Real_2 ->
  MAlonzo.Code.Complex.T_Cplx_14 ->
  MAlonzo.Code.Matrix.T_Shape_12 ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny
d_FFT_2674 v0 v1 v2 v3
  = let v4
          = MAlonzo.Code.Matrix.NonZ90Zero.d_nonZeroDec_22 (coe v2) in
    coe
      (case coe v4 of
         MAlonzo.Code.Relation.Nullary.Decidable.Core.C__because__32 v5 v6
           -> if coe v5
                then case coe v6 of
                       MAlonzo.Code.Relation.Nullary.Reflects.C_of'696'_22 v7
                         -> coe
                              d_FFT'8242'_2614 (coe v0) (coe v1) (coe v2) (coe v7) (coe v3)
                       _ -> MAlonzo.RTE.mazUnreachableError
                else coe
                       seq (coe v6)
                       (coe
                          MAlonzo.Code.Matrix.Reshape.du_reshape_70 (coe v2)
                          (coe
                             MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose_232 (coe v2))
                          (coe
                             MAlonzo.Code.Matrix.Reshape.d_recursive'45'transpose'7523'_240
                             (coe v2))
                          (coe v3))
         _ -> MAlonzo.RTE.mazUnreachableError)
