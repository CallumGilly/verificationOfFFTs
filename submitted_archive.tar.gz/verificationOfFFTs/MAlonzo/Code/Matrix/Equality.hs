{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wno-overlapping-patterns #-}

module MAlonzo.Code.Matrix.Equality where

import MAlonzo.RTE (coe, erased, AgdaAny, addInt, subInt, mulInt,
                    quotInt, remInt, geqInt, ltInt, eqInt, add64, sub64, mul64, quot64,
                    rem64, lt64, eq64, word64FromNat, word64ToNat)
import qualified MAlonzo.RTE
import qualified Data.Text
import qualified MAlonzo.Code.Agda.Builtin.Equality
import qualified MAlonzo.Code.Matrix

-- Matrix.Equality._≅_
d__'8773'__14 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  () ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) -> ()
d__'8773'__14 = erased
-- Matrix.Equality.reduce-≅
d_reduce'45''8773'_28 ::
  Integer ->
  () ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  (MAlonzo.Code.Matrix.T_Position_22 ->
   MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12) ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reduce'45''8773'_28 = erased
-- Matrix.Equality.tail₁-cong
d_tail'8321''45'cong_50 ::
  Integer ->
  () ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  (MAlonzo.Code.Matrix.T_Position_22 ->
   MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12) ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_tail'8321''45'cong_50 = erased
