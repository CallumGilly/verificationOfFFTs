{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wno-overlapping-patterns #-}

module MAlonzo.Code.Function.Properties.RightInverse where

import MAlonzo.RTE (coe, erased, AgdaAny, addInt, subInt, mulInt,
                    quotInt, remInt, geqInt, ltInt, eqInt, add64, sub64, mul64, quot64,
                    rem64, lt64, eq64, word64FromNat, word64ToNat)
import qualified MAlonzo.RTE
import qualified Data.Text
import qualified MAlonzo.Code.Agda.Primitive
import qualified MAlonzo.Code.Function.Base
import qualified MAlonzo.Code.Function.Bundles
import qualified MAlonzo.Code.Function.Consequences
import qualified MAlonzo.Code.Function.Structures
import qualified MAlonzo.Code.Relation.Binary.Bundles
import qualified MAlonzo.Code.Relation.Binary.Structures

-- Function.Properties.RightInverse._.Eq₁._≈_
d__'8776'__44 ::
  T_GeneralizeTel_407 ->
  MAlonzo.Code.Function.Bundles.T_Equivalence_1810 ->
  AgdaAny -> AgdaAny -> ()
d__'8776'__44 = erased
-- Function.Properties.RightInverse._.Eq₂._≈_
d__'8776'__70 ::
  T_GeneralizeTel_407 ->
  MAlonzo.Code.Function.Bundles.T_Equivalence_1810 ->
  AgdaAny -> AgdaAny -> ()
d__'8776'__70 = erased
-- Function.Properties.RightInverse.mkRightInverse
d_mkRightInverse_94 ::
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44 ->
  MAlonzo.Code.Function.Bundles.T_Equivalence_1810 ->
  (AgdaAny -> AgdaAny -> AgdaAny -> AgdaAny) ->
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984
d_mkRightInverse_94 ~v0 ~v1 ~v2 ~v3 ~v4 ~v5 v6 v7
  = du_mkRightInverse_94 v6 v7
du_mkRightInverse_94 ::
  MAlonzo.Code.Function.Bundles.T_Equivalence_1810 ->
  (AgdaAny -> AgdaAny -> AgdaAny -> AgdaAny) ->
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984
du_mkRightInverse_94 v0 v1
  = coe
      MAlonzo.Code.Function.Bundles.C_RightInverse'46'constructor_35773
      (coe MAlonzo.Code.Function.Bundles.d_to_1820 (coe v0))
      (coe MAlonzo.Code.Function.Bundles.d_from_1822 (coe v0))
      (coe MAlonzo.Code.Function.Bundles.d_to'45'cong_1824 (coe v0))
      (coe MAlonzo.Code.Function.Bundles.d_from'45'cong_1826 (coe v0))
      (coe v1)
-- Function.Properties.RightInverse.RightInverse⇒LeftInverse
d_RightInverse'8658'LeftInverse_172 ::
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44 ->
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984 ->
  MAlonzo.Code.Function.Bundles.T_LeftInverse_1892
d_RightInverse'8658'LeftInverse_172 ~v0 ~v1 ~v2 ~v3 ~v4 ~v5 v6
  = du_RightInverse'8658'LeftInverse_172 v6
du_RightInverse'8658'LeftInverse_172 ::
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984 ->
  MAlonzo.Code.Function.Bundles.T_LeftInverse_1892
du_RightInverse'8658'LeftInverse_172 v0
  = coe
      MAlonzo.Code.Function.Bundles.C_LeftInverse'46'constructor_30891
      (coe MAlonzo.Code.Function.Bundles.d_from_1998 (coe v0))
      (coe MAlonzo.Code.Function.Bundles.d_to_1996 (coe v0))
      (coe MAlonzo.Code.Function.Bundles.d_from'45'cong_2002 (coe v0))
      (coe MAlonzo.Code.Function.Bundles.d_to'45'cong_2000 (coe v0))
      (coe MAlonzo.Code.Function.Bundles.d_inverse'691'_2004 (coe v0))
-- Function.Properties.RightInverse.LeftInverse⇒RightInverse
d_LeftInverse'8658'RightInverse_252 ::
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44 ->
  MAlonzo.Code.Function.Bundles.T_LeftInverse_1892 ->
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984
d_LeftInverse'8658'RightInverse_252 ~v0 ~v1 ~v2 ~v3 ~v4 ~v5 v6
  = du_LeftInverse'8658'RightInverse_252 v6
du_LeftInverse'8658'RightInverse_252 ::
  MAlonzo.Code.Function.Bundles.T_LeftInverse_1892 ->
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984
du_LeftInverse'8658'RightInverse_252 v0
  = coe
      MAlonzo.Code.Function.Bundles.C_RightInverse'46'constructor_35773
      (coe MAlonzo.Code.Function.Bundles.d_from_1906 (coe v0))
      (coe MAlonzo.Code.Function.Bundles.d_to_1904 (coe v0))
      (coe MAlonzo.Code.Function.Bundles.d_from'45'cong_1910 (coe v0))
      (coe MAlonzo.Code.Function.Bundles.d_to'45'cong_1908 (coe v0))
      (coe MAlonzo.Code.Function.Bundles.d_inverse'737'_1912 (coe v0))
-- Function.Properties.RightInverse.RightInverse⇒Surjection
d_RightInverse'8658'Surjection_338 ::
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44 ->
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984 ->
  MAlonzo.Code.Function.Bundles.T_Surjection_894
d_RightInverse'8658'Surjection_338 ~v0 ~v1 ~v2 ~v3 ~v4 ~v5 v6
  = du_RightInverse'8658'Surjection_338 v6
du_RightInverse'8658'Surjection_338 ::
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984 ->
  MAlonzo.Code.Function.Bundles.T_Surjection_894
du_RightInverse'8658'Surjection_338 v0
  = coe
      MAlonzo.Code.Function.Bundles.C_Surjection'46'constructor_11713
      (coe MAlonzo.Code.Function.Bundles.d_from_1998 (coe v0))
      (coe MAlonzo.Code.Function.Bundles.d_from'45'cong_2002 (coe v0))
      (coe
         MAlonzo.Code.Function.Consequences.du_inverse'737''8658'surjective_38
         (coe MAlonzo.Code.Function.Bundles.d_to_1996 (coe v0))
         (coe MAlonzo.Code.Function.Bundles.d_inverse'691'_2004 (coe v0)))
-- Function.Properties.RightInverse..generalizedField-S.a
d_'46'generalizedField'45'S'46'a_395 ::
  T_GeneralizeTel_407 -> MAlonzo.Code.Agda.Primitive.T_Level_18
d_'46'generalizedField'45'S'46'a_395 v0
  = case coe v0 of
      C_mkGeneralizeTel_409 v1 v2 v3 v4 v5 v6 -> coe v1
      _ -> MAlonzo.RTE.mazUnreachableError
-- Function.Properties.RightInverse..generalizedField-S.ℓ₁
d_'46'generalizedField'45'S'46'ℓ'8321'_397 ::
  T_GeneralizeTel_407 -> MAlonzo.Code.Agda.Primitive.T_Level_18
d_'46'generalizedField'45'S'46'ℓ'8321'_397 v0
  = case coe v0 of
      C_mkGeneralizeTel_409 v1 v2 v3 v4 v5 v6 -> coe v2
      _ -> MAlonzo.RTE.mazUnreachableError
-- Function.Properties.RightInverse..generalizedField-S
d_'46'generalizedField'45'S_399 ::
  T_GeneralizeTel_407 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_'46'generalizedField'45'S_399 v0
  = case coe v0 of
      C_mkGeneralizeTel_409 v1 v2 v3 v4 v5 v6 -> coe v3
      _ -> MAlonzo.RTE.mazUnreachableError
-- Function.Properties.RightInverse..generalizedField-T.a
d_'46'generalizedField'45'T'46'a_401 ::
  T_GeneralizeTel_407 -> MAlonzo.Code.Agda.Primitive.T_Level_18
d_'46'generalizedField'45'T'46'a_401 v0
  = case coe v0 of
      C_mkGeneralizeTel_409 v1 v2 v3 v4 v5 v6 -> coe v4
      _ -> MAlonzo.RTE.mazUnreachableError
-- Function.Properties.RightInverse..generalizedField-T.ℓ₁
d_'46'generalizedField'45'T'46'ℓ'8321'_403 ::
  T_GeneralizeTel_407 -> MAlonzo.Code.Agda.Primitive.T_Level_18
d_'46'generalizedField'45'T'46'ℓ'8321'_403 v0
  = case coe v0 of
      C_mkGeneralizeTel_409 v1 v2 v3 v4 v5 v6 -> coe v5
      _ -> MAlonzo.RTE.mazUnreachableError
-- Function.Properties.RightInverse..generalizedField-T
d_'46'generalizedField'45'T_405 ::
  T_GeneralizeTel_407 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_'46'generalizedField'45'T_405 v0
  = case coe v0 of
      C_mkGeneralizeTel_409 v1 v2 v3 v4 v5 v6 -> coe v6
      _ -> MAlonzo.RTE.mazUnreachableError
-- Function.Properties.RightInverse.GeneralizeTel
d_GeneralizeTel_407 = ()
data T_GeneralizeTel_407
  = C_mkGeneralizeTel_409 MAlonzo.Code.Agda.Primitive.T_Level_18
                          MAlonzo.Code.Agda.Primitive.T_Level_18
                          MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
                          MAlonzo.Code.Agda.Primitive.T_Level_18
                          MAlonzo.Code.Agda.Primitive.T_Level_18
                          MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
-- Function.Properties.RightInverse.↪⇒↠
d_'8618''8658''8608'_418 ::
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  () ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  () ->
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984 ->
  MAlonzo.Code.Function.Bundles.T_Surjection_894
d_'8618''8658''8608'_418 ~v0 ~v1 ~v2 ~v3
  = du_'8618''8658''8608'_418
du_'8618''8658''8608'_418 ::
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984 ->
  MAlonzo.Code.Function.Bundles.T_Surjection_894
du_'8618''8658''8608'_418 = coe du_RightInverse'8658'Surjection_338
-- Function.Properties.RightInverse.↪⇒↩
d_'8618''8658''8617'_420 ::
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  () ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  () ->
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984 ->
  MAlonzo.Code.Function.Bundles.T_LeftInverse_1892
d_'8618''8658''8617'_420 ~v0 ~v1 ~v2 ~v3
  = du_'8618''8658''8617'_420
du_'8618''8658''8617'_420 ::
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984 ->
  MAlonzo.Code.Function.Bundles.T_LeftInverse_1892
du_'8618''8658''8617'_420
  = coe du_RightInverse'8658'LeftInverse_172
-- Function.Properties.RightInverse.↩⇒↪
d_'8617''8658''8618'_422 ::
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  () ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  () ->
  MAlonzo.Code.Function.Bundles.T_LeftInverse_1892 ->
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984
d_'8617''8658''8618'_422 ~v0 ~v1 ~v2 ~v3
  = du_'8617''8658''8618'_422
du_'8617''8658''8618'_422 ::
  MAlonzo.Code.Function.Bundles.T_LeftInverse_1892 ->
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984
du_'8617''8658''8618'_422
  = coe du_LeftInverse'8658'RightInverse_252
-- Function.Properties.RightInverse._._.Eq₁._≈_
d__'8776'__456 ::
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44 ->
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984 ->
  AgdaAny -> AgdaAny -> ()
d__'8776'__456 = erased
-- Function.Properties.RightInverse._._.Eq₂._≈_
d__'8776'__482 ::
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44 ->
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984 ->
  AgdaAny -> AgdaAny -> ()
d__'8776'__482 = erased
-- Function.Properties.RightInverse._.to-from
d_to'45'from_510 ::
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Agda.Primitive.T_Level_18 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44 ->
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984 ->
  AgdaAny -> AgdaAny -> AgdaAny -> AgdaAny
d_to'45'from_510 ~v0 ~v1 v2 ~v3 ~v4 v5 v6 v7 v8 v9
  = du_to'45'from_510 v2 v5 v6 v7 v8 v9
du_to'45'from_510 ::
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44 ->
  MAlonzo.Code.Function.Bundles.T_RightInverse_1984 ->
  AgdaAny -> AgdaAny -> AgdaAny -> AgdaAny
du_to'45'from_510 v0 v1 v2 v3 v4 v5
  = let v6
          = coe
              MAlonzo.Code.Function.Bundles.du_isRightInverse_2008 (coe v0)
              (coe v1) (coe v2) in
    coe
      (let v7
             = MAlonzo.Code.Function.Structures.d_isCongruent_440 (coe v6) in
       coe
         (let v8
                = coe MAlonzo.Code.Function.Structures.du_setoid_40 (coe v7) in
          coe
            (coe
               MAlonzo.Code.Relation.Binary.Structures.d_trans_38
               (MAlonzo.Code.Relation.Binary.Bundles.d_isEquivalence_60 (coe v8))
               (coe
                  MAlonzo.Code.Function.Base.du__'45''10216'_'8739'_292
                  (MAlonzo.Code.Function.Bundles.d_from_1998 (coe v2))
                  (\ v9 v10 -> v9) v4
                  (coe MAlonzo.Code.Function.Bundles.d_to_1996 v2 v3))
               (coe
                  MAlonzo.Code.Function.Base.du_'8739'_'10217''45'__298
                  (\ v9 v10 -> v10)
                  (MAlonzo.Code.Function.Bundles.d_from_1998 (coe v2)) v4
                  (coe MAlonzo.Code.Function.Bundles.d_to_1996 v2 v3))
               v3
               (coe
                  MAlonzo.Code.Function.Bundles.d_from'45'cong_2002 v2 v4
                  (coe MAlonzo.Code.Function.Bundles.d_to_1996 v2 v3)
                  (let v9
                         = coe
                             MAlonzo.Code.Function.Bundles.du_isRightInverse_2008 (coe v0)
                             (coe v1) (coe v2) in
                   coe
                     (let v10
                            = MAlonzo.Code.Function.Structures.d_isCongruent_440 (coe v9) in
                      coe
                        (let v11
                               = coe MAlonzo.Code.Function.Structures.du_setoid_68 (coe v10) in
                         coe
                           (coe
                              MAlonzo.Code.Relation.Binary.Structures.d_sym_36
                              (MAlonzo.Code.Relation.Binary.Bundles.d_isEquivalence_60 (coe v11))
                              (coe MAlonzo.Code.Function.Bundles.d_to_1996 v2 v3) v4 v5)))))
               (coe
                  MAlonzo.Code.Function.Structures.du_strictlyInverse'691'_506
                  (coe MAlonzo.Code.Function.Bundles.d_to_1996 (coe v2))
                  (coe
                     MAlonzo.Code.Function.Bundles.du_isRightInverse_2008 (coe v0)
                     (coe v1) (coe v2))
                  (coe v3)))))
