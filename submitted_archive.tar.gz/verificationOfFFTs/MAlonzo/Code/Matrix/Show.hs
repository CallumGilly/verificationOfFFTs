{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wno-overlapping-patterns #-}

module MAlonzo.Code.Matrix.Show where

import MAlonzo.RTE (coe, erased, AgdaAny, addInt, subInt, mulInt,
                    quotInt, remInt, geqInt, ltInt, eqInt, add64, sub64, mul64, quot64,
                    rem64, lt64, eq64, word64FromNat, word64ToNat)
import qualified MAlonzo.RTE
import qualified Data.Text
import qualified MAlonzo.Code.Agda.Builtin.String
import qualified MAlonzo.Code.Data.Fin.Base
import qualified MAlonzo.Code.Data.Nat.Show
import qualified MAlonzo.Code.Matrix

-- Matrix.Show._++_
d__'43''43'__4 ::
  MAlonzo.Code.Agda.Builtin.String.T_String_6 ->
  MAlonzo.Code.Agda.Builtin.String.T_String_6 ->
  MAlonzo.Code.Agda.Builtin.String.T_String_6
d__'43''43'__4
  = coe MAlonzo.Code.Agda.Builtin.String.d_primStringAppend_16
-- Matrix.Show.id
d_id_6 ::
  MAlonzo.Code.Agda.Builtin.String.T_String_6 ->
  MAlonzo.Code.Agda.Builtin.String.T_String_6
d_id_6 v0 = coe v0
-- Matrix.Show.flipArr
d_flipArr_14 ::
  Integer ->
  () ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny
d_flipArr_14 v0 ~v1 v2 v3 = du_flipArr_14 v0 v2 v3
du_flipArr_14 ::
  Integer ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny
du_flipArr_14 v0 v1 v2
  = case coe v2 of
      MAlonzo.Code.Matrix.C_ι_24 v4
        -> coe
             v1
             (coe
                MAlonzo.Code.Matrix.C_ι_24
                (MAlonzo.Code.Data.Fin.Base.d_opposite_370 (coe v0) (coe v4)))
      _ -> MAlonzo.RTE.mazUnreachableError
-- Matrix.Show.showShape
d_showShape_22 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  MAlonzo.Code.Agda.Builtin.String.T_String_6
d_showShape_22 v0
  = case coe v0 of
      MAlonzo.Code.Matrix.C_ι_14 v1
        -> coe
             d__'43''43'__4 ("\953 " :: Data.Text.Text)
             (coe MAlonzo.Code.Data.Nat.Show.d_show_56 v1)
      MAlonzo.Code.Matrix.C__'8855'__16 v1 v2
        -> coe
             d__'43''43'__4 ("[" :: Data.Text.Text)
             (coe
                d__'43''43'__4 (d_showShape_22 (coe v1))
                (coe
                   d__'43''43'__4 ("] \8855 [" :: Data.Text.Text)
                   (coe
                      d__'43''43'__4 (d_showShape_22 (coe v2)) ("]" :: Data.Text.Text))))
      _ -> MAlonzo.RTE.mazUnreachableError
-- Matrix.Show.show
d_show_34 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  () ->
  (AgdaAny -> MAlonzo.Code.Agda.Builtin.String.T_String_6) ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Agda.Builtin.String.T_String_6
d_show_34 v0 ~v1 v2 v3 = du_show_34 v0 v2 v3
du_show_34 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  (AgdaAny -> MAlonzo.Code.Agda.Builtin.String.T_String_6) ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Agda.Builtin.String.T_String_6
du_show_34 v0 v1 v2
  = case coe v0 of
      MAlonzo.Code.Matrix.C_ι_14 v3
        -> case coe v3 of
             0 -> coe
                    d__'43''43'__4 ("[" :: Data.Text.Text) ("]" :: Data.Text.Text)
             _ -> let v4 = subInt (coe v3) (coe (1 :: Integer)) in
                  coe
                    (coe
                       d__'43''43'__4
                       (coe
                          d__'43''43'__4 ("[" :: Data.Text.Text)
                          (coe
                             MAlonzo.Code.Matrix.du_foldr_132 (coe v4)
                             (coe
                                (\ v5 v6 ->
                                   coe
                                     d__'43''43'__4 v6
                                     (coe
                                        d__'43''43'__4
                                        (coe
                                           d__'43''43'__4
                                           (coe
                                              d__'43''43'__4 (", " :: Data.Text.Text)
                                              ("(" :: Data.Text.Text))
                                           (coe v1 v5))
                                        (")" :: Data.Text.Text))))
                             (coe
                                d__'43''43'__4
                                (coe
                                   d__'43''43'__4 ("(" :: Data.Text.Text)
                                   (coe v1 (coe MAlonzo.Code.Matrix.du_head'8321'_92 (coe v2))))
                                (")" :: Data.Text.Text))
                             (coe MAlonzo.Code.Matrix.du_tail'8321'_96 (coe v2))))
                       ("]" :: Data.Text.Text))
      MAlonzo.Code.Matrix.C__'8855'__16 v3 v4
        -> coe
             du_show_34 (coe v3) (coe (\ v5 -> v5))
             (coe
                MAlonzo.Code.Matrix.du_map_56 (coe du_show_34 (coe v4) (coe v1))
                (coe MAlonzo.Code.Matrix.du_nest_64 (coe v2)))
      _ -> MAlonzo.RTE.mazUnreachableError
