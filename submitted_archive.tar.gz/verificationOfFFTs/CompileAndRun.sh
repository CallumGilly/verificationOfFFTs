agda --compile Implementations/FFT.agda 1> /dev/null && ./FFT
