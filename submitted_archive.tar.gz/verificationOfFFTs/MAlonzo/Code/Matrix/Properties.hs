{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wno-overlapping-patterns #-}

module MAlonzo.Code.Matrix.Properties where

import MAlonzo.RTE (coe, erased, AgdaAny, addInt, subInt, mulInt,
                    quotInt, remInt, geqInt, ltInt, eqInt, add64, sub64, mul64, quot64,
                    rem64, lt64, eq64, word64FromNat, word64ToNat)
import qualified MAlonzo.RTE
import qualified Data.Text
import qualified MAlonzo.Code.Agda.Builtin.Equality
import qualified MAlonzo.Code.Matrix

-- Matrix.Properties.tail₁-const
d_tail'8321''45'const_20 ::
  () ->
  Integer ->
  AgdaAny ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_tail'8321''45'const_20 = erased
-- Matrix.Properties.splitArᵣ-zero
d_splitAr'7523''45'zero_26 ::
  Integer ->
  () ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_splitAr'7523''45'zero_26 = erased
-- Matrix.Properties.splitArₗ-zero
d_splitAr'8343''45'zero_34 ::
  Integer ->
  () ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_splitAr'8343''45'zero_34 = erased
-- Matrix.Properties.zipWith-congˡ
d_zipWith'45'cong'737'_46 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  () ->
  () ->
  () ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  (MAlonzo.Code.Matrix.T_Position_22 ->
   MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12) ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zipWith'45'cong'737'_46 = erased
-- Matrix.Properties.zipWith-congʳ
d_zipWith'45'cong'691'_62 ::
  MAlonzo.Code.Matrix.T_Shape_12 ->
  () ->
  () ->
  () ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  (MAlonzo.Code.Matrix.T_Position_22 -> AgdaAny) ->
  (AgdaAny -> AgdaAny -> AgdaAny) ->
  (MAlonzo.Code.Matrix.T_Position_22 ->
   MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12) ->
  MAlonzo.Code.Matrix.T_Position_22 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zipWith'45'cong'691'_62 = erased
-- Matrix.Properties.mapMap
d_mapMap_74 ::
  () ->
  () ->
  () ->
  MAlonzo.Code.Matrix.T_Shape_12 ->
  (AgdaAny -> AgdaAny) ->
  (AgdaAny -> AgdaAny) ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_mapMap_74 = erased
