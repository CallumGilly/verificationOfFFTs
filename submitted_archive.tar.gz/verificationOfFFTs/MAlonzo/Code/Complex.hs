{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wno-overlapping-patterns #-}

module MAlonzo.Code.Complex where

import MAlonzo.RTE (coe, erased, AgdaAny, addInt, subInt, mulInt,
                    quotInt, remInt, geqInt, ltInt, eqInt, add64, sub64, mul64, quot64,
                    rem64, lt64, eq64, word64FromNat, word64ToNat)
import qualified MAlonzo.RTE
import qualified Data.Text
import qualified MAlonzo.Code.Agda.Builtin.Equality
import qualified MAlonzo.Code.Algebra.Structures
import qualified MAlonzo.Code.Data.Nat.Base
import qualified MAlonzo.Code.Real

-- Complex._.0ℝ
d_0ℝ_8 :: MAlonzo.Code.Real.T_Real_2 -> AgdaAny
d_0ℝ_8 v0 = coe MAlonzo.Code.Real.d_0ℝ_2718 (coe v0)
-- Complex._.1ℝ
d_1ℝ_10 :: MAlonzo.Code.Real.T_Real_2 -> AgdaAny
d_1ℝ_10 v0 = coe MAlonzo.Code.Real.d_1ℝ_2722 (coe v0)
-- Complex.Cplx
d_Cplx_14 a0 = ()
data T_Cplx_14
  = C_Cplx'46'constructor_40271 (AgdaAny -> AgdaAny -> AgdaAny)
                                (AgdaAny -> AgdaAny -> AgdaAny) (AgdaAny -> AgdaAny)
                                (AgdaAny -> AgdaAny -> AgdaAny) (AgdaAny -> AgdaAny)
                                (AgdaAny -> AgdaAny) (AgdaAny -> AgdaAny)
                                (Integer ->
                                 MAlonzo.Code.Data.Nat.Base.T_NonZero_112 -> Integer -> AgdaAny)
                                MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818
-- Complex._.IsCommutativeRing
d_IsCommutativeRing_62 a0 a1 a2 a3 a4 a5 a6 a7 a8 a9 a10 a11 a12
                       a13 a14
  = ()
-- Complex._.IsCommutativeRing.*-comm
d_'42''45'comm_476 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  AgdaAny ->
  AgdaAny -> MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'comm_476 = erased
-- Complex._.IsCommutativeRing.isRing
d_isRing_564 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672
d_isRing_564 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0)
-- Complex.Cplx.ℂ
d_ℂ_2750 :: T_Cplx_14 -> ()
d_ℂ_2750 = erased
-- Complex.Cplx._+_
d__'43'__2752 :: T_Cplx_14 -> AgdaAny -> AgdaAny -> AgdaAny
d__'43'__2752 v0
  = case coe v0 of
      C_Cplx'46'constructor_40271 v2 v3 v4 v5 v6 v7 v8 v9 v10 -> coe v2
      _ -> MAlonzo.RTE.mazUnreachableError
-- Complex.Cplx._-_
d__'45'__2754 :: T_Cplx_14 -> AgdaAny -> AgdaAny -> AgdaAny
d__'45'__2754 v0
  = case coe v0 of
      C_Cplx'46'constructor_40271 v2 v3 v4 v5 v6 v7 v8 v9 v10 -> coe v3
      _ -> MAlonzo.RTE.mazUnreachableError
-- Complex.Cplx.-_
d_'45'__2756 :: T_Cplx_14 -> AgdaAny -> AgdaAny
d_'45'__2756 v0
  = case coe v0 of
      C_Cplx'46'constructor_40271 v2 v3 v4 v5 v6 v7 v8 v9 v10 -> coe v4
      _ -> MAlonzo.RTE.mazUnreachableError
-- Complex.Cplx._*_
d__'42'__2758 :: T_Cplx_14 -> AgdaAny -> AgdaAny -> AgdaAny
d__'42'__2758 v0
  = case coe v0 of
      C_Cplx'46'constructor_40271 v2 v3 v4 v5 v6 v7 v8 v9 v10 -> coe v5
      _ -> MAlonzo.RTE.mazUnreachableError
-- Complex.Cplx.fromℝ
d_fromℝ_2760 :: T_Cplx_14 -> AgdaAny -> AgdaAny
d_fromℝ_2760 v0
  = case coe v0 of
      C_Cplx'46'constructor_40271 v2 v3 v4 v5 v6 v7 v8 v9 v10 -> coe v6
      _ -> MAlonzo.RTE.mazUnreachableError
-- Complex.Cplx.e^i_
d_e'94'i__2762 :: T_Cplx_14 -> AgdaAny -> AgdaAny
d_e'94'i__2762 v0
  = case coe v0 of
      C_Cplx'46'constructor_40271 v2 v3 v4 v5 v6 v7 v8 v9 v10 -> coe v7
      _ -> MAlonzo.RTE.mazUnreachableError
-- Complex.Cplx.ℂ-conjugate
d_ℂ'45'conjugate_2764 :: T_Cplx_14 -> AgdaAny -> AgdaAny
d_ℂ'45'conjugate_2764 v0
  = case coe v0 of
      C_Cplx'46'constructor_40271 v2 v3 v4 v5 v6 v7 v8 v9 v10 -> coe v8
      _ -> MAlonzo.RTE.mazUnreachableError
-- Complex.Cplx.-ω
d_'45'ω_2772 ::
  T_Cplx_14 ->
  Integer ->
  MAlonzo.Code.Data.Nat.Base.T_NonZero_112 -> Integer -> AgdaAny
d_'45'ω_2772 v0
  = case coe v0 of
      C_Cplx'46'constructor_40271 v2 v3 v4 v5 v6 v7 v8 v9 v10 -> coe v9
      _ -> MAlonzo.RTE.mazUnreachableError
-- Complex.Cplx.0ℂ
d_0ℂ_2774 :: MAlonzo.Code.Real.T_Real_2 -> T_Cplx_14 -> AgdaAny
d_0ℂ_2774 v0 v1
  = coe d_fromℝ_2760 v1 (MAlonzo.Code.Real.d_0ℝ_2718 (coe v0))
-- Complex.Cplx.-1ℂ
d_'45'1ℂ_2776 :: MAlonzo.Code.Real.T_Real_2 -> T_Cplx_14 -> AgdaAny
d_'45'1ℂ_2776 v0 v1
  = coe d_fromℝ_2760 v1 (MAlonzo.Code.Real.d_'45'1ℝ_2720 (coe v0))
-- Complex.Cplx.1ℂ
d_1ℂ_2778 :: MAlonzo.Code.Real.T_Real_2 -> T_Cplx_14 -> AgdaAny
d_1ℂ_2778 v0 v1
  = coe d_fromℝ_2760 v1 (MAlonzo.Code.Real.d_1ℝ_2722 (coe v0))
-- Complex.Cplx.+-*-isCommutativeRing
d_'43''45''42''45'isCommutativeRing_5446 ::
  T_Cplx_14 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818
d_'43''45''42''45'isCommutativeRing_5446 v0
  = case coe v0 of
      C_Cplx'46'constructor_40271 v2 v3 v4 v5 v6 v7 v8 v9 v10 -> coe v10
      _ -> MAlonzo.RTE.mazUnreachableError
-- Complex.Cplx.ω-N-0
d_ω'45'N'45'0_5452 ::
  T_Cplx_14 ->
  Integer ->
  MAlonzo.Code.Data.Nat.Base.T_NonZero_112 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_ω'45'N'45'0_5452 = erased
-- Complex.Cplx.ω-N-mN
d_ω'45'N'45'mN_5460 ::
  T_Cplx_14 ->
  Integer ->
  Integer ->
  MAlonzo.Code.Data.Nat.Base.T_NonZero_112 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_ω'45'N'45'mN_5460 = erased
-- Complex.Cplx.ω-r₁x-r₁y
d_ω'45'r'8321'x'45'r'8321'y_5472 ::
  T_Cplx_14 ->
  Integer ->
  Integer ->
  Integer ->
  MAlonzo.Code.Data.Nat.Base.T_NonZero_112 ->
  MAlonzo.Code.Data.Nat.Base.T_NonZero_112 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_ω'45'r'8321'x'45'r'8321'y_5472 = erased
-- Complex.Cplx.ω-N-k₀+k₁
d_ω'45'N'45'k'8320''43'k'8321'_5482 ::
  T_Cplx_14 ->
  Integer ->
  Integer ->
  Integer ->
  MAlonzo.Code.Data.Nat.Base.T_NonZero_112 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_ω'45'N'45'k'8320''43'k'8321'_5482 = erased
