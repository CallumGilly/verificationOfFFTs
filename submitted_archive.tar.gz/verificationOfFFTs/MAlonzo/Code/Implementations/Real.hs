{-# LANGUAGE BangPatterns #-}
{-# LANGUAGE EmptyCase #-}
{-# LANGUAGE EmptyDataDecls #-}
{-# LANGUAGE ExistentialQuantification #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE PatternSynonyms #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}

{-# OPTIONS_GHC -Wno-overlapping-patterns #-}

module MAlonzo.Code.Implementations.Real where

import MAlonzo.RTE (coe, erased, AgdaAny, addInt, subInt, mulInt,
                    quotInt, remInt, geqInt, ltInt, eqInt, add64, sub64, mul64, quot64,
                    rem64, lt64, eq64, word64FromNat, word64ToNat)
import qualified MAlonzo.RTE
import qualified Data.Text
import qualified MAlonzo.Code.Agda.Builtin.Equality
import qualified MAlonzo.Code.Agda.Builtin.Float
import qualified MAlonzo.Code.Agda.Builtin.Sigma
import qualified MAlonzo.Code.Agda.Builtin.String
import qualified MAlonzo.Code.Algebra.Structures
import qualified MAlonzo.Code.Data.Irrelevant
import qualified MAlonzo.Code.Data.Sum.Base
import qualified MAlonzo.Code.Real
import qualified MAlonzo.Code.Relation.Binary.Bundles
import qualified MAlonzo.Code.Relation.Binary.Structures

-- _.IsAbelianGroup
d_IsAbelianGroup_6 a0 a1 a2 = ()
-- _.IsAlternativeMagma
d_IsAlternativeMagma_8 a0 = ()
-- _.IsBand
d_IsBand_10 a0 = ()
-- _.IsCancellativeCommutativeSemiring
d_IsCancellativeCommutativeSemiring_12 a0 a1 a2 a3 = ()
-- _.IsCommutativeBand
d_IsCommutativeBand_14 a0 = ()
-- _.IsCommutativeMagma
d_IsCommutativeMagma_16 a0 = ()
-- _.IsCommutativeMonoid
d_IsCommutativeMonoid_18 a0 a1 = ()
-- _.IsCommutativeRing
d_IsCommutativeRing_20 a0 a1 a2 a3 a4 = ()
-- _.IsCommutativeSemigroup
d_IsCommutativeSemigroup_22 a0 = ()
-- _.IsCommutativeSemiring
d_IsCommutativeSemiring_24 a0 a1 a2 a3 = ()
-- _.IsCommutativeSemiringWithoutOne
d_IsCommutativeSemiringWithoutOne_26 a0 a1 a2 = ()
-- _.IsFlexibleMagma
d_IsFlexibleMagma_28 a0 = ()
-- _.IsGroup
d_IsGroup_30 a0 a1 a2 = ()
-- _.IsIdempotentCommutativeMonoid
d_IsIdempotentCommutativeMonoid_32 a0 a1 = ()
-- _.IsIdempotentMagma
d_IsIdempotentMagma_34 a0 = ()
-- _.IsIdempotentMonoid
d_IsIdempotentMonoid_36 a0 a1 = ()
-- _.IsIdempotentSemiring
d_IsIdempotentSemiring_38 a0 a1 a2 a3 = ()
-- _.IsInvertibleMagma
d_IsInvertibleMagma_40 a0 a1 a2 = ()
-- _.IsInvertibleUnitalMagma
d_IsInvertibleUnitalMagma_42 a0 a1 a2 = ()
-- _.IsKleeneAlgebra
d_IsKleeneAlgebra_44 a0 a1 a2 a3 a4 = ()
-- _.IsLeftBolLoop
d_IsLeftBolLoop_46 a0 a1 a2 a3 = ()
-- _.IsLoop
d_IsLoop_48 a0 a1 a2 a3 = ()
-- _.IsMagma
d_IsMagma_50 a0 = ()
-- _.IsMedialMagma
d_IsMedialMagma_52 a0 = ()
-- _.IsMiddleBolLoop
d_IsMiddleBolLoop_54 a0 a1 a2 a3 = ()
-- _.IsMonoid
d_IsMonoid_56 a0 a1 = ()
-- _.IsMoufangLoop
d_IsMoufangLoop_58 a0 a1 a2 a3 = ()
-- _.IsNearSemiring
d_IsNearSemiring_60 a0 a1 a2 = ()
-- _.IsNearring
d_IsNearring_62 a0 a1 a2 a3 a4 = ()
-- _.IsNonAssociativeRing
d_IsNonAssociativeRing_64 a0 a1 a2 a3 a4 = ()
-- _.IsQuasigroup
d_IsQuasigroup_66 a0 a1 a2 = ()
-- _.IsQuasiring
d_IsQuasiring_68 a0 a1 a2 a3 = ()
-- _.IsRightBolLoop
d_IsRightBolLoop_70 a0 a1 a2 a3 = ()
-- _.IsRing
d_IsRing_72 a0 a1 a2 a3 a4 = ()
-- _.IsRingWithoutOne
d_IsRingWithoutOne_74 a0 a1 a2 a3 = ()
-- _.IsSelectiveMagma
d_IsSelectiveMagma_76 a0 = ()
-- _.IsSemigroup
d_IsSemigroup_78 a0 = ()
-- _.IsSemimedialMagma
d_IsSemimedialMagma_80 a0 = ()
-- _.IsSemiring
d_IsSemiring_82 a0 a1 a2 a3 = ()
-- _.IsSemiringWithoutAnnihilatingZero
d_IsSemiringWithoutAnnihilatingZero_84 a0 a1 a2 a3 = ()
-- _.IsSemiringWithoutOne
d_IsSemiringWithoutOne_86 a0 a1 a2 = ()
-- _.IsSuccessorSet
d_IsSuccessorSet_88 a0 a1 = ()
-- _.IsUnitalMagma
d_IsUnitalMagma_90 a0 a1 = ()
-- _.IsAbelianGroup._//_
d__'47''47'__94 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d__'47''47'__94 v0 ~v1 v2 ~v3 = du__'47''47'__94 v0 v2
du__'47''47'__94 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
du__'47''47'__94 v0 v1
  = coe
      MAlonzo.Code.Algebra.Structures.du__'47''47'__1098 (coe v0)
      (coe v1)
-- _.IsAbelianGroup.assoc
d_assoc_96 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_96 = erased
-- _.IsAbelianGroup.comm
d_comm_98 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_98 = erased
-- _.IsAbelianGroup.identity
d_identity_100 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_100 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
         (coe MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v0)))
-- _.IsAbelianGroup.identityʳ
d_identity'691'_102 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_102 = erased
-- _.IsAbelianGroup.identityˡ
d_identity'737'_104 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_104 = erased
-- _.IsAbelianGroup.inverse
d_inverse_106 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_inverse_106 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_inverse_1052
      (coe MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v0))
-- _.IsAbelianGroup.inverseʳ
d_inverse'691'_108 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_inverse'691'_108 = erased
-- _.IsAbelianGroup.inverseˡ
d_inverse'737'_110 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_inverse'737'_110 = erased
-- _.IsAbelianGroup.isCommutativeMagma
d_isCommutativeMagma_112 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_112 ~v0 ~v1 ~v2 v3
  = du_isCommutativeMagma_112 v3
du_isCommutativeMagma_112 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_112 v0
  = let v1
          = coe
              MAlonzo.Code.Algebra.Structures.du_isCommutativeMonoid_1204
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
            (coe v1)))
-- _.IsAbelianGroup.isCommutativeMonoid
d_isCommutativeMonoid_114 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
d_isCommutativeMonoid_114 v0 v1 v2 v3
  = coe
      MAlonzo.Code.Algebra.Structures.du_isCommutativeMonoid_1204 v3
-- _.IsAbelianGroup.isCommutativeSemigroup
d_isCommutativeSemigroup_116 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_isCommutativeSemigroup_116 ~v0 ~v1 ~v2 v3
  = du_isCommutativeSemigroup_116 v3
du_isCommutativeSemigroup_116 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
du_isCommutativeSemigroup_116 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
      (coe
         MAlonzo.Code.Algebra.Structures.du_isCommutativeMonoid_1204
         (coe v0))
-- _.IsAbelianGroup.isEquivalence
d_isEquivalence_118 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_118 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe
               MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
               (coe MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v0)))))
-- _.IsAbelianGroup.isGroup
d_isGroup_120 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036
d_isGroup_120 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v0)
-- _.IsAbelianGroup.isInvertibleMagma
d_isInvertibleMagma_122 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924
d_isInvertibleMagma_122 ~v0 ~v1 ~v2 v3
  = du_isInvertibleMagma_122 v3
du_isInvertibleMagma_122 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924
du_isInvertibleMagma_122 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isInvertibleMagma_1122
      (coe MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v0))
-- _.IsAbelianGroup.isInvertibleUnitalMagma
d_isInvertibleUnitalMagma_124 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976
d_isInvertibleUnitalMagma_124 ~v0 ~v1 ~v2 v3
  = du_isInvertibleUnitalMagma_124 v3
du_isInvertibleUnitalMagma_124 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976
du_isInvertibleUnitalMagma_124 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isInvertibleUnitalMagma_1124
      (coe MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v0))
-- _.IsAbelianGroup.isMagma
d_isMagma_126 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_126 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe
            MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
            (coe MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v0))))
-- _.IsAbelianGroup.isMonoid
d_isMonoid_128 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_isMonoid_128 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
      (coe MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v0))
-- _.IsAbelianGroup.isPartialEquivalence
d_isPartialEquivalence_130 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_130 ~v0 ~v1 ~v2 v3
  = du_isPartialEquivalence_130 v3
du_isPartialEquivalence_130 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_130 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v2) in
          coe
            (let v4 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v3) in
             coe
               (coe
                  MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v4))))))
-- _.IsAbelianGroup.isSemigroup
d_isSemigroup_132 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_132 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
         (coe MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v0)))
-- _.IsAbelianGroup.isUnitalMagma
d_isUnitalMagma_134 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_134 ~v0 ~v1 ~v2 v3 = du_isUnitalMagma_134 v3
du_isUnitalMagma_134 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_134 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
         (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v1)))
-- _.IsAbelianGroup.refl
d_refl_136 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_136 = erased
-- _.IsAbelianGroup.reflexive
d_reflexive_138 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_138 = erased
-- _.IsAbelianGroup.setoid
d_setoid_140 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_140 ~v0 ~v1 ~v2 v3 = du_setoid_140 v3
du_setoid_140 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_140 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v2) in
          coe
            (coe
               MAlonzo.Code.Algebra.Structures.du_setoid_200
               (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v3)))))
-- _.IsAbelianGroup.sym
d_sym_142 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_142 = erased
-- _.IsAbelianGroup.trans
d_trans_144 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_144 = erased
-- _.IsAbelianGroup.uniqueʳ-⁻¹
d_unique'691''45''8315''185'_146 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_unique'691''45''8315''185'_146 = erased
-- _.IsAbelianGroup.uniqueˡ-⁻¹
d_unique'737''45''8315''185'_148 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_unique'737''45''8315''185'_148 = erased
-- _.IsAbelianGroup.⁻¹-cong
d_'8315''185''45'cong_150 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8315''185''45'cong_150 = erased
-- _.IsAbelianGroup.∙-cong
d_'8729''45'cong_152 ::
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_152 = erased
-- _.IsAbelianGroup.∙-congʳ
d_'8729''45'cong'691'_154 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_154 = erased
-- _.IsAbelianGroup.∙-congˡ
d_'8729''45'cong'737'_156 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_156 = erased
-- _.IsAlternativeMagma.alter
d_alter_160 ::
  MAlonzo.Code.Algebra.Structures.T_IsAlternativeMagma_284 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_alter_160 v0
  = coe MAlonzo.Code.Algebra.Structures.d_alter_294 (coe v0)
-- _.IsAlternativeMagma.alternativeʳ
d_alternative'691'_162 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAlternativeMagma_284 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_alternative'691'_162 = erased
-- _.IsAlternativeMagma.alternativeˡ
d_alternative'737'_164 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAlternativeMagma_284 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_alternative'737'_164 = erased
-- _.IsAlternativeMagma.isEquivalence
d_isEquivalence_166 ::
  MAlonzo.Code.Algebra.Structures.T_IsAlternativeMagma_284 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_166 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_292 (coe v0))
-- _.IsAlternativeMagma.isMagma
d_isMagma_168 ::
  MAlonzo.Code.Algebra.Structures.T_IsAlternativeMagma_284 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_168 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isMagma_292 (coe v0)
-- _.IsAlternativeMagma.isPartialEquivalence
d_isPartialEquivalence_170 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAlternativeMagma_284 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_170 ~v0 v1 = du_isPartialEquivalence_170 v1
du_isPartialEquivalence_170 ::
  MAlonzo.Code.Algebra.Structures.T_IsAlternativeMagma_284 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_170 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isMagma_292 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
         (coe MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v1)))
-- _.IsAlternativeMagma.refl
d_refl_172 ::
  MAlonzo.Code.Algebra.Structures.T_IsAlternativeMagma_284 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_172 = erased
-- _.IsAlternativeMagma.reflexive
d_reflexive_174 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAlternativeMagma_284 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_174 = erased
-- _.IsAlternativeMagma.setoid
d_setoid_176 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAlternativeMagma_284 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_176 ~v0 v1 = du_setoid_176 v1
du_setoid_176 ::
  MAlonzo.Code.Algebra.Structures.T_IsAlternativeMagma_284 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_176 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_setoid_200
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_292 (coe v0))
-- _.IsAlternativeMagma.sym
d_sym_178 ::
  MAlonzo.Code.Algebra.Structures.T_IsAlternativeMagma_284 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_178 = erased
-- _.IsAlternativeMagma.trans
d_trans_180 ::
  MAlonzo.Code.Algebra.Structures.T_IsAlternativeMagma_284 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_180 = erased
-- _.IsAlternativeMagma.∙-cong
d_'8729''45'cong_182 ::
  MAlonzo.Code.Algebra.Structures.T_IsAlternativeMagma_284 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_182 = erased
-- _.IsAlternativeMagma.∙-congʳ
d_'8729''45'cong'691'_184 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAlternativeMagma_284 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_184 = erased
-- _.IsAlternativeMagma.∙-congˡ
d_'8729''45'cong'737'_186 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsAlternativeMagma_284 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_186 = erased
-- _.IsBand.assoc
d_assoc_190 ::
  MAlonzo.Code.Algebra.Structures.T_IsBand_508 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_190 = erased
-- _.IsBand.idem
d_idem_192 ::
  MAlonzo.Code.Algebra.Structures.T_IsBand_508 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_idem_192 = erased
-- _.IsBand.isEquivalence
d_isEquivalence_194 ::
  MAlonzo.Code.Algebra.Structures.T_IsBand_508 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_194 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe MAlonzo.Code.Algebra.Structures.d_isSemigroup_516 (coe v0)))
-- _.IsBand.isMagma
d_isMagma_196 ::
  MAlonzo.Code.Algebra.Structures.T_IsBand_508 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_196 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe MAlonzo.Code.Algebra.Structures.d_isSemigroup_516 (coe v0))
-- _.IsBand.isPartialEquivalence
d_isPartialEquivalence_198 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsBand_508 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_198 ~v0 v1 = du_isPartialEquivalence_198 v1
du_isPartialEquivalence_198 ::
  MAlonzo.Code.Algebra.Structures.T_IsBand_508 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_198 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemigroup_516 (coe v0) in
    coe
      (let v2 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
            (coe
               MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v2))))
-- _.IsBand.isSemigroup
d_isSemigroup_200 ::
  MAlonzo.Code.Algebra.Structures.T_IsBand_508 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_200 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isSemigroup_516 (coe v0)
-- _.IsBand.refl
d_refl_202 ::
  MAlonzo.Code.Algebra.Structures.T_IsBand_508 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_202 = erased
-- _.IsBand.reflexive
d_reflexive_204 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsBand_508 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_204 = erased
-- _.IsBand.setoid
d_setoid_206 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsBand_508 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_206 ~v0 v1 = du_setoid_206 v1
du_setoid_206 ::
  MAlonzo.Code.Algebra.Structures.T_IsBand_508 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_206 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemigroup_516 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_setoid_200
         (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v1)))
-- _.IsBand.sym
d_sym_208 ::
  MAlonzo.Code.Algebra.Structures.T_IsBand_508 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_208 = erased
-- _.IsBand.trans
d_trans_210 ::
  MAlonzo.Code.Algebra.Structures.T_IsBand_508 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_210 = erased
-- _.IsBand.∙-cong
d_'8729''45'cong_212 ::
  MAlonzo.Code.Algebra.Structures.T_IsBand_508 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_212 = erased
-- _.IsBand.∙-congʳ
d_'8729''45'cong'691'_214 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsBand_508 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_214 = erased
-- _.IsBand.∙-congˡ
d_'8729''45'cong'737'_216 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsBand_508 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_216 = erased
-- _.IsCancellativeCommutativeSemiring.*-assoc
d_'42''45'assoc_220 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'assoc_220 = erased
-- _.IsCancellativeCommutativeSemiring.*-cancelʳ-nonZero
d_'42''45'cancel'691''45'nonZero_222 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
   MAlonzo.Code.Data.Irrelevant.T_Irrelevant_20) ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'cancel'691''45'nonZero_222 = erased
-- _.IsCancellativeCommutativeSemiring.*-cancelˡ-nonZero
d_'42''45'cancel'737''45'nonZero_224 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
   MAlonzo.Code.Data.Irrelevant.T_Irrelevant_20) ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'cancel'737''45'nonZero_224 = erased
-- _.IsCancellativeCommutativeSemiring.*-comm
d_'42''45'comm_226 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'comm_226 = erased
-- _.IsCancellativeCommutativeSemiring.*-cong
d_'42''45'cong_228 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'cong_228 = erased
-- _.IsCancellativeCommutativeSemiring.∙-congʳ
d_'8729''45'cong'691'_230 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_230 = erased
-- _.IsCancellativeCommutativeSemiring.∙-congˡ
d_'8729''45'cong'737'_232 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_232 = erased
-- _.IsCancellativeCommutativeSemiring.*-identity
d_'42''45'identity_234 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_'42''45'identity_234 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'42''45'identity_1514
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiring_1712
            (coe
               MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
               (coe v0))))
-- _.IsCancellativeCommutativeSemiring.identityʳ
d_identity'691'_236 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_236 = erased
-- _.IsCancellativeCommutativeSemiring.identityˡ
d_identity'737'_238 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_238 = erased
-- _.IsCancellativeCommutativeSemiring.isCommutativeMagma
d_isCommutativeMagma_240 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_240 ~v0 ~v1 ~v2 ~v3 v4
  = du_isCommutativeMagma_240 v4
du_isCommutativeMagma_240 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_240 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
              (coe v0) in
    coe
      (let v2
             = coe
                 MAlonzo.Code.Algebra.Structures.du_isCommutativeSemiringWithoutOne_1800
                 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
            (coe
               MAlonzo.Code.Algebra.Structures.du_'42''45'isCommutativeSemigroup_1474
               (coe v2))))
-- _.IsCancellativeCommutativeSemiring.*-isCommutativeMonoid
d_'42''45'isCommutativeMonoid_242 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
d_'42''45'isCommutativeMonoid_242 ~v0 ~v1 ~v2 ~v3 v4
  = du_'42''45'isCommutativeMonoid_242 v4
du_'42''45'isCommutativeMonoid_242 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
du_'42''45'isCommutativeMonoid_242 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isCommutativeMonoid_1808
      (coe
         MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
         (coe v0))
-- _.IsCancellativeCommutativeSemiring.*-isCommutativeSemigroup
d_'42''45'isCommutativeSemigroup_244 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_'42''45'isCommutativeSemigroup_244 ~v0 ~v1 ~v2 ~v3 v4
  = du_'42''45'isCommutativeSemigroup_244 v4
du_'42''45'isCommutativeSemigroup_244 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
du_'42''45'isCommutativeSemigroup_244 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_'42''45'isCommutativeSemigroup_1474
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeSemiringWithoutOne_1800
            (coe v1)))
-- _.IsCancellativeCommutativeSemiring.*-isMagma
d_'42''45'isMagma_246 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_'42''45'isMagma_246 ~v0 ~v1 ~v2 ~v3 v4
  = du_'42''45'isMagma_246 v4
du_'42''45'isMagma_246 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
du_'42''45'isMagma_246 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_'42''45'isMagma_1566
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
               (coe v2))))
-- _.IsCancellativeCommutativeSemiring.*-isMonoid
d_'42''45'isMonoid_248 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_'42''45'isMonoid_248 ~v0 ~v1 ~v2 ~v3 v4
  = du_'42''45'isMonoid_248 v4
du_'42''45'isMonoid_248 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
du_'42''45'isMonoid_248 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_'42''45'isMonoid_1570
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
               (coe v2))))
-- _.IsCancellativeCommutativeSemiring.*-isSemigroup
d_'42''45'isSemigroup_250 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_'42''45'isSemigroup_250 ~v0 ~v1 ~v2 ~v3 v4
  = du_'42''45'isSemigroup_250 v4
du_'42''45'isSemigroup_250 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
du_'42''45'isSemigroup_250 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_'42''45'isSemigroup_1568
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
               (coe v2))))
-- _.IsCancellativeCommutativeSemiring.assoc
d_assoc_252 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_252 = erased
-- _.IsCancellativeCommutativeSemiring.comm
d_comm_254 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_254 = erased
-- _.IsCancellativeCommutativeSemiring.∙-cong
d_'8729''45'cong_256 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_256 = erased
-- _.IsCancellativeCommutativeSemiring.∙-congʳ
d_'8729''45'cong'691'_258 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_258 = erased
-- _.IsCancellativeCommutativeSemiring.∙-congˡ
d_'8729''45'cong'737'_260 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_260 = erased
-- _.IsCancellativeCommutativeSemiring.identity
d_identity_262 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_262 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_746
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isSemiring_1712
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
                     (coe v0))))))
-- _.IsCancellativeCommutativeSemiring.identityʳ
d_identity'691'_264 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_264 = erased
-- _.IsCancellativeCommutativeSemiring.identityˡ
d_identity'737'_266 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_266 = erased
-- _.IsCancellativeCommutativeSemiring.isCommutativeMagma
d_isCommutativeMagma_268 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_268 ~v0 ~v1 ~v2 ~v3 v4
  = du_isCommutativeMagma_268 v4
du_isCommutativeMagma_268 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_268 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                    (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                       (coe v3) in
             coe
               (coe
                  MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
                  (coe
                     MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
                     (coe v4))))))
-- _.IsCancellativeCommutativeSemiring.+-isCommutativeMonoid
d_'43''45'isCommutativeMonoid_270 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
d_'43''45'isCommutativeMonoid_270 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiring_1712
            (coe
               MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
               (coe v0))))
-- _.IsCancellativeCommutativeSemiring.isCommutativeSemigroup
d_isCommutativeSemigroup_272 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_isCommutativeSemigroup_272 ~v0 ~v1 ~v2 ~v3 v4
  = du_isCommutativeSemigroup_272 v4
du_isCommutativeSemigroup_272 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
du_isCommutativeSemigroup_272 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                    (coe v2) in
          coe
            (coe
               MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
               (coe
                  MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                  (coe v3)))))
-- _.IsCancellativeCommutativeSemiring.isMagma
d_isMagma_274 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_274 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe
            MAlonzo.Code.Algebra.Structures.d_isMonoid_746
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isSemiring_1712
                     (coe
                        MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
                        (coe v0)))))))
-- _.IsCancellativeCommutativeSemiring.isMonoid
d_isMonoid_276 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_isMonoid_276 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMonoid_746
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiring_1712
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
                  (coe v0)))))
-- _.IsCancellativeCommutativeSemiring.isSemigroup
d_isSemigroup_278 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_278 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_746
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isSemiring_1712
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
                     (coe v0))))))
-- _.IsCancellativeCommutativeSemiring.isUnitalMagma
d_isUnitalMagma_280 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_280 ~v0 ~v1 ~v2 ~v3 v4 = du_isUnitalMagma_280 v4
du_isUnitalMagma_280 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_280 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                    (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                       (coe v3) in
             coe
               (coe
                  MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
                  (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v4))))))
-- _.IsCancellativeCommutativeSemiring.distrib
d_distrib_282 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_distrib_282 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_distrib_1516
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiring_1712
            (coe
               MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
               (coe v0))))
-- _.IsCancellativeCommutativeSemiring.distribʳ
d_distrib'691'_284 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'691'_284 = erased
-- _.IsCancellativeCommutativeSemiring.distribˡ
d_distrib'737'_286 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'737'_286 = erased
-- _.IsCancellativeCommutativeSemiring.isCommutativeSemiring
d_isCommutativeSemiring_288 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698
d_isCommutativeSemiring_288 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
      (coe v0)
-- _.IsCancellativeCommutativeSemiring.isCommutativeSemiringWithoutOne
d_isCommutativeSemiringWithoutOne_290 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392
d_isCommutativeSemiringWithoutOne_290 ~v0 ~v1 ~v2 ~v3 v4
  = du_isCommutativeSemiringWithoutOne_290 v4
du_isCommutativeSemiringWithoutOne_290 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392
du_isCommutativeSemiringWithoutOne_290 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isCommutativeSemiringWithoutOne_1800
      (coe
         MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
         (coe v0))
-- _.IsCancellativeCommutativeSemiring.isEquivalence
d_isEquivalence_292 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_292 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe
               MAlonzo.Code.Algebra.Structures.d_isMonoid_746
               (coe
                  MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                     (coe
                        MAlonzo.Code.Algebra.Structures.d_isSemiring_1712
                        (coe
                           MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
                           (coe v0))))))))
-- _.IsCancellativeCommutativeSemiring.isNearSemiring
d_isNearSemiring_294 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
d_isNearSemiring_294 ~v0 ~v1 ~v2 ~v3 v4 = du_isNearSemiring_294 v4
du_isNearSemiring_294 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
du_isNearSemiring_294 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isNearSemiring_1384
            (coe
               MAlonzo.Code.Algebra.Structures.du_isSemiringWithoutOne_1680
               (coe v2))))
-- _.IsCancellativeCommutativeSemiring.isPartialEquivalence
d_isPartialEquivalence_296 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_296 ~v0 ~v1 ~v2 ~v3 v4
  = du_isPartialEquivalence_296 v4
du_isPartialEquivalence_296 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_296 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                    (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                       (coe v3) in
             coe
               (let v5
                      = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v4) in
                coe
                  (let v6
                         = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v5) in
                   coe
                     (let v7 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v6) in
                      coe
                        (coe
                           MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
                           (coe
                              MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
                              (coe v7)))))))))
-- _.IsCancellativeCommutativeSemiring.isSemiring
d_isSemiring_298 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590
d_isSemiring_298 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemiring_1712
      (coe
         MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
         (coe v0))
-- _.IsCancellativeCommutativeSemiring.isSemiringWithoutAnnihilatingZero
d_isSemiringWithoutAnnihilatingZero_300 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488
d_isSemiringWithoutAnnihilatingZero_300 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiring_1712
         (coe
            MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
            (coe v0)))
-- _.IsCancellativeCommutativeSemiring.isSemiringWithoutOne
d_isSemiringWithoutOne_302 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298
d_isSemiringWithoutOne_302 ~v0 ~v1 ~v2 ~v3 v4
  = du_isSemiringWithoutOne_302 v4
du_isSemiringWithoutOne_302 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298
du_isSemiringWithoutOne_302 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isSemiringWithoutOne_1680
         (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v1)))
-- _.IsCancellativeCommutativeSemiring.refl
d_refl_304 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_304 = erased
-- _.IsCancellativeCommutativeSemiring.reflexive
d_reflexive_306 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_306 = erased
-- _.IsCancellativeCommutativeSemiring.setoid
d_setoid_308 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_308 ~v0 ~v1 ~v2 ~v3 v4 = du_setoid_308 v4
du_setoid_308 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_308 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                    (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                       (coe v3) in
             coe
               (let v5
                      = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v4) in
                coe
                  (let v6
                         = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v5) in
                   coe
                     (coe
                        MAlonzo.Code.Algebra.Structures.du_setoid_200
                        (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v6))))))))
-- _.IsCancellativeCommutativeSemiring.sym
d_sym_310 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_310 = erased
-- _.IsCancellativeCommutativeSemiring.trans
d_trans_312 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_312 = erased
-- _.IsCancellativeCommutativeSemiring.zero
d_zero_314 ::
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_zero_314 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_zero_1606
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiring_1712
         (coe
            MAlonzo.Code.Algebra.Structures.d_isCommutativeSemiring_1832
            (coe v0)))
-- _.IsCancellativeCommutativeSemiring.zeroʳ
d_zero'691'_316 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'691'_316 = erased
-- _.IsCancellativeCommutativeSemiring.zeroˡ
d_zero'737'_318 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCancellativeCommutativeSemiring_1818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'737'_318 = erased
-- _.IsCommutativeBand.assoc
d_assoc_322 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_322 = erased
-- _.IsCommutativeBand.comm
d_comm_324 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_324 = erased
-- _.IsCommutativeBand.idem
d_idem_326 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_idem_326 = erased
-- _.IsCommutativeBand.isBand
d_isBand_328 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Algebra.Structures.T_IsBand_508
d_isBand_328 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isBand_598 (coe v0)
-- _.IsCommutativeBand.isCommutativeMagma
d_isCommutativeMagma_330 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_330 ~v0 v1 = du_isCommutativeMagma_330 v1
du_isCommutativeMagma_330 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_330 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
      (coe
         MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_632
         (coe v0))
-- _.IsCommutativeBand.isCommutativeSemigroup
d_isCommutativeSemigroup_332 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_isCommutativeSemigroup_332 v0 v1
  = coe
      MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_632 v1
-- _.IsCommutativeBand.isEquivalence
d_isEquivalence_334 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_334 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_516
            (coe MAlonzo.Code.Algebra.Structures.d_isBand_598 (coe v0))))
-- _.IsCommutativeBand.isMagma
d_isMagma_336 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_336 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_516
         (coe MAlonzo.Code.Algebra.Structures.d_isBand_598 (coe v0)))
-- _.IsCommutativeBand.isPartialEquivalence
d_isPartialEquivalence_338 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_338 ~v0 v1 = du_isPartialEquivalence_338 v1
du_isPartialEquivalence_338 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_338 v0
  = let v1 = MAlonzo.Code.Algebra.Structures.d_isBand_598 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemigroup_516 (coe v1) in
       coe
         (let v3 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v2) in
          coe
            (coe
               MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v3)))))
-- _.IsCommutativeBand.isSemigroup
d_isSemigroup_340 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_340 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_516
      (coe MAlonzo.Code.Algebra.Structures.d_isBand_598 (coe v0))
-- _.IsCommutativeBand.refl
d_refl_342 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_342 = erased
-- _.IsCommutativeBand.reflexive
d_reflexive_344 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_344 = erased
-- _.IsCommutativeBand.setoid
d_setoid_346 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_346 ~v0 v1 = du_setoid_346 v1
du_setoid_346 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_346 v0
  = let v1 = MAlonzo.Code.Algebra.Structures.d_isBand_598 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemigroup_516 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_setoid_200
            (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v2))))
-- _.IsCommutativeBand.sym
d_sym_348 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_348 = erased
-- _.IsCommutativeBand.trans
d_trans_350 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_350 = erased
-- _.IsCommutativeBand.∙-cong
d_'8729''45'cong_352 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_352 = erased
-- _.IsCommutativeBand.∙-congʳ
d_'8729''45'cong'691'_354 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_354 = erased
-- _.IsCommutativeBand.∙-congˡ
d_'8729''45'cong'737'_356 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_356 = erased
-- _.IsCommutativeMagma.comm
d_comm_360 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_360 = erased
-- _.IsCommutativeMagma.isEquivalence
d_isEquivalence_362 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_362 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_220 (coe v0))
-- _.IsCommutativeMagma.isMagma
d_isMagma_364 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_364 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isMagma_220 (coe v0)
-- _.IsCommutativeMagma.isPartialEquivalence
d_isPartialEquivalence_366 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_366 ~v0 v1 = du_isPartialEquivalence_366 v1
du_isPartialEquivalence_366 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_366 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isMagma_220 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
         (coe MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v1)))
-- _.IsCommutativeMagma.refl
d_refl_368 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_368 = erased
-- _.IsCommutativeMagma.reflexive
d_reflexive_370 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_370 = erased
-- _.IsCommutativeMagma.setoid
d_setoid_372 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_372 ~v0 v1 = du_setoid_372 v1
du_setoid_372 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_372 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_setoid_200
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_220 (coe v0))
-- _.IsCommutativeMagma.sym
d_sym_374 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_374 = erased
-- _.IsCommutativeMagma.trans
d_trans_376 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_376 = erased
-- _.IsCommutativeMagma.∙-cong
d_'8729''45'cong_378 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_378 = erased
-- _.IsCommutativeMagma.∙-congʳ
d_'8729''45'cong'691'_380 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_380 = erased
-- _.IsCommutativeMagma.∙-congˡ
d_'8729''45'cong'737'_382 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_382 = erased
-- _.IsCommutativeMonoid.assoc
d_assoc_386 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_386 = erased
-- _.IsCommutativeMonoid.comm
d_comm_388 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_388 = erased
-- _.IsCommutativeMonoid.identity
d_identity_390 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_390 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v0))
-- _.IsCommutativeMonoid.identityʳ
d_identity'691'_392 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_392 = erased
-- _.IsCommutativeMonoid.identityˡ
d_identity'737'_394 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_394 = erased
-- _.IsCommutativeMonoid.isCommutativeMagma
d_isCommutativeMagma_396 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_396 ~v0 ~v1 v2 = du_isCommutativeMagma_396 v2
du_isCommutativeMagma_396 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_396 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
      (coe
         MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
         (coe v0))
-- _.IsCommutativeMonoid.isCommutativeSemigroup
d_isCommutativeSemigroup_398 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_isCommutativeSemigroup_398 v0 v1 v2
  = coe
      MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786 v2
-- _.IsCommutativeMonoid.isEquivalence
d_isEquivalence_400 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_400 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v0))))
-- _.IsCommutativeMonoid.isMagma
d_isMagma_402 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_402 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v0)))
-- _.IsCommutativeMonoid.isMonoid
d_isMonoid_404 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_isMonoid_404 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v0)
-- _.IsCommutativeMonoid.isPartialEquivalence
d_isPartialEquivalence_406 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_406 ~v0 ~v1 v2
  = du_isPartialEquivalence_406 v2
du_isPartialEquivalence_406 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_406 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v1) in
       coe
         (let v3 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v2) in
          coe
            (coe
               MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v3)))))
-- _.IsCommutativeMonoid.isSemigroup
d_isSemigroup_408 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_408 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
      (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v0))
-- _.IsCommutativeMonoid.isUnitalMagma
d_isUnitalMagma_410 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_410 ~v0 ~v1 v2 = du_isUnitalMagma_410 v2
du_isUnitalMagma_410 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_410 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
      (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v0))
-- _.IsCommutativeMonoid.refl
d_refl_412 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_412 = erased
-- _.IsCommutativeMonoid.reflexive
d_reflexive_414 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_414 = erased
-- _.IsCommutativeMonoid.setoid
d_setoid_416 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_416 ~v0 ~v1 v2 = du_setoid_416 v2
du_setoid_416 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_416 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_setoid_200
            (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v2))))
-- _.IsCommutativeMonoid.sym
d_sym_418 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_418 = erased
-- _.IsCommutativeMonoid.trans
d_trans_420 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_420 = erased
-- _.IsCommutativeMonoid.∙-cong
d_'8729''45'cong_422 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_422 = erased
-- _.IsCommutativeMonoid.∙-congʳ
d_'8729''45'cong'691'_424 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_424 = erased
-- _.IsCommutativeMonoid.∙-congˡ
d_'8729''45'cong'737'_426 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_426 = erased
-- _.IsCommutativeRing._//_
d__'47''47'__430 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d__'47''47'__430 v0 ~v1 v2 ~v3 ~v4 ~v5 = du__'47''47'__430 v0 v2
du__'47''47'__430 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
du__'47''47'__430 v0 v1
  = coe
      MAlonzo.Code.Algebra.Structures.du__'47''47'__1098 (coe v0)
      (coe v1)
-- _.IsCommutativeRing.*-assoc
d_'42''45'assoc_432 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'assoc_432 = erased
-- _.IsCommutativeRing.*-comm
d_'42''45'comm_434 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'comm_434 = erased
-- _.IsCommutativeRing.*-cong
d_'42''45'cong_436 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'cong_436 = erased
-- _.IsCommutativeRing.∙-congʳ
d_'8729''45'cong'691'_438 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_438 = erased
-- _.IsCommutativeRing.∙-congˡ
d_'8729''45'cong'737'_440 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_440 = erased
-- _.IsCommutativeRing.*-identity
d_'42''45'identity_442 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_'42''45'identity_442 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'42''45'identity_2700
      (coe MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0))
-- _.IsCommutativeRing.identityʳ
d_identity'691'_444 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_444 = erased
-- _.IsCommutativeRing.identityˡ
d_identity'737'_446 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_446 = erased
-- _.IsCommutativeRing.isCommutativeMagma
d_isCommutativeMagma_448 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_448 v0 v1 v2 v3 ~v4 v5
  = du_isCommutativeMagma_448 v0 v1 v2 v3 v5
du_isCommutativeMagma_448 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_448 v0 v1 v2 v3 v4
  = let v5
          = coe
              MAlonzo.Code.Algebra.Structures.du_isCommutativeSemiring_2948
              (coe v0) (coe v1) (coe v2) (coe v3) (coe v4) in
    coe
      (let v6
             = coe
                 MAlonzo.Code.Algebra.Structures.du_isCommutativeSemiringWithoutOne_1800
                 (coe v5) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
            (coe
               MAlonzo.Code.Algebra.Structures.du_'42''45'isCommutativeSemigroup_1474
               (coe v6))))
-- _.IsCommutativeRing.*-isCommutativeMonoid
d_'42''45'isCommutativeMonoid_450 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
d_'42''45'isCommutativeMonoid_450 v0 v1 v2 v3 ~v4 v5
  = du_'42''45'isCommutativeMonoid_450 v0 v1 v2 v3 v5
du_'42''45'isCommutativeMonoid_450 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
du_'42''45'isCommutativeMonoid_450 v0 v1 v2 v3 v4
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isCommutativeMonoid_1808
      (coe
         MAlonzo.Code.Algebra.Structures.du_isCommutativeSemiring_2948
         (coe v0) (coe v1) (coe v2) (coe v3) (coe v4))
-- _.IsCommutativeRing.*-isCommutativeSemigroup
d_'42''45'isCommutativeSemigroup_452 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_'42''45'isCommutativeSemigroup_452 v0 v1 v2 v3 ~v4 v5
  = du_'42''45'isCommutativeSemigroup_452 v0 v1 v2 v3 v5
du_'42''45'isCommutativeSemigroup_452 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
du_'42''45'isCommutativeSemigroup_452 v0 v1 v2 v3 v4
  = let v5
          = coe
              MAlonzo.Code.Algebra.Structures.du_isCommutativeSemiring_2948
              (coe v0) (coe v1) (coe v2) (coe v3) (coe v4) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_'42''45'isCommutativeSemigroup_1474
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeSemiringWithoutOne_1800
            (coe v5)))
-- _.IsCommutativeRing.*-isMagma
d_'42''45'isMagma_454 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_'42''45'isMagma_454 v0 v1 v2 v3 ~v4 v5
  = du_'42''45'isMagma_454 v0 v1 v2 v3 v5
du_'42''45'isMagma_454 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
du_'42''45'isMagma_454 v0 v1 v2 v3 v4
  = let v5
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v4) in
    coe
      (let v6
             = coe
                 MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
                 (coe v5) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_'42''45'isMagma_1282
            (coe
               MAlonzo.Code.Algebra.Structures.du_isNearSemiring_2408 (coe v0)
               (coe v1) (coe v2) (coe v3) (coe v6))))
-- _.IsCommutativeRing.*-isMonoid
d_'42''45'isMonoid_456 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_'42''45'isMonoid_456 v0 v1 v2 v3 ~v4 v5
  = du_'42''45'isMonoid_456 v0 v1 v2 v3 v5
du_'42''45'isMonoid_456 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
du_'42''45'isMonoid_456 v0 v1 v2 v3 v4
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isMonoid_2792 (coe v0)
      (coe v1) (coe v2) (coe v3)
      (coe MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v4))
-- _.IsCommutativeRing.*-isSemigroup
d_'42''45'isSemigroup_458 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_'42''45'isSemigroup_458 v0 v1 v2 v3 ~v4 v5
  = du_'42''45'isSemigroup_458 v0 v1 v2 v3 v5
du_'42''45'isSemigroup_458 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
du_'42''45'isSemigroup_458 v0 v1 v2 v3 v4
  = let v5
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v4) in
    coe
      (let v6
             = coe
                 MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
                 (coe v5) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_'42''45'isSemigroup_1284
            (coe
               MAlonzo.Code.Algebra.Structures.du_isNearSemiring_2408 (coe v0)
               (coe v1) (coe v2) (coe v3) (coe v6))))
-- _.IsCommutativeRing.assoc
d_assoc_460 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_460 = erased
-- _.IsCommutativeRing.comm
d_comm_462 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_462 = erased
-- _.IsCommutativeRing.∙-cong
d_'8729''45'cong_464 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_464 = erased
-- _.IsCommutativeRing.∙-congʳ
d_'8729''45'cong'691'_466 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_466 = erased
-- _.IsCommutativeRing.∙-congˡ
d_'8729''45'cong'737'_468 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_468 = erased
-- _.IsCommutativeRing.identity
d_identity_470 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_470 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_identity_470 v5
du_identity_470 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
du_identity_470 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.d_identity_698
         (coe
            MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
            (coe
               MAlonzo.Code.Algebra.Structures.d_isGroup_1144
               (coe
                  MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2694
                  (coe v1)))))
-- _.IsCommutativeRing.identityʳ
d_identity'691'_472 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_472 = erased
-- _.IsCommutativeRing.identityˡ
d_identity'737'_474 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_474 = erased
-- _.IsCommutativeRing.+-isAbelianGroup
d_'43''45'isAbelianGroup_476 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132
d_'43''45'isAbelianGroup_476 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2694
      (coe MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0))
-- _.IsCommutativeRing.isCommutativeMagma
d_isCommutativeMagma_478 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_478 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isCommutativeMagma_478 v5
du_isCommutativeMagma_478 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_478 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0) in
    coe
      (let v2
             = coe
                 MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
                    (coe v2) in
          coe
            (let v4
                   = coe
                       MAlonzo.Code.Algebra.Structures.du_isCommutativeMonoid_1204
                       (coe v3) in
             coe
               (coe
                  MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
                  (coe
                     MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
                     (coe v4))))))
-- _.IsCommutativeRing.isCommutativeMonoid
d_isCommutativeMonoid_480 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
d_isCommutativeMonoid_480 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isCommutativeMonoid_480 v5
du_isCommutativeMonoid_480 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
du_isCommutativeMonoid_480 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0) in
    coe
      (let v2
             = coe
                 MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
                 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeMonoid_1204
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
               (coe v2))))
-- _.IsCommutativeRing.isCommutativeSemigroup
d_isCommutativeSemigroup_482 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_isCommutativeSemigroup_482 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isCommutativeSemigroup_482 v5
du_isCommutativeSemigroup_482 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
du_isCommutativeSemigroup_482 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0) in
    coe
      (let v2
             = coe
                 MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
                    (coe v2) in
          coe
            (coe
               MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
               (coe
                  MAlonzo.Code.Algebra.Structures.du_isCommutativeMonoid_1204
                  (coe v3)))))
-- _.IsCommutativeRing.isGroup
d_isGroup_484 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036
d_isGroup_484 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_isGroup_484 v5
du_isGroup_484 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036
du_isGroup_484 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.d_isGroup_1144
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2694
            (coe v1)))
-- _.IsCommutativeRing.isInvertibleMagma
d_isInvertibleMagma_486 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924
d_isInvertibleMagma_486 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isInvertibleMagma_486 v5
du_isInvertibleMagma_486 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924
du_isInvertibleMagma_486 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0) in
    coe
      (let v2
             = coe
                 MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
                    (coe v2) in
          coe
            (coe
               MAlonzo.Code.Algebra.Structures.du_isInvertibleMagma_1122
               (coe MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v3)))))
-- _.IsCommutativeRing.isInvertibleUnitalMagma
d_isInvertibleUnitalMagma_488 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976
d_isInvertibleUnitalMagma_488 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isInvertibleUnitalMagma_488 v5
du_isInvertibleUnitalMagma_488 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976
du_isInvertibleUnitalMagma_488 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0) in
    coe
      (let v2
             = coe
                 MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
                    (coe v2) in
          coe
            (coe
               MAlonzo.Code.Algebra.Structures.du_isInvertibleUnitalMagma_1124
               (coe MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v3)))))
-- _.IsCommutativeRing.isMagma
d_isMagma_490 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_490 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_isMagma_490 v5
du_isMagma_490 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
du_isMagma_490 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe
               MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isGroup_1144
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2694
                     (coe v1))))))
-- _.IsCommutativeRing.isMonoid
d_isMonoid_492 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_isMonoid_492 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_isMonoid_492 v5
du_isMonoid_492 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
du_isMonoid_492 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
         (coe
            MAlonzo.Code.Algebra.Structures.d_isGroup_1144
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2694
               (coe v1))))
-- _.IsCommutativeRing.isSemigroup
d_isSemigroup_494 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_494 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_isSemigroup_494 v5
du_isSemigroup_494 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
du_isSemigroup_494 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe
            MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
            (coe
               MAlonzo.Code.Algebra.Structures.d_isGroup_1144
               (coe
                  MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2694
                  (coe v1)))))
-- _.IsCommutativeRing.isUnitalMagma
d_isUnitalMagma_496 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_496 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isUnitalMagma_496 v5
du_isUnitalMagma_496 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_496 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0) in
    coe
      (let v2
             = coe
                 MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
                    (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v3) in
             coe
               (coe
                  MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
                  (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v4))))))
-- _.IsCommutativeRing.⁻¹-cong
d_'8315''185''45'cong_498 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8315''185''45'cong_498 = erased
-- _.IsCommutativeRing.inverse
d_inverse_500 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_inverse_500 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_inverse_500 v5
du_inverse_500 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
du_inverse_500 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.d_inverse_1052
         (coe
            MAlonzo.Code.Algebra.Structures.d_isGroup_1144
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2694
               (coe v1))))
-- _.IsCommutativeRing.inverseʳ
d_inverse'691'_502 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_inverse'691'_502 = erased
-- _.IsCommutativeRing.inverseˡ
d_inverse'737'_504 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_inverse'737'_504 = erased
-- _.IsCommutativeRing.distrib
d_distrib_506 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_distrib_506 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_distrib_2702
      (coe MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0))
-- _.IsCommutativeRing.distribʳ
d_distrib'691'_508 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'691'_508 = erased
-- _.IsCommutativeRing.distribˡ
d_distrib'737'_510 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'737'_510 = erased
-- _.IsCommutativeRing.isCommutativeSemiring
d_isCommutativeSemiring_512 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698
d_isCommutativeSemiring_512 v0 v1 v2 v3 v4 v5
  = coe
      MAlonzo.Code.Algebra.Structures.du_isCommutativeSemiring_2948 v0 v1
      v2 v3 v5
-- _.IsCommutativeRing.isCommutativeSemiringWithoutOne
d_isCommutativeSemiringWithoutOne_514 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392
d_isCommutativeSemiringWithoutOne_514 v0 v1 v2 v3 ~v4 v5
  = du_isCommutativeSemiringWithoutOne_514 v0 v1 v2 v3 v5
du_isCommutativeSemiringWithoutOne_514 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392
du_isCommutativeSemiringWithoutOne_514 v0 v1 v2 v3 v4
  = coe
      MAlonzo.Code.Algebra.Structures.du_isCommutativeSemiringWithoutOne_1800
      (coe
         MAlonzo.Code.Algebra.Structures.du_isCommutativeSemiring_2948
         (coe v0) (coe v1) (coe v2) (coe v3) (coe v4))
-- _.IsCommutativeRing.isEquivalence
d_isEquivalence_516 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_516 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isEquivalence_516 v5
du_isEquivalence_516 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
du_isEquivalence_516 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
         (coe
            MAlonzo.Code.Algebra.Structures.d_isMagma_480
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isGroup_1144
                     (coe
                        MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2694
                        (coe v1)))))))
-- _.IsCommutativeRing.isNearSemiring
d_isNearSemiring_518 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
d_isNearSemiring_518 v0 v1 v2 v3 ~v4 v5
  = du_isNearSemiring_518 v0 v1 v2 v3 v5
du_isNearSemiring_518 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
du_isNearSemiring_518 v0 v1 v2 v3 v4
  = let v5
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v4) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isNearSemiring_2408 (coe v0)
         (coe v1) (coe v2) (coe v3)
         (coe
            MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704 (coe v5)))
-- _.IsCommutativeRing.isPartialEquivalence
d_isPartialEquivalence_520 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_520 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isPartialEquivalence_520 v5
du_isPartialEquivalence_520 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_520 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0) in
    coe
      (let v2
             = coe
                 MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
                    (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v3) in
             coe
               (let v5
                      = MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v4) in
                coe
                  (let v6
                         = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v5) in
                   coe
                     (let v7 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v6) in
                      coe
                        (coe
                           MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
                           (coe
                              MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
                              (coe v7)))))))))
-- _.IsCommutativeRing.isRing
d_isRing_522 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672
d_isRing_522 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0)
-- _.IsCommutativeRing.isRingWithoutOne
d_isRingWithoutOne_524 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306
d_isRingWithoutOne_524 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isRingWithoutOne_524 v5
du_isRingWithoutOne_524 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306
du_isRingWithoutOne_524 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
      (coe MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0))
-- _.IsCommutativeRing.isSemiring
d_isSemiring_526 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590
d_isSemiring_526 v0 v1 v2 v3 ~v4 v5
  = du_isSemiring_526 v0 v1 v2 v3 v5
du_isSemiring_526 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590
du_isSemiring_526 v0 v1 v2 v3 v4
  = coe
      MAlonzo.Code.Algebra.Structures.du_isSemiring_2802 (coe v0)
      (coe v1) (coe v2) (coe v3)
      (coe MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v4))
-- _.IsCommutativeRing.isSemiringWithoutAnnihilatingZero
d_isSemiringWithoutAnnihilatingZero_528 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488
d_isSemiringWithoutAnnihilatingZero_528 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isSemiringWithoutAnnihilatingZero_528 v5
du_isSemiringWithoutAnnihilatingZero_528 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488
du_isSemiringWithoutAnnihilatingZero_528 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isSemiringWithoutAnnihilatingZero_2800
      (coe MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0))
-- _.IsCommutativeRing.isSemiringWithoutOne
d_isSemiringWithoutOne_530 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298
d_isSemiringWithoutOne_530 v0 v1 v2 v3 ~v4 v5
  = du_isSemiringWithoutOne_530 v0 v1 v2 v3 v5
du_isSemiringWithoutOne_530 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298
du_isSemiringWithoutOne_530 v0 v1 v2 v3 v4
  = let v5
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v4) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isSemiringWithoutOne_1680
         (coe
            MAlonzo.Code.Algebra.Structures.du_isSemiring_2802 (coe v0)
            (coe v1) (coe v2) (coe v3) (coe v5)))
-- _.IsCommutativeRing.refl
d_refl_532 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_532 = erased
-- _.IsCommutativeRing.reflexive
d_reflexive_534 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_534 = erased
-- _.IsCommutativeRing.setoid
d_setoid_536 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_536 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_setoid_536 v5
du_setoid_536 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_536 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v0) in
    coe
      (let v2
             = coe
                 MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
                    (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v3) in
             coe
               (let v5
                      = MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v4) in
                coe
                  (let v6
                         = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v5) in
                   coe
                     (coe
                        MAlonzo.Code.Algebra.Structures.du_setoid_200
                        (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v6))))))))
-- _.IsCommutativeRing.sym
d_sym_538 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_538 = erased
-- _.IsCommutativeRing.trans
d_trans_540 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_540 = erased
-- _.IsCommutativeRing.uniqueʳ-⁻¹
d_unique'691''45''8315''185'_542 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_unique'691''45''8315''185'_542 = erased
-- _.IsCommutativeRing.uniqueˡ-⁻¹
d_unique'737''45''8315''185'_544 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_unique'737''45''8315''185'_544 = erased
-- _.IsCommutativeRing.zero
d_zero_546 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_zero_546 v0 v1 v2 v3 ~v4 v5 = du_zero_546 v0 v1 v2 v3 v5
du_zero_546 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
du_zero_546 v0 v1 v2 v3 v4
  = let v5
          = MAlonzo.Code.Algebra.Structures.d_isRing_2834 (coe v4) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_zero_2406 (coe v0) (coe v1)
         (coe v2) (coe v3)
         (coe
            MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704 (coe v5)))
-- _.IsCommutativeRing.zeroʳ
d_zero'691'_548 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'691'_548 = erased
-- _.IsCommutativeRing.zeroˡ
d_zero'737'_550 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'737'_550 = erased
-- _.IsCommutativeSemigroup.assoc
d_assoc_554 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_554 = erased
-- _.IsCommutativeSemigroup.comm
d_comm_556 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_556 = erased
-- _.IsCommutativeSemigroup.isCommutativeMagma
d_isCommutativeMagma_558 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_558 v0 v1
  = coe MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586 v1
-- _.IsCommutativeSemigroup.isEquivalence
d_isEquivalence_560 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_560 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe MAlonzo.Code.Algebra.Structures.d_isSemigroup_556 (coe v0)))
-- _.IsCommutativeSemigroup.isMagma
d_isMagma_562 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_562 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe MAlonzo.Code.Algebra.Structures.d_isSemigroup_556 (coe v0))
-- _.IsCommutativeSemigroup.isPartialEquivalence
d_isPartialEquivalence_564 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_564 ~v0 v1 = du_isPartialEquivalence_564 v1
du_isPartialEquivalence_564 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_564 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemigroup_556 (coe v0) in
    coe
      (let v2 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
            (coe
               MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v2))))
-- _.IsCommutativeSemigroup.isSemigroup
d_isSemigroup_566 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_566 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isSemigroup_556 (coe v0)
-- _.IsCommutativeSemigroup.refl
d_refl_568 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_568 = erased
-- _.IsCommutativeSemigroup.reflexive
d_reflexive_570 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_570 = erased
-- _.IsCommutativeSemigroup.setoid
d_setoid_572 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_572 ~v0 v1 = du_setoid_572 v1
du_setoid_572 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_572 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemigroup_556 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_setoid_200
         (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v1)))
-- _.IsCommutativeSemigroup.sym
d_sym_574 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_574 = erased
-- _.IsCommutativeSemigroup.trans
d_trans_576 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_576 = erased
-- _.IsCommutativeSemigroup.∙-cong
d_'8729''45'cong_578 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_578 = erased
-- _.IsCommutativeSemigroup.∙-congʳ
d_'8729''45'cong'691'_580 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_580 = erased
-- _.IsCommutativeSemigroup.∙-congˡ
d_'8729''45'cong'737'_582 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_582 = erased
-- _.IsCommutativeSemiring.*-assoc
d_'42''45'assoc_586 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'assoc_586 = erased
-- _.IsCommutativeSemiring.*-comm
d_'42''45'comm_588 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'comm_588 = erased
-- _.IsCommutativeSemiring.*-cong
d_'42''45'cong_590 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'cong_590 = erased
-- _.IsCommutativeSemiring.∙-congʳ
d_'8729''45'cong'691'_592 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_592 = erased
-- _.IsCommutativeSemiring.∙-congˡ
d_'8729''45'cong'737'_594 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_594 = erased
-- _.IsCommutativeSemiring.*-identity
d_'42''45'identity_596 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_'42''45'identity_596 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'42''45'identity_1514
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0)))
-- _.IsCommutativeSemiring.identityʳ
d_identity'691'_598 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_598 = erased
-- _.IsCommutativeSemiring.identityˡ
d_identity'737'_600 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_600 = erased
-- _.IsCommutativeSemiring.isCommutativeMagma
d_isCommutativeMagma_602 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_602 ~v0 ~v1 ~v2 ~v3 v4
  = du_isCommutativeMagma_602 v4
du_isCommutativeMagma_602 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_602 v0
  = let v1
          = coe
              MAlonzo.Code.Algebra.Structures.du_isCommutativeSemiringWithoutOne_1800
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
         (coe
            MAlonzo.Code.Algebra.Structures.du_'42''45'isCommutativeSemigroup_1474
            (coe v1)))
-- _.IsCommutativeSemiring.*-isCommutativeMonoid
d_'42''45'isCommutativeMonoid_604 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
d_'42''45'isCommutativeMonoid_604 v0 v1 v2 v3 v4
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isCommutativeMonoid_1808
      v4
-- _.IsCommutativeSemiring.*-isCommutativeSemigroup
d_'42''45'isCommutativeSemigroup_606 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_'42''45'isCommutativeSemigroup_606 ~v0 ~v1 ~v2 ~v3 v4
  = du_'42''45'isCommutativeSemigroup_606 v4
du_'42''45'isCommutativeSemigroup_606 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
du_'42''45'isCommutativeSemigroup_606 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isCommutativeSemigroup_1474
      (coe
         MAlonzo.Code.Algebra.Structures.du_isCommutativeSemiringWithoutOne_1800
         (coe v0))
-- _.IsCommutativeSemiring.*-isMagma
d_'42''45'isMagma_608 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_'42''45'isMagma_608 ~v0 ~v1 ~v2 ~v3 v4
  = du_'42''45'isMagma_608 v4
du_'42''45'isMagma_608 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
du_'42''45'isMagma_608 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_'42''45'isMagma_1566
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
            (coe v1)))
-- _.IsCommutativeSemiring.*-isMonoid
d_'42''45'isMonoid_610 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_'42''45'isMonoid_610 ~v0 ~v1 ~v2 ~v3 v4
  = du_'42''45'isMonoid_610 v4
du_'42''45'isMonoid_610 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
du_'42''45'isMonoid_610 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_'42''45'isMonoid_1570
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
            (coe v1)))
-- _.IsCommutativeSemiring.*-isSemigroup
d_'42''45'isSemigroup_612 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_'42''45'isSemigroup_612 ~v0 ~v1 ~v2 ~v3 v4
  = du_'42''45'isSemigroup_612 v4
du_'42''45'isSemigroup_612 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
du_'42''45'isSemigroup_612 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_'42''45'isSemigroup_1568
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
            (coe v1)))
-- _.IsCommutativeSemiring.assoc
d_assoc_614 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_614 = erased
-- _.IsCommutativeSemiring.comm
d_comm_616 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_616 = erased
-- _.IsCommutativeSemiring.∙-cong
d_'8729''45'cong_618 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_618 = erased
-- _.IsCommutativeSemiring.∙-congʳ
d_'8729''45'cong'691'_620 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_620 = erased
-- _.IsCommutativeSemiring.∙-congˡ
d_'8729''45'cong'737'_622 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_622 = erased
-- _.IsCommutativeSemiring.identity
d_identity_624 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_624 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_746
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
               (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0)))))
-- _.IsCommutativeSemiring.identityʳ
d_identity'691'_626 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_626 = erased
-- _.IsCommutativeSemiring.identityˡ
d_identity'737'_628 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_628 = erased
-- _.IsCommutativeSemiring.isCommutativeMagma
d_isCommutativeMagma_630 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_630 ~v0 ~v1 ~v2 ~v3 v4
  = du_isCommutativeMagma_630 v4
du_isCommutativeMagma_630 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_630 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                    (coe v2) in
          coe
            (coe
               MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
               (coe
                  MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
                  (coe v3)))))
-- _.IsCommutativeSemiring.+-isCommutativeMonoid
d_'43''45'isCommutativeMonoid_632 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
d_'43''45'isCommutativeMonoid_632 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0)))
-- _.IsCommutativeSemiring.isCommutativeSemigroup
d_isCommutativeSemigroup_634 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_isCommutativeSemigroup_634 ~v0 ~v1 ~v2 ~v3 v4
  = du_isCommutativeSemigroup_634 v4
du_isCommutativeSemigroup_634 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
du_isCommutativeSemigroup_634 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
               (coe v2))))
-- _.IsCommutativeSemiring.isMagma
d_isMagma_636 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_636 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe
            MAlonzo.Code.Algebra.Structures.d_isMonoid_746
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0))))))
-- _.IsCommutativeSemiring.isMonoid
d_isMonoid_638 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_isMonoid_638 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMonoid_746
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
            (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0))))
-- _.IsCommutativeSemiring.isSemigroup
d_isSemigroup_640 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_640 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_746
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
               (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0)))))
-- _.IsCommutativeSemiring.isUnitalMagma
d_isUnitalMagma_642 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_642 ~v0 ~v1 ~v2 ~v3 v4 = du_isUnitalMagma_642 v4
du_isUnitalMagma_642 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_642 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                    (coe v2) in
          coe
            (coe
               MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
               (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v3)))))
-- _.IsCommutativeSemiring.distrib
d_distrib_644 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_distrib_644 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_distrib_1516
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0)))
-- _.IsCommutativeSemiring.distribʳ
d_distrib'691'_646 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'691'_646 = erased
-- _.IsCommutativeSemiring.distribˡ
d_distrib'737'_648 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'737'_648 = erased
-- _.IsCommutativeSemiring.isCommutativeSemiringWithoutOne
d_isCommutativeSemiringWithoutOne_650 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392
d_isCommutativeSemiringWithoutOne_650 v0 v1 v2 v3 v4
  = coe
      MAlonzo.Code.Algebra.Structures.du_isCommutativeSemiringWithoutOne_1800
      v4
-- _.IsCommutativeSemiring.isEquivalence
d_isEquivalence_652 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_652 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe
               MAlonzo.Code.Algebra.Structures.d_isMonoid_746
               (coe
                  MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                     (coe
                        MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0)))))))
-- _.IsCommutativeSemiring.isNearSemiring
d_isNearSemiring_654 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
d_isNearSemiring_654 ~v0 ~v1 ~v2 ~v3 v4 = du_isNearSemiring_654 v4
du_isNearSemiring_654 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
du_isNearSemiring_654 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isNearSemiring_1384
         (coe
            MAlonzo.Code.Algebra.Structures.du_isSemiringWithoutOne_1680
            (coe v1)))
-- _.IsCommutativeSemiring.isPartialEquivalence
d_isPartialEquivalence_656 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_656 ~v0 ~v1 ~v2 ~v3 v4
  = du_isPartialEquivalence_656 v4
du_isPartialEquivalence_656 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_656 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                    (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v3) in
             coe
               (let v5
                      = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v4) in
                coe
                  (let v6 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v5) in
                   coe
                     (coe
                        MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
                        (coe
                           MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v6))))))))
-- _.IsCommutativeSemiring.isSemiring
d_isSemiring_658 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590
d_isSemiring_658 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0)
-- _.IsCommutativeSemiring.isSemiringWithoutAnnihilatingZero
d_isSemiringWithoutAnnihilatingZero_660 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488
d_isSemiringWithoutAnnihilatingZero_660 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
      (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0))
-- _.IsCommutativeSemiring.isSemiringWithoutOne
d_isSemiringWithoutOne_662 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298
d_isSemiringWithoutOne_662 ~v0 ~v1 ~v2 ~v3 v4
  = du_isSemiringWithoutOne_662 v4
du_isSemiringWithoutOne_662 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298
du_isSemiringWithoutOne_662 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isSemiringWithoutOne_1680
      (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0))
-- _.IsCommutativeSemiring.refl
d_refl_664 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_664 = erased
-- _.IsCommutativeSemiring.reflexive
d_reflexive_666 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_666 = erased
-- _.IsCommutativeSemiring.setoid
d_setoid_668 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_668 ~v0 ~v1 ~v2 ~v3 v4 = du_setoid_668 v4
du_setoid_668 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_668 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                    (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v3) in
             coe
               (let v5
                      = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v4) in
                coe
                  (coe
                     MAlonzo.Code.Algebra.Structures.du_setoid_200
                     (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v5)))))))
-- _.IsCommutativeSemiring.sym
d_sym_670 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_670 = erased
-- _.IsCommutativeSemiring.trans
d_trans_672 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_672 = erased
-- _.IsCommutativeSemiring.zero
d_zero_674 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_zero_674 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_zero_1606
      (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1712 (coe v0))
-- _.IsCommutativeSemiring.zeroʳ
d_zero'691'_676 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'691'_676 = erased
-- _.IsCommutativeSemiring.zeroˡ
d_zero'737'_678 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiring_1698 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'737'_678 = erased
-- _.IsCommutativeSemiringWithoutOne.*-assoc
d_'42''45'assoc_682 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'assoc_682 = erased
-- _.IsCommutativeSemiringWithoutOne.*-comm
d_'42''45'comm_684 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'comm_684 = erased
-- _.IsCommutativeSemiringWithoutOne.*-cong
d_'42''45'cong_686 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'cong_686 = erased
-- _.IsCommutativeSemiringWithoutOne.∙-congʳ
d_'8729''45'cong'691'_688 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_688 = erased
-- _.IsCommutativeSemiringWithoutOne.∙-congˡ
d_'8729''45'cong'737'_690 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_690 = erased
-- _.IsCommutativeSemiringWithoutOne.isCommutativeMagma
d_isCommutativeMagma_692 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_692 ~v0 ~v1 ~v2 v3
  = du_isCommutativeMagma_692 v3
du_isCommutativeMagma_692 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_692 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
      (coe
         MAlonzo.Code.Algebra.Structures.du_'42''45'isCommutativeSemigroup_1474
         (coe v0))
-- _.IsCommutativeSemiringWithoutOne.*-isCommutativeSemigroup
d_'42''45'isCommutativeSemigroup_694 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_'42''45'isCommutativeSemigroup_694 v0 v1 v2 v3
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isCommutativeSemigroup_1474
      v3
-- _.IsCommutativeSemiringWithoutOne.*-isMagma
d_'42''45'isMagma_696 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_'42''45'isMagma_696 ~v0 ~v1 ~v2 v3 = du_'42''45'isMagma_696 v3
du_'42''45'isMagma_696 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
du_'42''45'isMagma_696 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isMagma_1366
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutOne_1404
         (coe v0))
-- _.IsCommutativeSemiringWithoutOne.*-isSemigroup
d_'42''45'isSemigroup_698 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_'42''45'isSemigroup_698 ~v0 ~v1 ~v2 v3
  = du_'42''45'isSemigroup_698 v3
du_'42''45'isSemigroup_698 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
du_'42''45'isSemigroup_698 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isSemigroup_1368
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutOne_1404
         (coe v0))
-- _.IsCommutativeSemiringWithoutOne.assoc
d_assoc_700 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_700 = erased
-- _.IsCommutativeSemiringWithoutOne.comm
d_comm_702 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_702 = erased
-- _.IsCommutativeSemiringWithoutOne.∙-cong
d_'8729''45'cong_704 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_704 = erased
-- _.IsCommutativeSemiringWithoutOne.∙-congʳ
d_'8729''45'cong'691'_706 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_706 = erased
-- _.IsCommutativeSemiringWithoutOne.∙-congˡ
d_'8729''45'cong'737'_708 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_708 = erased
-- _.IsCommutativeSemiringWithoutOne.identity
d_identity_710 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_710 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_746
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1316
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutOne_1404
               (coe v0))))
-- _.IsCommutativeSemiringWithoutOne.identityʳ
d_identity'691'_712 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_712 = erased
-- _.IsCommutativeSemiringWithoutOne.identityˡ
d_identity'737'_714 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_714 = erased
-- _.IsCommutativeSemiringWithoutOne.isCommutativeMagma
d_isCommutativeMagma_716 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_716 ~v0 ~v1 ~v2 v3
  = du_isCommutativeMagma_716 v3
du_isCommutativeMagma_716 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_716 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutOne_1404
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1316
                 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
            (coe
               MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
               (coe v2))))
-- _.IsCommutativeSemiringWithoutOne.+-isCommutativeMonoid
d_'43''45'isCommutativeMonoid_718 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
d_'43''45'isCommutativeMonoid_718 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1316
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutOne_1404
         (coe v0))
-- _.IsCommutativeSemiringWithoutOne.isCommutativeSemigroup
d_isCommutativeSemigroup_720 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_isCommutativeSemigroup_720 ~v0 ~v1 ~v2 v3
  = du_isCommutativeSemigroup_720 v3
du_isCommutativeSemigroup_720 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
du_isCommutativeSemigroup_720 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutOne_1404
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1316
            (coe v1)))
-- _.IsCommutativeSemiringWithoutOne.isMonoid
d_isMonoid_722 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_isMonoid_722 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMonoid_746
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1316
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutOne_1404
            (coe v0)))
-- _.IsCommutativeSemiringWithoutOne.distrib
d_distrib_724 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_distrib_724 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_distrib_1322
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutOne_1404
         (coe v0))
-- _.IsCommutativeSemiringWithoutOne.distribʳ
d_distrib'691'_726 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'691'_726 = erased
-- _.IsCommutativeSemiringWithoutOne.distribˡ
d_distrib'737'_728 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'737'_728 = erased
-- _.IsCommutativeSemiringWithoutOne.isEquivalence
d_isEquivalence_730 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_730 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe
               MAlonzo.Code.Algebra.Structures.d_isMonoid_746
               (coe
                  MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1316
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutOne_1404
                     (coe v0))))))
-- _.IsCommutativeSemiringWithoutOne.isNearSemiring
d_isNearSemiring_732 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
d_isNearSemiring_732 ~v0 ~v1 ~v2 v3 = du_isNearSemiring_732 v3
du_isNearSemiring_732 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
du_isNearSemiring_732 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isNearSemiring_1384
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutOne_1404
         (coe v0))
-- _.IsCommutativeSemiringWithoutOne.isPartialEquivalence
d_isPartialEquivalence_734 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_734 ~v0 ~v1 ~v2 v3
  = du_isPartialEquivalence_734 v3
du_isPartialEquivalence_734 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_734 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutOne_1404
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
         (coe
            MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
            (coe
               MAlonzo.Code.Algebra.Structures.d_isMagma_480
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isMonoid_746
                     (coe
                        MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1316
                        (coe v1)))))))
-- _.IsCommutativeSemiringWithoutOne.isSemiringWithoutOne
d_isSemiringWithoutOne_736 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298
d_isSemiringWithoutOne_736 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutOne_1404
      (coe v0)
-- _.IsCommutativeSemiringWithoutOne.refl
d_refl_738 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_738 = erased
-- _.IsCommutativeSemiringWithoutOne.reflexive
d_reflexive_740 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_740 = erased
-- _.IsCommutativeSemiringWithoutOne.setoid
d_setoid_742 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_742 ~v0 ~v1 ~v2 v3 = du_setoid_742 v3
du_setoid_742 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_742 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutOne_1404
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1316
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v3) in
             coe
               (coe
                  MAlonzo.Code.Algebra.Structures.du_setoid_200
                  (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v4))))))
-- _.IsCommutativeSemiringWithoutOne.sym
d_sym_744 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_744 = erased
-- _.IsCommutativeSemiringWithoutOne.trans
d_trans_746 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_746 = erased
-- _.IsCommutativeSemiringWithoutOne.zero
d_zero_748 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_zero_748 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_zero_1324
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutOne_1404
         (coe v0))
-- _.IsCommutativeSemiringWithoutOne.zeroʳ
d_zero'691'_750 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'691'_750 = erased
-- _.IsCommutativeSemiringWithoutOne.zeroˡ
d_zero'737'_752 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemiringWithoutOne_1392 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'737'_752 = erased
-- _.IsFlexibleMagma.flex
d_flex_756 ::
  MAlonzo.Code.Algebra.Structures.T_IsFlexibleMagma_324 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_flex_756 = erased
-- _.IsFlexibleMagma.isEquivalence
d_isEquivalence_758 ::
  MAlonzo.Code.Algebra.Structures.T_IsFlexibleMagma_324 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_758 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_332 (coe v0))
-- _.IsFlexibleMagma.isMagma
d_isMagma_760 ::
  MAlonzo.Code.Algebra.Structures.T_IsFlexibleMagma_324 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_760 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isMagma_332 (coe v0)
-- _.IsFlexibleMagma.isPartialEquivalence
d_isPartialEquivalence_762 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsFlexibleMagma_324 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_762 ~v0 v1 = du_isPartialEquivalence_762 v1
du_isPartialEquivalence_762 ::
  MAlonzo.Code.Algebra.Structures.T_IsFlexibleMagma_324 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_762 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isMagma_332 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
         (coe MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v1)))
-- _.IsFlexibleMagma.refl
d_refl_764 ::
  MAlonzo.Code.Algebra.Structures.T_IsFlexibleMagma_324 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_764 = erased
-- _.IsFlexibleMagma.reflexive
d_reflexive_766 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsFlexibleMagma_324 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_766 = erased
-- _.IsFlexibleMagma.setoid
d_setoid_768 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsFlexibleMagma_324 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_768 ~v0 v1 = du_setoid_768 v1
du_setoid_768 ::
  MAlonzo.Code.Algebra.Structures.T_IsFlexibleMagma_324 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_768 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_setoid_200
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_332 (coe v0))
-- _.IsFlexibleMagma.sym
d_sym_770 ::
  MAlonzo.Code.Algebra.Structures.T_IsFlexibleMagma_324 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_770 = erased
-- _.IsFlexibleMagma.trans
d_trans_772 ::
  MAlonzo.Code.Algebra.Structures.T_IsFlexibleMagma_324 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_772 = erased
-- _.IsFlexibleMagma.∙-cong
d_'8729''45'cong_774 ::
  MAlonzo.Code.Algebra.Structures.T_IsFlexibleMagma_324 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_774 = erased
-- _.IsFlexibleMagma.∙-congʳ
d_'8729''45'cong'691'_776 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsFlexibleMagma_324 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_776 = erased
-- _.IsFlexibleMagma.∙-congˡ
d_'8729''45'cong'737'_778 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsFlexibleMagma_324 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_778 = erased
-- _.IsGroup._-_
d__'45'__782 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d__'45'__782 v0 v1 v2 v3
  = coe MAlonzo.Code.Algebra.Structures.du__'45'__1104 v0 v2
-- _.IsGroup._//_
d__'47''47'__784 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d__'47''47'__784 v0 v1 v2 v3 v4 v5
  = coe
      MAlonzo.Code.Algebra.Structures.du__'47''47'__1098 v0 v2 v4 v5
-- _.IsGroup._\\_
d__'92''92'__786 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d__'92''92'__786 v0 v1 v2 v3 v4 v5
  = coe
      MAlonzo.Code.Algebra.Structures.du__'92''92'__1092 v0 v2 v4 v5
-- _.IsGroup.assoc
d_assoc_788 ::
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_788 = erased
-- _.IsGroup.identity
d_identity_790 ::
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_790 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v0))
-- _.IsGroup.identityʳ
d_identity'691'_792 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_792 = erased
-- _.IsGroup.identityˡ
d_identity'737'_794 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_794 = erased
-- _.IsGroup.inverse
d_inverse_796 ::
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_inverse_796 v0
  = coe MAlonzo.Code.Algebra.Structures.d_inverse_1052 (coe v0)
-- _.IsGroup.inverseʳ
d_inverse'691'_798 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_inverse'691'_798 = erased
-- _.IsGroup.inverseˡ
d_inverse'737'_800 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_inverse'737'_800 = erased
-- _.IsGroup.isEquivalence
d_isEquivalence_802 ::
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_802 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v0))))
-- _.IsGroup.isInvertibleMagma
d_isInvertibleMagma_804 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924
d_isInvertibleMagma_804 v0 v1 v2 v3
  = coe MAlonzo.Code.Algebra.Structures.du_isInvertibleMagma_1122 v3
-- _.IsGroup.isInvertibleUnitalMagma
d_isInvertibleUnitalMagma_806 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976
d_isInvertibleUnitalMagma_806 v0 v1 v2 v3
  = coe
      MAlonzo.Code.Algebra.Structures.du_isInvertibleUnitalMagma_1124 v3
-- _.IsGroup.isMagma
d_isMagma_808 ::
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_808 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v0)))
-- _.IsGroup.isMonoid
d_isMonoid_810 ::
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_isMonoid_810 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v0)
-- _.IsGroup.isPartialEquivalence
d_isPartialEquivalence_812 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_812 ~v0 ~v1 ~v2 v3
  = du_isPartialEquivalence_812 v3
du_isPartialEquivalence_812 ::
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_812 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v1) in
       coe
         (let v3 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v2) in
          coe
            (coe
               MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v3)))))
-- _.IsGroup.isSemigroup
d_isSemigroup_814 ::
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_814 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
      (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v0))
-- _.IsGroup.isUnitalMagma
d_isUnitalMagma_816 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_816 ~v0 ~v1 ~v2 v3 = du_isUnitalMagma_816 v3
du_isUnitalMagma_816 ::
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_816 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
      (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v0))
-- _.IsGroup.refl
d_refl_818 ::
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_818 = erased
-- _.IsGroup.reflexive
d_reflexive_820 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_820 = erased
-- _.IsGroup.setoid
d_setoid_822 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_822 ~v0 ~v1 ~v2 v3 = du_setoid_822 v3
du_setoid_822 ::
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_822 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_setoid_200
            (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v2))))
-- _.IsGroup.sym
d_sym_824 ::
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_824 = erased
-- _.IsGroup.trans
d_trans_826 ::
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_826 = erased
-- _.IsGroup.uniqueʳ-⁻¹
d_unique'691''45''8315''185'_828 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_unique'691''45''8315''185'_828 = erased
-- _.IsGroup.uniqueˡ-⁻¹
d_unique'737''45''8315''185'_830 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_unique'737''45''8315''185'_830 = erased
-- _.IsGroup.⁻¹-cong
d_'8315''185''45'cong_832 ::
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8315''185''45'cong_832 = erased
-- _.IsGroup.∙-cong
d_'8729''45'cong_834 ::
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_834 = erased
-- _.IsGroup.∙-congʳ
d_'8729''45'cong'691'_836 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_836 = erased
-- _.IsGroup.∙-congˡ
d_'8729''45'cong'737'_838 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_838 = erased
-- _.IsIdempotentCommutativeMonoid.assoc
d_assoc_842 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_842 = erased
-- _.IsIdempotentCommutativeMonoid.comm
d_comm_844 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_844 = erased
-- _.IsIdempotentCommutativeMonoid.idem
d_idem_846 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_idem_846 = erased
-- _.IsIdempotentCommutativeMonoid.identity
d_identity_848 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_848 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_746
         (coe
            MAlonzo.Code.Algebra.Structures.d_isCommutativeMonoid_862
            (coe v0)))
-- _.IsIdempotentCommutativeMonoid.identityʳ
d_identity'691'_850 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_850 = erased
-- _.IsIdempotentCommutativeMonoid.identityˡ
d_identity'737'_852 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_852 = erased
-- _.IsIdempotentCommutativeMonoid.isBand
d_isBand_854 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Algebra.Structures.T_IsBand_508
d_isBand_854 ~v0 ~v1 v2 = du_isBand_854 v2
du_isBand_854 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Algebra.Structures.T_IsBand_508
du_isBand_854 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isBand_846
      (coe
         MAlonzo.Code.Algebra.Structures.du_isIdempotentMonoid_910 (coe v0))
-- _.IsIdempotentCommutativeMonoid.isCommutativeBand
d_isCommutativeBand_856 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590
d_isCommutativeBand_856 v0 v1 v2
  = coe MAlonzo.Code.Algebra.Structures.du_isCommutativeBand_916 v2
-- _.IsIdempotentCommutativeMonoid.isCommutativeMagma
d_isCommutativeMagma_858 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_858 ~v0 ~v1 v2 = du_isCommutativeMagma_858 v2
du_isCommutativeMagma_858 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_858 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isCommutativeMonoid_862
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
            (coe v1)))
-- _.IsIdempotentCommutativeMonoid.isCommutativeMonoid
d_isCommutativeMonoid_860 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
d_isCommutativeMonoid_860 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isCommutativeMonoid_862 (coe v0)
-- _.IsIdempotentCommutativeMonoid.isCommutativeSemigroup
d_isCommutativeSemigroup_862 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_isCommutativeSemigroup_862 ~v0 ~v1 v2
  = du_isCommutativeSemigroup_862 v2
du_isCommutativeSemigroup_862 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
du_isCommutativeSemigroup_862 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
      (coe
         MAlonzo.Code.Algebra.Structures.d_isCommutativeMonoid_862 (coe v0))
-- _.IsIdempotentCommutativeMonoid.isEquivalence
d_isEquivalence_864 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_864 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe
               MAlonzo.Code.Algebra.Structures.d_isMonoid_746
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isCommutativeMonoid_862
                  (coe v0)))))
-- _.IsIdempotentCommutativeMonoid.isIdempotentMonoid
d_isIdempotentMonoid_866 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796
d_isIdempotentMonoid_866 v0 v1 v2
  = coe MAlonzo.Code.Algebra.Structures.du_isIdempotentMonoid_910 v2
-- _.IsIdempotentCommutativeMonoid.isMagma
d_isMagma_868 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_868 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe
            MAlonzo.Code.Algebra.Structures.d_isMonoid_746
            (coe
               MAlonzo.Code.Algebra.Structures.d_isCommutativeMonoid_862
               (coe v0))))
-- _.IsIdempotentCommutativeMonoid.isMonoid
d_isMonoid_870 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_isMonoid_870 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMonoid_746
      (coe
         MAlonzo.Code.Algebra.Structures.d_isCommutativeMonoid_862 (coe v0))
-- _.IsIdempotentCommutativeMonoid.isPartialEquivalence
d_isPartialEquivalence_872 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_872 ~v0 ~v1 v2
  = du_isPartialEquivalence_872 v2
du_isPartialEquivalence_872 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_872 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isCommutativeMonoid_862
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v2) in
          coe
            (let v4 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v3) in
             coe
               (coe
                  MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v4))))))
-- _.IsIdempotentCommutativeMonoid.isSemigroup
d_isSemigroup_874 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_874 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_746
         (coe
            MAlonzo.Code.Algebra.Structures.d_isCommutativeMonoid_862
            (coe v0)))
-- _.IsIdempotentCommutativeMonoid.isUnitalMagma
d_isUnitalMagma_876 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_876 ~v0 ~v1 v2 = du_isUnitalMagma_876 v2
du_isUnitalMagma_876 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_876 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isCommutativeMonoid_862
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
         (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v1)))
-- _.IsIdempotentCommutativeMonoid.refl
d_refl_878 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_878 = erased
-- _.IsIdempotentCommutativeMonoid.reflexive
d_reflexive_880 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_880 = erased
-- _.IsIdempotentCommutativeMonoid.setoid
d_setoid_882 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_882 ~v0 ~v1 v2 = du_setoid_882 v2
du_setoid_882 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_882 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isCommutativeMonoid_862
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v2) in
          coe
            (coe
               MAlonzo.Code.Algebra.Structures.du_setoid_200
               (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v3)))))
-- _.IsIdempotentCommutativeMonoid.sym
d_sym_884 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_884 = erased
-- _.IsIdempotentCommutativeMonoid.trans
d_trans_886 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_886 = erased
-- _.IsIdempotentCommutativeMonoid.∙-cong
d_'8729''45'cong_888 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_888 = erased
-- _.IsIdempotentCommutativeMonoid.∙-congʳ
d_'8729''45'cong'691'_890 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_890 = erased
-- _.IsIdempotentCommutativeMonoid.∙-congˡ
d_'8729''45'cong'737'_892 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_892 = erased
-- _.IsIdempotentMagma.idem
d_idem_896 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMagma_248 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_idem_896 = erased
-- _.IsIdempotentMagma.isEquivalence
d_isEquivalence_898 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMagma_248 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_898 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_256 (coe v0))
-- _.IsIdempotentMagma.isMagma
d_isMagma_900 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMagma_248 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_900 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isMagma_256 (coe v0)
-- _.IsIdempotentMagma.isPartialEquivalence
d_isPartialEquivalence_902 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMagma_248 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_902 ~v0 v1 = du_isPartialEquivalence_902 v1
du_isPartialEquivalence_902 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMagma_248 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_902 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isMagma_256 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
         (coe MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v1)))
-- _.IsIdempotentMagma.refl
d_refl_904 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMagma_248 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_904 = erased
-- _.IsIdempotentMagma.reflexive
d_reflexive_906 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMagma_248 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_906 = erased
-- _.IsIdempotentMagma.setoid
d_setoid_908 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMagma_248 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_908 ~v0 v1 = du_setoid_908 v1
du_setoid_908 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMagma_248 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_908 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_setoid_200
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_256 (coe v0))
-- _.IsIdempotentMagma.sym
d_sym_910 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMagma_248 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_910 = erased
-- _.IsIdempotentMagma.trans
d_trans_912 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMagma_248 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_912 = erased
-- _.IsIdempotentMagma.∙-cong
d_'8729''45'cong_914 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMagma_248 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_914 = erased
-- _.IsIdempotentMagma.∙-congʳ
d_'8729''45'cong'691'_916 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMagma_248 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_916 = erased
-- _.IsIdempotentMagma.∙-congˡ
d_'8729''45'cong'737'_918 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMagma_248 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_918 = erased
-- _.IsIdempotentMonoid.assoc
d_assoc_922 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_922 = erased
-- _.IsIdempotentMonoid.idem
d_idem_924 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_idem_924 = erased
-- _.IsIdempotentMonoid.identity
d_identity_926 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_926 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_806 (coe v0))
-- _.IsIdempotentMonoid.identityʳ
d_identity'691'_928 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_928 = erased
-- _.IsIdempotentMonoid.identityˡ
d_identity'737'_930 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_930 = erased
-- _.IsIdempotentMonoid.isBand
d_isBand_932 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Algebra.Structures.T_IsBand_508
d_isBand_932 v0 v1 v2
  = coe MAlonzo.Code.Algebra.Structures.du_isBand_846 v2
-- _.IsIdempotentMonoid.isEquivalence
d_isEquivalence_934 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_934 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_806 (coe v0))))
-- _.IsIdempotentMonoid.isMagma
d_isMagma_936 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_936 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_806 (coe v0)))
-- _.IsIdempotentMonoid.isMonoid
d_isMonoid_938 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_isMonoid_938 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isMonoid_806 (coe v0)
-- _.IsIdempotentMonoid.isPartialEquivalence
d_isPartialEquivalence_940 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_940 ~v0 ~v1 v2
  = du_isPartialEquivalence_940 v2
du_isPartialEquivalence_940 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_940 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isMonoid_806 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v1) in
       coe
         (let v3 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v2) in
          coe
            (coe
               MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v3)))))
-- _.IsIdempotentMonoid.isSemigroup
d_isSemigroup_942 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_942 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
      (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_806 (coe v0))
-- _.IsIdempotentMonoid.isUnitalMagma
d_isUnitalMagma_944 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_944 ~v0 ~v1 v2 = du_isUnitalMagma_944 v2
du_isUnitalMagma_944 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_944 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
      (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_806 (coe v0))
-- _.IsIdempotentMonoid.refl
d_refl_946 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_946 = erased
-- _.IsIdempotentMonoid.reflexive
d_reflexive_948 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_948 = erased
-- _.IsIdempotentMonoid.setoid
d_setoid_950 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_950 ~v0 ~v1 v2 = du_setoid_950 v2
du_setoid_950 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_950 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isMonoid_806 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_setoid_200
            (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v2))))
-- _.IsIdempotentMonoid.sym
d_sym_952 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_952 = erased
-- _.IsIdempotentMonoid.trans
d_trans_954 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_954 = erased
-- _.IsIdempotentMonoid.∙-cong
d_'8729''45'cong_956 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_956 = erased
-- _.IsIdempotentMonoid.∙-congʳ
d_'8729''45'cong'691'_958 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_958 = erased
-- _.IsIdempotentMonoid.∙-congˡ
d_'8729''45'cong'737'_960 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_960 = erased
-- _.IsIdempotentSemiring.*-assoc
d_'42''45'assoc_964 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'assoc_964 = erased
-- _.IsIdempotentSemiring.*-cong
d_'42''45'cong_966 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'cong_966 = erased
-- _.IsIdempotentSemiring.∙-congʳ
d_'8729''45'cong'691'_968 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_968 = erased
-- _.IsIdempotentSemiring.∙-congˡ
d_'8729''45'cong'737'_970 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_970 = erased
-- _.IsIdempotentSemiring.*-identity
d_'42''45'identity_972 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_'42''45'identity_972 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'42''45'identity_1514
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0)))
-- _.IsIdempotentSemiring.identityʳ
d_identity'691'_974 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_974 = erased
-- _.IsIdempotentSemiring.identityˡ
d_identity'737'_976 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_976 = erased
-- _.IsIdempotentSemiring.*-isMagma
d_'42''45'isMagma_978 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_'42''45'isMagma_978 ~v0 ~v1 ~v2 ~v3 v4
  = du_'42''45'isMagma_978 v4
du_'42''45'isMagma_978 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
du_'42''45'isMagma_978 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_'42''45'isMagma_1566
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
            (coe v1)))
-- _.IsIdempotentSemiring.*-isMonoid
d_'42''45'isMonoid_980 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_'42''45'isMonoid_980 ~v0 ~v1 ~v2 ~v3 v4
  = du_'42''45'isMonoid_980 v4
du_'42''45'isMonoid_980 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
du_'42''45'isMonoid_980 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_'42''45'isMonoid_1570
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
            (coe v1)))
-- _.IsIdempotentSemiring.*-isSemigroup
d_'42''45'isSemigroup_982 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_'42''45'isSemigroup_982 ~v0 ~v1 ~v2 ~v3 v4
  = du_'42''45'isSemigroup_982 v4
du_'42''45'isSemigroup_982 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
du_'42''45'isSemigroup_982 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_'42''45'isSemigroup_1568
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
            (coe v1)))
-- _.IsIdempotentSemiring.assoc
d_assoc_984 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_984 = erased
-- _.IsIdempotentSemiring.comm
d_comm_986 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_986 = erased
-- _.IsIdempotentSemiring.∙-cong
d_'8729''45'cong_988 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_988 = erased
-- _.IsIdempotentSemiring.∙-congʳ
d_'8729''45'cong'691'_990 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_990 = erased
-- _.IsIdempotentSemiring.∙-congˡ
d_'8729''45'cong'737'_992 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_992 = erased
-- _.IsIdempotentSemiring.+-idem
d_'43''45'idem_994 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'43''45'idem_994 = erased
-- _.IsIdempotentSemiring.identity
d_identity_996 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_996 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_746
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
               (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0)))))
-- _.IsIdempotentSemiring.identityʳ
d_identity'691'_998 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_998 = erased
-- _.IsIdempotentSemiring.identityˡ
d_identity'737'_1000 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1000 = erased
-- _.IsIdempotentSemiring.isBand
d_isBand_1002 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsBand_508
d_isBand_1002 ~v0 ~v1 ~v2 ~v3 v4 = du_isBand_1002 v4
du_isBand_1002 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsBand_508
du_isBand_1002 v0
  = let v1
          = coe
              MAlonzo.Code.Algebra.Structures.du_'43''45'isIdempotentCommutativeMonoid_2044
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isBand_846
         (coe
            MAlonzo.Code.Algebra.Structures.du_isIdempotentMonoid_910
            (coe v1)))
-- _.IsIdempotentSemiring.isCommutativeBand
d_isCommutativeBand_1004 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590
d_isCommutativeBand_1004 ~v0 ~v1 ~v2 ~v3 v4
  = du_isCommutativeBand_1004 v4
du_isCommutativeBand_1004 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590
du_isCommutativeBand_1004 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isCommutativeBand_916
      (coe
         MAlonzo.Code.Algebra.Structures.du_'43''45'isIdempotentCommutativeMonoid_2044
         (coe v0))
-- _.IsIdempotentSemiring.isCommutativeMagma
d_isCommutativeMagma_1006 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_1006 ~v0 ~v1 ~v2 ~v3 v4
  = du_isCommutativeMagma_1006 v4
du_isCommutativeMagma_1006 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_1006 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                    (coe v2) in
          coe
            (coe
               MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
               (coe
                  MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
                  (coe v3)))))
-- _.IsIdempotentSemiring.+-isCommutativeMonoid
d_'43''45'isCommutativeMonoid_1008 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
d_'43''45'isCommutativeMonoid_1008 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0)))
-- _.IsIdempotentSemiring.isCommutativeSemigroup
d_isCommutativeSemigroup_1010 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_isCommutativeSemigroup_1010 ~v0 ~v1 ~v2 ~v3 v4
  = du_isCommutativeSemigroup_1010 v4
du_isCommutativeSemigroup_1010 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
du_isCommutativeSemigroup_1010 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
               (coe v2))))
-- _.IsIdempotentSemiring.+-isIdempotentCommutativeMonoid
d_'43''45'isIdempotentCommutativeMonoid_1012 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852
d_'43''45'isIdempotentCommutativeMonoid_1012 v0 v1 v2 v3 v4
  = coe
      MAlonzo.Code.Algebra.Structures.du_'43''45'isIdempotentCommutativeMonoid_2044
      v4
-- _.IsIdempotentSemiring.isIdempotentMonoid
d_isIdempotentMonoid_1014 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796
d_isIdempotentMonoid_1014 ~v0 ~v1 ~v2 ~v3 v4
  = du_isIdempotentMonoid_1014 v4
du_isIdempotentMonoid_1014 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796
du_isIdempotentMonoid_1014 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isIdempotentMonoid_910
      (coe
         MAlonzo.Code.Algebra.Structures.du_'43''45'isIdempotentCommutativeMonoid_2044
         (coe v0))
-- _.IsIdempotentSemiring.isMagma
d_isMagma_1016 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_1016 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe
            MAlonzo.Code.Algebra.Structures.d_isMonoid_746
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0))))))
-- _.IsIdempotentSemiring.isMonoid
d_isMonoid_1018 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_isMonoid_1018 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMonoid_746
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
            (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0))))
-- _.IsIdempotentSemiring.isSemigroup
d_isSemigroup_1020 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_1020 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_746
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
               (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0)))))
-- _.IsIdempotentSemiring.isUnitalMagma
d_isUnitalMagma_1022 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_1022 ~v0 ~v1 ~v2 ~v3 v4 = du_isUnitalMagma_1022 v4
du_isUnitalMagma_1022 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_1022 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                    (coe v2) in
          coe
            (coe
               MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
               (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v3)))))
-- _.IsIdempotentSemiring.distrib
d_distrib_1024 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_distrib_1024 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_distrib_1516
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0)))
-- _.IsIdempotentSemiring.distribʳ
d_distrib'691'_1026 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'691'_1026 = erased
-- _.IsIdempotentSemiring.distribˡ
d_distrib'737'_1028 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'737'_1028 = erased
-- _.IsIdempotentSemiring.isEquivalence
d_isEquivalence_1030 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_1030 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe
               MAlonzo.Code.Algebra.Structures.d_isMonoid_746
               (coe
                  MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                     (coe
                        MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0)))))))
-- _.IsIdempotentSemiring.isNearSemiring
d_isNearSemiring_1032 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
d_isNearSemiring_1032 ~v0 ~v1 ~v2 ~v3 v4
  = du_isNearSemiring_1032 v4
du_isNearSemiring_1032 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
du_isNearSemiring_1032 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isNearSemiring_1384
         (coe
            MAlonzo.Code.Algebra.Structures.du_isSemiringWithoutOne_1680
            (coe v1)))
-- _.IsIdempotentSemiring.isPartialEquivalence
d_isPartialEquivalence_1034 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_1034 ~v0 ~v1 ~v2 ~v3 v4
  = du_isPartialEquivalence_1034 v4
du_isPartialEquivalence_1034 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_1034 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                    (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v3) in
             coe
               (let v5
                      = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v4) in
                coe
                  (let v6 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v5) in
                   coe
                     (coe
                        MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
                        (coe
                           MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v6))))))))
-- _.IsIdempotentSemiring.isSemiring
d_isSemiring_1036 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590
d_isSemiring_1036 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0)
-- _.IsIdempotentSemiring.isSemiringWithoutAnnihilatingZero
d_isSemiringWithoutAnnihilatingZero_1038 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488
d_isSemiringWithoutAnnihilatingZero_1038 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
      (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0))
-- _.IsIdempotentSemiring.isSemiringWithoutOne
d_isSemiringWithoutOne_1040 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298
d_isSemiringWithoutOne_1040 ~v0 ~v1 ~v2 ~v3 v4
  = du_isSemiringWithoutOne_1040 v4
du_isSemiringWithoutOne_1040 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298
du_isSemiringWithoutOne_1040 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isSemiringWithoutOne_1680
      (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0))
-- _.IsIdempotentSemiring.refl
d_refl_1042 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_1042 = erased
-- _.IsIdempotentSemiring.reflexive
d_reflexive_1044 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_1044 = erased
-- _.IsIdempotentSemiring.setoid
d_setoid_1046 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_1046 ~v0 ~v1 ~v2 ~v3 v4 = du_setoid_1046 v4
du_setoid_1046 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_1046 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                    (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v3) in
             coe
               (let v5
                      = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v4) in
                coe
                  (coe
                     MAlonzo.Code.Algebra.Structures.du_setoid_200
                     (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v5)))))))
-- _.IsIdempotentSemiring.sym
d_sym_1048 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_1048 = erased
-- _.IsIdempotentSemiring.trans
d_trans_1050 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_1050 = erased
-- _.IsIdempotentSemiring.zero
d_zero_1052 ::
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_zero_1052 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_zero_1606
      (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v0))
-- _.IsIdempotentSemiring.zeroʳ
d_zero'691'_1054 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'691'_1054 = erased
-- _.IsIdempotentSemiring.zeroˡ
d_zero'737'_1056 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'737'_1056 = erased
-- _.IsInvertibleMagma.inverse
d_inverse_1060 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_inverse_1060 v0
  = coe MAlonzo.Code.Algebra.Structures.d_inverse_940 (coe v0)
-- _.IsInvertibleMagma.inverseʳ
d_inverse'691'_1062 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_inverse'691'_1062 = erased
-- _.IsInvertibleMagma.inverseˡ
d_inverse'737'_1064 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_inverse'737'_1064 = erased
-- _.IsInvertibleMagma.isEquivalence
d_isEquivalence_1066 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_1066 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_938 (coe v0))
-- _.IsInvertibleMagma.isMagma
d_isMagma_1068 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_1068 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isMagma_938 (coe v0)
-- _.IsInvertibleMagma.isPartialEquivalence
d_isPartialEquivalence_1070 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_1070 ~v0 ~v1 ~v2 v3
  = du_isPartialEquivalence_1070 v3
du_isPartialEquivalence_1070 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_1070 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isMagma_938 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
         (coe MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v1)))
-- _.IsInvertibleMagma.refl
d_refl_1072 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_1072 = erased
-- _.IsInvertibleMagma.reflexive
d_reflexive_1074 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_1074 = erased
-- _.IsInvertibleMagma.setoid
d_setoid_1076 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_1076 ~v0 ~v1 ~v2 v3 = du_setoid_1076 v3
du_setoid_1076 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_1076 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_setoid_200
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_938 (coe v0))
-- _.IsInvertibleMagma.sym
d_sym_1078 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_1078 = erased
-- _.IsInvertibleMagma.trans
d_trans_1080 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_1080 = erased
-- _.IsInvertibleMagma.⁻¹-cong
d_'8315''185''45'cong_1082 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8315''185''45'cong_1082 = erased
-- _.IsInvertibleMagma.∙-cong
d_'8729''45'cong_1084 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_1084 = erased
-- _.IsInvertibleMagma.∙-congʳ
d_'8729''45'cong'691'_1086 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1086 = erased
-- _.IsInvertibleMagma.∙-congˡ
d_'8729''45'cong'737'_1088 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1088 = erased
-- _.IsInvertibleUnitalMagma.identity
d_identity_1092 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_1092 v0
  = coe MAlonzo.Code.Algebra.Structures.d_identity_990 (coe v0)
-- _.IsInvertibleUnitalMagma.identityʳ
d_identity'691'_1094 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1094 = erased
-- _.IsInvertibleUnitalMagma.identityˡ
d_identity'737'_1096 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1096 = erased
-- _.IsInvertibleUnitalMagma.inverse
d_inverse_1098 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_inverse_1098 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_inverse_940
      (coe
         MAlonzo.Code.Algebra.Structures.d_isInvertibleMagma_988 (coe v0))
-- _.IsInvertibleUnitalMagma.inverseʳ
d_inverse'691'_1100 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_inverse'691'_1100 = erased
-- _.IsInvertibleUnitalMagma.inverseˡ
d_inverse'737'_1102 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_inverse'737'_1102 = erased
-- _.IsInvertibleUnitalMagma.isEquivalence
d_isEquivalence_1104 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_1104 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_938
         (coe
            MAlonzo.Code.Algebra.Structures.d_isInvertibleMagma_988 (coe v0)))
-- _.IsInvertibleUnitalMagma.isInvertibleMagma
d_isInvertibleMagma_1106 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924
d_isInvertibleMagma_1106 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isInvertibleMagma_988 (coe v0)
-- _.IsInvertibleUnitalMagma.isMagma
d_isMagma_1108 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_1108 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_938
      (coe
         MAlonzo.Code.Algebra.Structures.d_isInvertibleMagma_988 (coe v0))
-- _.IsInvertibleUnitalMagma.isPartialEquivalence
d_isPartialEquivalence_1110 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_1110 ~v0 ~v1 ~v2 v3
  = du_isPartialEquivalence_1110 v3
du_isPartialEquivalence_1110 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_1110 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isInvertibleMagma_988
              (coe v0) in
    coe
      (let v2 = MAlonzo.Code.Algebra.Structures.d_isMagma_938 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
            (coe
               MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v2))))
-- _.IsInvertibleUnitalMagma.isUnitalMagma
d_isUnitalMagma_1112 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_1112 v0 v1 v2 v3
  = coe MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_1028 v3
-- _.IsInvertibleUnitalMagma.refl
d_refl_1114 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_1114 = erased
-- _.IsInvertibleUnitalMagma.reflexive
d_reflexive_1116 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_1116 = erased
-- _.IsInvertibleUnitalMagma.setoid
d_setoid_1118 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_1118 ~v0 ~v1 ~v2 v3 = du_setoid_1118 v3
du_setoid_1118 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_1118 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isInvertibleMagma_988
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_setoid_200
         (coe MAlonzo.Code.Algebra.Structures.d_isMagma_938 (coe v1)))
-- _.IsInvertibleUnitalMagma.sym
d_sym_1120 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_1120 = erased
-- _.IsInvertibleUnitalMagma.trans
d_trans_1122 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_1122 = erased
-- _.IsInvertibleUnitalMagma.⁻¹-cong
d_'8315''185''45'cong_1124 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8315''185''45'cong_1124 = erased
-- _.IsInvertibleUnitalMagma.∙-cong
d_'8729''45'cong_1126 ::
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_1126 = erased
-- _.IsInvertibleUnitalMagma.∙-congʳ
d_'8729''45'cong'691'_1128 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1128 = erased
-- _.IsInvertibleUnitalMagma.∙-congˡ
d_'8729''45'cong'737'_1130 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1130 = erased
-- _.IsKleeneAlgebra.*-assoc
d_'42''45'assoc_1134 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'assoc_1134 = erased
-- _.IsKleeneAlgebra.*-cong
d_'42''45'cong_1136 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'cong_1136 = erased
-- _.IsKleeneAlgebra.∙-congʳ
d_'8729''45'cong'691'_1138 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1138 = erased
-- _.IsKleeneAlgebra.∙-congˡ
d_'8729''45'cong'737'_1140 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1140 = erased
-- _.IsKleeneAlgebra.*-identity
d_'42''45'identity_1142 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_'42''45'identity_1142 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'42''45'identity_1514
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiring_1956
            (coe
               MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
               (coe v0))))
-- _.IsKleeneAlgebra.identityʳ
d_identity'691'_1144 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1144 = erased
-- _.IsKleeneAlgebra.identityˡ
d_identity'737'_1146 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1146 = erased
-- _.IsKleeneAlgebra.*-isMagma
d_'42''45'isMagma_1148 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_'42''45'isMagma_1148 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_'42''45'isMagma_1148 v5
du_'42''45'isMagma_1148 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
du_'42''45'isMagma_1148 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_'42''45'isMagma_1566
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
               (coe v2))))
-- _.IsKleeneAlgebra.*-isMonoid
d_'42''45'isMonoid_1150 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_'42''45'isMonoid_1150 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_'42''45'isMonoid_1150 v5
du_'42''45'isMonoid_1150 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
du_'42''45'isMonoid_1150 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_'42''45'isMonoid_1570
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
               (coe v2))))
-- _.IsKleeneAlgebra.*-isSemigroup
d_'42''45'isSemigroup_1152 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_'42''45'isSemigroup_1152 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_'42''45'isSemigroup_1152 v5
du_'42''45'isSemigroup_1152 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
du_'42''45'isSemigroup_1152 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_'42''45'isSemigroup_1568
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
               (coe v2))))
-- _.IsKleeneAlgebra.assoc
d_assoc_1154 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_1154 = erased
-- _.IsKleeneAlgebra.comm
d_comm_1156 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_1156 = erased
-- _.IsKleeneAlgebra.∙-cong
d_'8729''45'cong_1158 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_1158 = erased
-- _.IsKleeneAlgebra.∙-congʳ
d_'8729''45'cong'691'_1160 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1160 = erased
-- _.IsKleeneAlgebra.∙-congˡ
d_'8729''45'cong'737'_1162 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1162 = erased
-- _.IsKleeneAlgebra.+-idem
d_'43''45'idem_1164 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'43''45'idem_1164 = erased
-- _.IsKleeneAlgebra.identity
d_identity_1166 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_1166 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_746
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isSemiring_1956
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
                     (coe v0))))))
-- _.IsKleeneAlgebra.identityʳ
d_identity'691'_1168 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1168 = erased
-- _.IsKleeneAlgebra.identityˡ
d_identity'737'_1170 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1170 = erased
-- _.IsKleeneAlgebra.isBand
d_isBand_1172 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsBand_508
d_isBand_1172 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_isBand_1172 v5
du_isBand_1172 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsBand_508
du_isBand_1172 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
              (coe v0) in
    coe
      (let v2
             = coe
                 MAlonzo.Code.Algebra.Structures.du_'43''45'isIdempotentCommutativeMonoid_2044
                 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isBand_846
            (coe
               MAlonzo.Code.Algebra.Structures.du_isIdempotentMonoid_910
               (coe v2))))
-- _.IsKleeneAlgebra.isCommutativeBand
d_isCommutativeBand_1174 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590
d_isCommutativeBand_1174 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isCommutativeBand_1174 v5
du_isCommutativeBand_1174 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeBand_590
du_isCommutativeBand_1174 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isCommutativeBand_916
         (coe
            MAlonzo.Code.Algebra.Structures.du_'43''45'isIdempotentCommutativeMonoid_2044
            (coe v1)))
-- _.IsKleeneAlgebra.isCommutativeMagma
d_isCommutativeMagma_1176 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_1176 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isCommutativeMagma_1176 v5
du_isCommutativeMagma_1176 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_1176 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                    (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                       (coe v3) in
             coe
               (coe
                  MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
                  (coe
                     MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
                     (coe v4))))))
-- _.IsKleeneAlgebra.+-isCommutativeMonoid
d_'43''45'isCommutativeMonoid_1178 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
d_'43''45'isCommutativeMonoid_1178 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiring_1956
            (coe
               MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
               (coe v0))))
-- _.IsKleeneAlgebra.isCommutativeSemigroup
d_isCommutativeSemigroup_1180 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_isCommutativeSemigroup_1180 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isCommutativeSemigroup_1180 v5
du_isCommutativeSemigroup_1180 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
du_isCommutativeSemigroup_1180 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                    (coe v2) in
          coe
            (coe
               MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
               (coe
                  MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                  (coe v3)))))
-- _.IsKleeneAlgebra.+-isIdempotentCommutativeMonoid
d_'43''45'isIdempotentCommutativeMonoid_1182 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852
d_'43''45'isIdempotentCommutativeMonoid_1182 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_'43''45'isIdempotentCommutativeMonoid_1182 v5
du_'43''45'isIdempotentCommutativeMonoid_1182 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentCommutativeMonoid_852
du_'43''45'isIdempotentCommutativeMonoid_1182 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_'43''45'isIdempotentCommutativeMonoid_2044
      (coe
         MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
         (coe v0))
-- _.IsKleeneAlgebra.isIdempotentMonoid
d_isIdempotentMonoid_1184 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796
d_isIdempotentMonoid_1184 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isIdempotentMonoid_1184 v5
du_isIdempotentMonoid_1184 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentMonoid_796
du_isIdempotentMonoid_1184 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isIdempotentMonoid_910
         (coe
            MAlonzo.Code.Algebra.Structures.du_'43''45'isIdempotentCommutativeMonoid_2044
            (coe v1)))
-- _.IsKleeneAlgebra.isMagma
d_isMagma_1186 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_1186 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe
            MAlonzo.Code.Algebra.Structures.d_isMonoid_746
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isSemiring_1956
                     (coe
                        MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
                        (coe v0)))))))
-- _.IsKleeneAlgebra.isMonoid
d_isMonoid_1188 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_isMonoid_1188 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMonoid_746
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiring_1956
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
                  (coe v0)))))
-- _.IsKleeneAlgebra.isSemigroup
d_isSemigroup_1190 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_1190 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_746
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isSemiring_1956
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
                     (coe v0))))))
-- _.IsKleeneAlgebra.isUnitalMagma
d_isUnitalMagma_1192 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_1192 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isUnitalMagma_1192 v5
du_isUnitalMagma_1192 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_1192 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                    (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                       (coe v3) in
             coe
               (coe
                  MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
                  (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v4))))))
-- _.IsKleeneAlgebra.distrib
d_distrib_1194 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_distrib_1194 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_distrib_1516
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiring_1956
            (coe
               MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
               (coe v0))))
-- _.IsKleeneAlgebra.distribʳ
d_distrib'691'_1196 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'691'_1196 = erased
-- _.IsKleeneAlgebra.distribˡ
d_distrib'737'_1198 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'737'_1198 = erased
-- _.IsKleeneAlgebra.isEquivalence
d_isEquivalence_1200 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_1200 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe
               MAlonzo.Code.Algebra.Structures.d_isMonoid_746
               (coe
                  MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                     (coe
                        MAlonzo.Code.Algebra.Structures.d_isSemiring_1956
                        (coe
                           MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
                           (coe v0))))))))
-- _.IsKleeneAlgebra.isIdempotentSemiring
d_isIdempotentSemiring_1202 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsIdempotentSemiring_1942
d_isIdempotentSemiring_1202 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
      (coe v0)
-- _.IsKleeneAlgebra.isNearSemiring
d_isNearSemiring_1204 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
d_isNearSemiring_1204 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isNearSemiring_1204 v5
du_isNearSemiring_1204 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
du_isNearSemiring_1204 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isNearSemiring_1384
            (coe
               MAlonzo.Code.Algebra.Structures.du_isSemiringWithoutOne_1680
               (coe v2))))
-- _.IsKleeneAlgebra.isPartialEquivalence
d_isPartialEquivalence_1206 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_1206 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isPartialEquivalence_1206 v5
du_isPartialEquivalence_1206 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_1206 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                    (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                       (coe v3) in
             coe
               (let v5
                      = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v4) in
                coe
                  (let v6
                         = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v5) in
                   coe
                     (let v7 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v6) in
                      coe
                        (coe
                           MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
                           (coe
                              MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
                              (coe v7)))))))))
-- _.IsKleeneAlgebra.isSemiring
d_isSemiring_1208 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590
d_isSemiring_1208 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemiring_1956
      (coe
         MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
         (coe v0))
-- _.IsKleeneAlgebra.isSemiringWithoutAnnihilatingZero
d_isSemiringWithoutAnnihilatingZero_1210 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488
d_isSemiringWithoutAnnihilatingZero_1210 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiring_1956
         (coe
            MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
            (coe v0)))
-- _.IsKleeneAlgebra.isSemiringWithoutOne
d_isSemiringWithoutOne_1212 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298
d_isSemiringWithoutOne_1212 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isSemiringWithoutOne_1212 v5
du_isSemiringWithoutOne_1212 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298
du_isSemiringWithoutOne_1212 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isSemiringWithoutOne_1680
         (coe MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v1)))
-- _.IsKleeneAlgebra.refl
d_refl_1214 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_1214 = erased
-- _.IsKleeneAlgebra.reflexive
d_reflexive_1216 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_1216 = erased
-- _.IsKleeneAlgebra.setoid
d_setoid_1218 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_1218 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_setoid_1218 v5
du_setoid_1218 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_1218 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemiring_1956 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                    (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                       (coe v3) in
             coe
               (let v5
                      = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v4) in
                coe
                  (let v6
                         = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v5) in
                   coe
                     (coe
                        MAlonzo.Code.Algebra.Structures.du_setoid_200
                        (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v6))))))))
-- _.IsKleeneAlgebra.starDestructive
d_starDestructive_1220 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_starDestructive_1220 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_starDestructive_2086 (coe v0)
-- _.IsKleeneAlgebra.starDestructiveʳ
d_starDestructive'691'_1222 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_starDestructive'691'_1222 = erased
-- _.IsKleeneAlgebra.starDestructiveˡ
d_starDestructive'737'_1224 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_starDestructive'737'_1224 = erased
-- _.IsKleeneAlgebra.starExpansive
d_starExpansive_1226 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_starExpansive_1226 v0
  = coe MAlonzo.Code.Algebra.Structures.d_starExpansive_2084 (coe v0)
-- _.IsKleeneAlgebra.starExpansiveʳ
d_starExpansive'691'_1228 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_starExpansive'691'_1228 = erased
-- _.IsKleeneAlgebra.starExpansiveˡ
d_starExpansive'737'_1230 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_starExpansive'737'_1230 = erased
-- _.IsKleeneAlgebra.sym
d_sym_1232 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_1232 = erased
-- _.IsKleeneAlgebra.trans
d_trans_1234 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_1234 = erased
-- _.IsKleeneAlgebra.zero
d_zero_1236 ::
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_zero_1236 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_zero_1606
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiring_1956
         (coe
            MAlonzo.Code.Algebra.Structures.d_isIdempotentSemiring_2082
            (coe v0)))
-- _.IsKleeneAlgebra.zeroʳ
d_zero'691'_1238 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'691'_1238 = erased
-- _.IsKleeneAlgebra.zeroˡ
d_zero'737'_1240 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsKleeneAlgebra_2064 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'737'_1240 = erased
-- _.IsLeftBolLoop.//-cong
d_'47''47''45'cong_1244 ::
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong_1244 = erased
-- _.IsLeftBolLoop.//-congʳ
d_'47''47''45'cong'691'_1246 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong'691'_1246 = erased
-- _.IsLeftBolLoop.//-congˡ
d_'47''47''45'cong'737'_1248 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong'737'_1248 = erased
-- _.IsLeftBolLoop.\\-cong
d_'92''92''45'cong_1250 ::
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong_1250 = erased
-- _.IsLeftBolLoop.\\-congʳ
d_'92''92''45'cong'691'_1252 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong'691'_1252 = erased
-- _.IsLeftBolLoop.\\-congˡ
d_'92''92''45'cong'737'_1254 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong'737'_1254 = erased
-- _.IsLeftBolLoop.identity
d_identity_1256 ::
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_1256 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_3064
      (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3140 (coe v0))
-- _.IsLeftBolLoop.identityʳ
d_identity'691'_1258 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1258 = erased
-- _.IsLeftBolLoop.identityˡ
d_identity'737'_1260 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1260 = erased
-- _.IsLeftBolLoop.isEquivalence
d_isEquivalence_1262 ::
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_1262 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_2984
         (coe
            MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
            (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3140 (coe v0))))
-- _.IsLeftBolLoop.isLoop
d_isLoop_1264 ::
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048
d_isLoop_1264 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isLoop_3140 (coe v0)
-- _.IsLeftBolLoop.isMagma
d_isMagma_1266 ::
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_1266 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_2984
      (coe
         MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
         (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3140 (coe v0)))
-- _.IsLeftBolLoop.isPartialEquivalence
d_isPartialEquivalence_1268 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_1268 ~v0 ~v1 ~v2 ~v3 v4
  = du_isPartialEquivalence_1268 v4
du_isPartialEquivalence_1268 ::
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_1268 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isLoop_3140 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isMagma_2984 (coe v2) in
          coe
            (coe
               MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v3)))))
-- _.IsLeftBolLoop.isQuasigroup
d_isQuasigroup_1270 ::
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966
d_isQuasigroup_1270 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
      (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3140 (coe v0))
-- _.IsLeftBolLoop.leftBol
d_leftBol_1272 ::
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_leftBol_1272 = erased
-- _.IsLeftBolLoop.leftDivides
d_leftDivides_1274 ::
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_leftDivides_1274 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_leftDivides_2990
      (coe
         MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
         (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3140 (coe v0)))
-- _.IsLeftBolLoop.leftDividesʳ
d_leftDivides'691'_1276 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_leftDivides'691'_1276 = erased
-- _.IsLeftBolLoop.leftDividesˡ
d_leftDivides'737'_1278 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_leftDivides'737'_1278 = erased
-- _.IsLeftBolLoop.refl
d_refl_1280 ::
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_1280 = erased
-- _.IsLeftBolLoop.reflexive
d_reflexive_1282 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_1282 = erased
-- _.IsLeftBolLoop.rightDivides
d_rightDivides_1284 ::
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_rightDivides_1284 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_rightDivides_2992
      (coe
         MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
         (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3140 (coe v0)))
-- _.IsLeftBolLoop.rightDividesʳ
d_rightDivides'691'_1286 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_rightDivides'691'_1286 = erased
-- _.IsLeftBolLoop.rightDividesˡ
d_rightDivides'737'_1288 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_rightDivides'737'_1288 = erased
-- _.IsLeftBolLoop.setoid
d_setoid_1290 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_1290 ~v0 ~v1 ~v2 ~v3 v4 = du_setoid_1290 v4
du_setoid_1290 ::
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_1290 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isLoop_3140 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_setoid_200
            (coe MAlonzo.Code.Algebra.Structures.d_isMagma_2984 (coe v2))))
-- _.IsLeftBolLoop.sym
d_sym_1292 ::
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_1292 = erased
-- _.IsLeftBolLoop.trans
d_trans_1294 ::
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_1294 = erased
-- _.IsLeftBolLoop.∙-cong
d_'8729''45'cong_1296 ::
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_1296 = erased
-- _.IsLeftBolLoop.∙-congʳ
d_'8729''45'cong'691'_1298 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1298 = erased
-- _.IsLeftBolLoop.∙-congˡ
d_'8729''45'cong'737'_1300 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1300 = erased
-- _.IsLoop.//-cong
d_'47''47''45'cong_1304 ::
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong_1304 = erased
-- _.IsLoop.//-congʳ
d_'47''47''45'cong'691'_1306 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong'691'_1306 = erased
-- _.IsLoop.//-congˡ
d_'47''47''45'cong'737'_1308 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong'737'_1308 = erased
-- _.IsLoop.\\-cong
d_'92''92''45'cong_1310 ::
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong_1310 = erased
-- _.IsLoop.\\-congʳ
d_'92''92''45'cong'691'_1312 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong'691'_1312 = erased
-- _.IsLoop.\\-congˡ
d_'92''92''45'cong'737'_1314 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong'737'_1314 = erased
-- _.IsLoop.identity
d_identity_1316 ::
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_1316 v0
  = coe MAlonzo.Code.Algebra.Structures.d_identity_3064 (coe v0)
-- _.IsLoop.identityʳ
d_identity'691'_1318 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1318 = erased
-- _.IsLoop.identityˡ
d_identity'737'_1320 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1320 = erased
-- _.IsLoop.isEquivalence
d_isEquivalence_1322 ::
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_1322 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_2984
         (coe MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062 (coe v0)))
-- _.IsLoop.isMagma
d_isMagma_1324 ::
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_1324 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_2984
      (coe MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062 (coe v0))
-- _.IsLoop.isPartialEquivalence
d_isPartialEquivalence_1326 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_1326 ~v0 ~v1 ~v2 ~v3 v4
  = du_isPartialEquivalence_1326 v4
du_isPartialEquivalence_1326 ::
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_1326 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isMagma_2984 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
            (coe
               MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v2))))
-- _.IsLoop.isQuasigroup
d_isQuasigroup_1328 ::
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966
d_isQuasigroup_1328 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062 (coe v0)
-- _.IsLoop.leftDivides
d_leftDivides_1330 ::
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_leftDivides_1330 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_leftDivides_2990
      (coe MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062 (coe v0))
-- _.IsLoop.leftDividesʳ
d_leftDivides'691'_1332 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_leftDivides'691'_1332 = erased
-- _.IsLoop.leftDividesˡ
d_leftDivides'737'_1334 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_leftDivides'737'_1334 = erased
-- _.IsLoop.refl
d_refl_1336 ::
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_1336 = erased
-- _.IsLoop.reflexive
d_reflexive_1338 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_1338 = erased
-- _.IsLoop.rightDivides
d_rightDivides_1340 ::
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_rightDivides_1340 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_rightDivides_2992
      (coe MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062 (coe v0))
-- _.IsLoop.rightDividesʳ
d_rightDivides'691'_1342 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_rightDivides'691'_1342 = erased
-- _.IsLoop.rightDividesˡ
d_rightDivides'737'_1344 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_rightDivides'737'_1344 = erased
-- _.IsLoop.setoid
d_setoid_1346 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_1346 ~v0 ~v1 ~v2 ~v3 v4 = du_setoid_1346 v4
du_setoid_1346 ::
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_1346 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_setoid_200
         (coe MAlonzo.Code.Algebra.Structures.d_isMagma_2984 (coe v1)))
-- _.IsLoop.sym
d_sym_1348 ::
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_1348 = erased
-- _.IsLoop.trans
d_trans_1350 ::
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_1350 = erased
-- _.IsLoop.∙-cong
d_'8729''45'cong_1352 ::
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_1352 = erased
-- _.IsLoop.∙-congʳ
d_'8729''45'cong'691'_1354 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1354 = erased
-- _.IsLoop.∙-congˡ
d_'8729''45'cong'737'_1356 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1356 = erased
-- _.IsMagma.isEquivalence
d_isEquivalence_1360 ::
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_1360 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v0)
-- _.IsMagma.isPartialEquivalence
d_isPartialEquivalence_1362 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_1362 ~v0 v1
  = du_isPartialEquivalence_1362 v1
du_isPartialEquivalence_1362 ::
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_1362 v0
  = coe
      MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
      (coe MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v0))
-- _.IsMagma.refl
d_refl_1364 ::
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_1364 = erased
-- _.IsMagma.reflexive
d_reflexive_1366 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_1366 = erased
-- _.IsMagma.setoid
d_setoid_1368 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_1368 v0 v1
  = coe MAlonzo.Code.Algebra.Structures.du_setoid_200 v1
-- _.IsMagma.sym
d_sym_1370 ::
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_1370 = erased
-- _.IsMagma.trans
d_trans_1372 ::
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_1372 = erased
-- _.IsMagma.∙-cong
d_'8729''45'cong_1374 ::
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_1374 = erased
-- _.IsMagma.∙-congʳ
d_'8729''45'cong'691'_1376 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1376 = erased
-- _.IsMagma.∙-congˡ
d_'8729''45'cong'737'_1378 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1378 = erased
-- _.IsMedialMagma.isEquivalence
d_isEquivalence_1382 ::
  MAlonzo.Code.Algebra.Structures.T_IsMedialMagma_360 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_1382 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_368 (coe v0))
-- _.IsMedialMagma.isMagma
d_isMagma_1384 ::
  MAlonzo.Code.Algebra.Structures.T_IsMedialMagma_360 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_1384 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isMagma_368 (coe v0)
-- _.IsMedialMagma.isPartialEquivalence
d_isPartialEquivalence_1386 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsMedialMagma_360 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_1386 ~v0 v1
  = du_isPartialEquivalence_1386 v1
du_isPartialEquivalence_1386 ::
  MAlonzo.Code.Algebra.Structures.T_IsMedialMagma_360 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_1386 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isMagma_368 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
         (coe MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v1)))
-- _.IsMedialMagma.medial
d_medial_1388 ::
  MAlonzo.Code.Algebra.Structures.T_IsMedialMagma_360 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_medial_1388 = erased
-- _.IsMedialMagma.refl
d_refl_1390 ::
  MAlonzo.Code.Algebra.Structures.T_IsMedialMagma_360 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_1390 = erased
-- _.IsMedialMagma.reflexive
d_reflexive_1392 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsMedialMagma_360 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_1392 = erased
-- _.IsMedialMagma.setoid
d_setoid_1394 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsMedialMagma_360 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_1394 ~v0 v1 = du_setoid_1394 v1
du_setoid_1394 ::
  MAlonzo.Code.Algebra.Structures.T_IsMedialMagma_360 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_1394 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_setoid_200
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_368 (coe v0))
-- _.IsMedialMagma.sym
d_sym_1396 ::
  MAlonzo.Code.Algebra.Structures.T_IsMedialMagma_360 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_1396 = erased
-- _.IsMedialMagma.trans
d_trans_1398 ::
  MAlonzo.Code.Algebra.Structures.T_IsMedialMagma_360 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_1398 = erased
-- _.IsMedialMagma.∙-cong
d_'8729''45'cong_1400 ::
  MAlonzo.Code.Algebra.Structures.T_IsMedialMagma_360 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_1400 = erased
-- _.IsMedialMagma.∙-congʳ
d_'8729''45'cong'691'_1402 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsMedialMagma_360 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1402 = erased
-- _.IsMedialMagma.∙-congˡ
d_'8729''45'cong'737'_1404 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsMedialMagma_360 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1404 = erased
-- _.IsMiddleBolLoop.//-cong
d_'47''47''45'cong_1408 ::
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong_1408 = erased
-- _.IsMiddleBolLoop.//-congʳ
d_'47''47''45'cong'691'_1410 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong'691'_1410 = erased
-- _.IsMiddleBolLoop.//-congˡ
d_'47''47''45'cong'737'_1412 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong'737'_1412 = erased
-- _.IsMiddleBolLoop.\\-cong
d_'92''92''45'cong_1414 ::
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong_1414 = erased
-- _.IsMiddleBolLoop.\\-congʳ
d_'92''92''45'cong'691'_1416 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong'691'_1416 = erased
-- _.IsMiddleBolLoop.\\-congˡ
d_'92''92''45'cong'737'_1418 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong'737'_1418 = erased
-- _.IsMiddleBolLoop.identity
d_identity_1420 ::
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_1420 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_3064
      (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3394 (coe v0))
-- _.IsMiddleBolLoop.identityʳ
d_identity'691'_1422 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1422 = erased
-- _.IsMiddleBolLoop.identityˡ
d_identity'737'_1424 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1424 = erased
-- _.IsMiddleBolLoop.isEquivalence
d_isEquivalence_1426 ::
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_1426 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_2984
         (coe
            MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
            (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3394 (coe v0))))
-- _.IsMiddleBolLoop.isLoop
d_isLoop_1428 ::
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048
d_isLoop_1428 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isLoop_3394 (coe v0)
-- _.IsMiddleBolLoop.isMagma
d_isMagma_1430 ::
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_1430 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_2984
      (coe
         MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
         (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3394 (coe v0)))
-- _.IsMiddleBolLoop.isPartialEquivalence
d_isPartialEquivalence_1432 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_1432 ~v0 ~v1 ~v2 ~v3 v4
  = du_isPartialEquivalence_1432 v4
du_isPartialEquivalence_1432 ::
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_1432 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isLoop_3394 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isMagma_2984 (coe v2) in
          coe
            (coe
               MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v3)))))
-- _.IsMiddleBolLoop.isQuasigroup
d_isQuasigroup_1434 ::
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966
d_isQuasigroup_1434 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
      (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3394 (coe v0))
-- _.IsMiddleBolLoop.leftDivides
d_leftDivides_1436 ::
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_leftDivides_1436 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_leftDivides_2990
      (coe
         MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
         (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3394 (coe v0)))
-- _.IsMiddleBolLoop.leftDividesʳ
d_leftDivides'691'_1438 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_leftDivides'691'_1438 = erased
-- _.IsMiddleBolLoop.leftDividesˡ
d_leftDivides'737'_1440 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_leftDivides'737'_1440 = erased
-- _.IsMiddleBolLoop.middleBol
d_middleBol_1442 ::
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_middleBol_1442 = erased
-- _.IsMiddleBolLoop.refl
d_refl_1444 ::
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_1444 = erased
-- _.IsMiddleBolLoop.reflexive
d_reflexive_1446 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_1446 = erased
-- _.IsMiddleBolLoop.rightDivides
d_rightDivides_1448 ::
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_rightDivides_1448 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_rightDivides_2992
      (coe
         MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
         (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3394 (coe v0)))
-- _.IsMiddleBolLoop.rightDividesʳ
d_rightDivides'691'_1450 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_rightDivides'691'_1450 = erased
-- _.IsMiddleBolLoop.rightDividesˡ
d_rightDivides'737'_1452 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_rightDivides'737'_1452 = erased
-- _.IsMiddleBolLoop.setoid
d_setoid_1454 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_1454 ~v0 ~v1 ~v2 ~v3 v4 = du_setoid_1454 v4
du_setoid_1454 ::
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_1454 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isLoop_3394 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_setoid_200
            (coe MAlonzo.Code.Algebra.Structures.d_isMagma_2984 (coe v2))))
-- _.IsMiddleBolLoop.sym
d_sym_1456 ::
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_1456 = erased
-- _.IsMiddleBolLoop.trans
d_trans_1458 ::
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_1458 = erased
-- _.IsMiddleBolLoop.∙-cong
d_'8729''45'cong_1460 ::
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_1460 = erased
-- _.IsMiddleBolLoop.∙-congʳ
d_'8729''45'cong'691'_1462 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1462 = erased
-- _.IsMiddleBolLoop.∙-congˡ
d_'8729''45'cong'737'_1464 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMiddleBolLoop_3380 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1464 = erased
-- _.IsMonoid.assoc
d_assoc_1468 ::
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_1468 = erased
-- _.IsMonoid.identity
d_identity_1470 ::
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_1470 v0
  = coe MAlonzo.Code.Algebra.Structures.d_identity_698 (coe v0)
-- _.IsMonoid.identityʳ
d_identity'691'_1472 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1472 = erased
-- _.IsMonoid.identityˡ
d_identity'737'_1474 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1474 = erased
-- _.IsMonoid.isEquivalence
d_isEquivalence_1476 ::
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_1476 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v0)))
-- _.IsMonoid.isMagma
d_isMagma_1478 ::
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_1478 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v0))
-- _.IsMonoid.isPartialEquivalence
d_isPartialEquivalence_1480 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_1480 ~v0 ~v1 v2
  = du_isPartialEquivalence_1480 v2
du_isPartialEquivalence_1480 ::
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_1480 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v0) in
    coe
      (let v2 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
            (coe
               MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v2))))
-- _.IsMonoid.isSemigroup
d_isSemigroup_1482 ::
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_1482 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v0)
-- _.IsMonoid.isUnitalMagma
d_isUnitalMagma_1484 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_1484 v0 v1 v2
  = coe MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730 v2
-- _.IsMonoid.refl
d_refl_1486 ::
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_1486 = erased
-- _.IsMonoid.reflexive
d_reflexive_1488 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_1488 = erased
-- _.IsMonoid.setoid
d_setoid_1490 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_1490 ~v0 ~v1 v2 = du_setoid_1490 v2
du_setoid_1490 ::
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_1490 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_setoid_200
         (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v1)))
-- _.IsMonoid.sym
d_sym_1492 ::
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_1492 = erased
-- _.IsMonoid.trans
d_trans_1494 ::
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_1494 = erased
-- _.IsMonoid.∙-cong
d_'8729''45'cong_1496 ::
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_1496 = erased
-- _.IsMonoid.∙-congʳ
d_'8729''45'cong'691'_1498 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1498 = erased
-- _.IsMonoid.∙-congˡ
d_'8729''45'cong'737'_1500 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1500 = erased
-- _.IsMoufangLoop.//-cong
d_'47''47''45'cong_1504 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong_1504 = erased
-- _.IsMoufangLoop.//-congʳ
d_'47''47''45'cong'691'_1506 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong'691'_1506 = erased
-- _.IsMoufangLoop.//-congˡ
d_'47''47''45'cong'737'_1508 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong'737'_1508 = erased
-- _.IsMoufangLoop.\\-cong
d_'92''92''45'cong_1510 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong_1510 = erased
-- _.IsMoufangLoop.\\-congʳ
d_'92''92''45'cong'691'_1512 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong'691'_1512 = erased
-- _.IsMoufangLoop.\\-congˡ
d_'92''92''45'cong'737'_1514 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong'737'_1514 = erased
-- _.IsMoufangLoop.identical
d_identical_1516 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identical_1516 = erased
-- _.IsMoufangLoop.identity
d_identity_1518 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_1518 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_3064
      (coe
         MAlonzo.Code.Algebra.Structures.d_isLoop_3140
         (coe
            MAlonzo.Code.Algebra.Structures.d_isLeftBolLoop_3306 (coe v0)))
-- _.IsMoufangLoop.identityʳ
d_identity'691'_1520 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1520 = erased
-- _.IsMoufangLoop.identityˡ
d_identity'737'_1522 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1522 = erased
-- _.IsMoufangLoop.isEquivalence
d_isEquivalence_1524 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_1524 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_2984
         (coe
            MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
            (coe
               MAlonzo.Code.Algebra.Structures.d_isLoop_3140
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isLeftBolLoop_3306 (coe v0)))))
-- _.IsMoufangLoop.isLeftBolLoop
d_isLeftBolLoop_1526 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Algebra.Structures.T_IsLeftBolLoop_3126
d_isLeftBolLoop_1526 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isLeftBolLoop_3306 (coe v0)
-- _.IsMoufangLoop.isLoop
d_isLoop_1528 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048
d_isLoop_1528 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isLoop_3140
      (coe MAlonzo.Code.Algebra.Structures.d_isLeftBolLoop_3306 (coe v0))
-- _.IsMoufangLoop.isMagma
d_isMagma_1530 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_1530 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_2984
      (coe
         MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
         (coe
            MAlonzo.Code.Algebra.Structures.d_isLoop_3140
            (coe
               MAlonzo.Code.Algebra.Structures.d_isLeftBolLoop_3306 (coe v0))))
-- _.IsMoufangLoop.isPartialEquivalence
d_isPartialEquivalence_1532 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_1532 ~v0 ~v1 ~v2 ~v3 v4
  = du_isPartialEquivalence_1532 v4
du_isPartialEquivalence_1532 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_1532 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isLeftBolLoop_3306 (coe v0) in
    coe
      (let v2 = MAlonzo.Code.Algebra.Structures.d_isLoop_3140 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062 (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_isMagma_2984 (coe v3) in
             coe
               (coe
                  MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v4))))))
-- _.IsMoufangLoop.isQuasigroup
d_isQuasigroup_1534 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966
d_isQuasigroup_1534 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
      (coe
         MAlonzo.Code.Algebra.Structures.d_isLoop_3140
         (coe
            MAlonzo.Code.Algebra.Structures.d_isLeftBolLoop_3306 (coe v0)))
-- _.IsMoufangLoop.leftBol
d_leftBol_1536 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_leftBol_1536 = erased
-- _.IsMoufangLoop.leftDivides
d_leftDivides_1538 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_leftDivides_1538 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_leftDivides_2990
      (coe
         MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
         (coe
            MAlonzo.Code.Algebra.Structures.d_isLoop_3140
            (coe
               MAlonzo.Code.Algebra.Structures.d_isLeftBolLoop_3306 (coe v0))))
-- _.IsMoufangLoop.leftDividesʳ
d_leftDivides'691'_1540 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_leftDivides'691'_1540 = erased
-- _.IsMoufangLoop.leftDividesˡ
d_leftDivides'737'_1542 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_leftDivides'737'_1542 = erased
-- _.IsMoufangLoop.refl
d_refl_1544 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_1544 = erased
-- _.IsMoufangLoop.reflexive
d_reflexive_1546 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_1546 = erased
-- _.IsMoufangLoop.rightBol
d_rightBol_1548 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_rightBol_1548 = erased
-- _.IsMoufangLoop.rightDivides
d_rightDivides_1550 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_rightDivides_1550 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_rightDivides_2992
      (coe
         MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
         (coe
            MAlonzo.Code.Algebra.Structures.d_isLoop_3140
            (coe
               MAlonzo.Code.Algebra.Structures.d_isLeftBolLoop_3306 (coe v0))))
-- _.IsMoufangLoop.rightDividesʳ
d_rightDivides'691'_1552 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_rightDivides'691'_1552 = erased
-- _.IsMoufangLoop.rightDividesˡ
d_rightDivides'737'_1554 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_rightDivides'737'_1554 = erased
-- _.IsMoufangLoop.setoid
d_setoid_1556 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_1556 ~v0 ~v1 ~v2 ~v3 v4 = du_setoid_1556 v4
du_setoid_1556 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_1556 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isLeftBolLoop_3306 (coe v0) in
    coe
      (let v2 = MAlonzo.Code.Algebra.Structures.d_isLoop_3140 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062 (coe v2) in
          coe
            (coe
               MAlonzo.Code.Algebra.Structures.du_setoid_200
               (coe MAlonzo.Code.Algebra.Structures.d_isMagma_2984 (coe v3)))))
-- _.IsMoufangLoop.sym
d_sym_1558 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_1558 = erased
-- _.IsMoufangLoop.trans
d_trans_1560 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_1560 = erased
-- _.IsMoufangLoop.∙-cong
d_'8729''45'cong_1562 ::
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_1562 = erased
-- _.IsMoufangLoop.∙-congʳ
d_'8729''45'cong'691'_1564 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1564 = erased
-- _.IsMoufangLoop.∙-congˡ
d_'8729''45'cong'737'_1566 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsMoufangLoop_3290 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1566 = erased
-- _.IsNearSemiring.*-assoc
d_'42''45'assoc_1570 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'assoc_1570 = erased
-- _.IsNearSemiring.*-cong
d_'42''45'cong_1572 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'cong_1572 = erased
-- _.IsNearSemiring.∙-congʳ
d_'8729''45'cong'691'_1574 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1574 = erased
-- _.IsNearSemiring.∙-congˡ
d_'8729''45'cong'737'_1576 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1576 = erased
-- _.IsNearSemiring.*-isMagma
d_'42''45'isMagma_1578 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_'42''45'isMagma_1578 v0 v1 v2 v3
  = coe MAlonzo.Code.Algebra.Structures.du_'42''45'isMagma_1282 v3
-- _.IsNearSemiring.*-isSemigroup
d_'42''45'isSemigroup_1580 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_'42''45'isSemigroup_1580 v0 v1 v2 v3
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isSemigroup_1284 v3
-- _.IsNearSemiring.assoc
d_assoc_1582 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_1582 = erased
-- _.IsNearSemiring.∙-cong
d_'8729''45'cong_1584 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_1584 = erased
-- _.IsNearSemiring.∙-congʳ
d_'8729''45'cong'691'_1586 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1586 = erased
-- _.IsNearSemiring.∙-congˡ
d_'8729''45'cong'737'_1588 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1588 = erased
-- _.IsNearSemiring.identity
d_identity_1590 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_1590 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_1236 (coe v0))
-- _.IsNearSemiring.identityʳ
d_identity'691'_1592 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1592 = erased
-- _.IsNearSemiring.identityˡ
d_identity'737'_1594 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1594 = erased
-- _.IsNearSemiring.isMagma
d_isMagma_1596 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_1596 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_1236 (coe v0)))
-- _.IsNearSemiring.+-isMonoid
d_'43''45'isMonoid_1598 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_'43''45'isMonoid_1598 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_1236 (coe v0)
-- _.IsNearSemiring.isSemigroup
d_isSemigroup_1600 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_1600 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_1236 (coe v0))
-- _.IsNearSemiring.isUnitalMagma
d_isUnitalMagma_1602 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_1602 ~v0 ~v1 ~v2 v3 = du_isUnitalMagma_1602 v3
du_isUnitalMagma_1602 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_1602 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_1236 (coe v0))
-- _.IsNearSemiring.distribʳ
d_distrib'691'_1604 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'691'_1604 = erased
-- _.IsNearSemiring.isEquivalence
d_isEquivalence_1606 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_1606 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_1236 (coe v0))))
-- _.IsNearSemiring.isPartialEquivalence
d_isPartialEquivalence_1608 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_1608 ~v0 ~v1 ~v2 v3
  = du_isPartialEquivalence_1608 v3
du_isPartialEquivalence_1608 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_1608 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_1236
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v1) in
       coe
         (let v3 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v2) in
          coe
            (coe
               MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v3)))))
-- _.IsNearSemiring.refl
d_refl_1610 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_1610 = erased
-- _.IsNearSemiring.reflexive
d_reflexive_1612 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_1612 = erased
-- _.IsNearSemiring.setoid
d_setoid_1614 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_1614 ~v0 ~v1 ~v2 v3 = du_setoid_1614 v3
du_setoid_1614 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_1614 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_1236
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_setoid_200
            (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v2))))
-- _.IsNearSemiring.sym
d_sym_1616 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_1616 = erased
-- _.IsNearSemiring.trans
d_trans_1618 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_1618 = erased
-- _.IsNearSemiring.zeroˡ
d_zero'737'_1620 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'737'_1620 = erased
-- _.IsNearring.*-assoc
d_'42''45'assoc_1624 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'assoc_1624 = erased
-- _.IsNearring.*-cong
d_'42''45'cong_1626 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'cong_1626 = erased
-- _.IsNearring.∙-congʳ
d_'8729''45'cong'691'_1628 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1628 = erased
-- _.IsNearring.∙-congˡ
d_'8729''45'cong'737'_1630 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1630 = erased
-- _.IsNearring.*-identity
d_'42''45'identity_1632 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_'42''45'identity_1632 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'42''45'identity_2228
      (coe MAlonzo.Code.Algebra.Structures.d_isQuasiring_2578 (coe v0))
-- _.IsNearring.identityʳ
d_identity'691'_1634 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1634 = erased
-- _.IsNearring.identityˡ
d_identity'737'_1636 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1636 = erased
-- _.IsNearring.*-isMagma
d_'42''45'isMagma_1638 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_'42''45'isMagma_1638 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_'42''45'isMagma_1638 v5
du_'42''45'isMagma_1638 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
du_'42''45'isMagma_1638 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isMagma_2282
      (coe MAlonzo.Code.Algebra.Structures.d_isQuasiring_2578 (coe v0))
-- _.IsNearring.*-isMonoid
d_'42''45'isMonoid_1640 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_'42''45'isMonoid_1640 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_'42''45'isMonoid_1640 v5
du_'42''45'isMonoid_1640 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
du_'42''45'isMonoid_1640 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isMonoid_2286
      (coe MAlonzo.Code.Algebra.Structures.d_isQuasiring_2578 (coe v0))
-- _.IsNearring.*-isSemigroup
d_'42''45'isSemigroup_1642 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_'42''45'isSemigroup_1642 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_'42''45'isSemigroup_1642 v5
du_'42''45'isSemigroup_1642 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
du_'42''45'isSemigroup_1642 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isSemigroup_2284
      (coe MAlonzo.Code.Algebra.Structures.d_isQuasiring_2578 (coe v0))
-- _.IsNearring.assoc
d_assoc_1644 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_1644 = erased
-- _.IsNearring.∙-cong
d_'8729''45'cong_1646 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_1646 = erased
-- _.IsNearring.∙-congʳ
d_'8729''45'cong'691'_1648 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1648 = erased
-- _.IsNearring.∙-congˡ
d_'8729''45'cong'737'_1650 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1650 = erased
-- _.IsNearring.identity
d_identity_1652 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_1652 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_2222
         (coe MAlonzo.Code.Algebra.Structures.d_isQuasiring_2578 (coe v0)))
-- _.IsNearring.identityʳ
d_identity'691'_1654 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1654 = erased
-- _.IsNearring.identityˡ
d_identity'737'_1656 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1656 = erased
-- _.IsNearring.+-inverse
d_'43''45'inverse_1658 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_'43''45'inverse_1658 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'43''45'inverse_2580 (coe v0)
-- _.IsNearring.+-inverseʳ
d_'43''45'inverse'691'_1660 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'43''45'inverse'691'_1660 = erased
-- _.IsNearring.+-inverseˡ
d_'43''45'inverse'737'_1662 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'43''45'inverse'737'_1662 = erased
-- _.IsNearring.isMagma
d_isMagma_1664 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_1664 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_2222
            (coe MAlonzo.Code.Algebra.Structures.d_isQuasiring_2578 (coe v0))))
-- _.IsNearring.+-isMonoid
d_'43''45'isMonoid_1666 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_'43''45'isMonoid_1666 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_2222
      (coe MAlonzo.Code.Algebra.Structures.d_isQuasiring_2578 (coe v0))
-- _.IsNearring.isSemigroup
d_isSemigroup_1668 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_1668 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_2222
         (coe MAlonzo.Code.Algebra.Structures.d_isQuasiring_2578 (coe v0)))
-- _.IsNearring.isUnitalMagma
d_isUnitalMagma_1670 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_1670 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isUnitalMagma_1670 v5
du_isUnitalMagma_1670 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_1670 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isQuasiring_2578 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_2222 (coe v1)))
-- _.IsNearring.distrib
d_distrib_1672 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_distrib_1672 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_distrib_2230
      (coe MAlonzo.Code.Algebra.Structures.d_isQuasiring_2578 (coe v0))
-- _.IsNearring.distribʳ
d_distrib'691'_1674 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'691'_1674 = erased
-- _.IsNearring.distribˡ
d_distrib'737'_1676 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'737'_1676 = erased
-- _.IsNearring.identityʳ
d_identity'691'_1678 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1678 = erased
-- _.IsNearring.identityˡ
d_identity'737'_1680 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1680 = erased
-- _.IsNearring.isEquivalence
d_isEquivalence_1682 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_1682 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_2222
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isQuasiring_2578 (coe v0)))))
-- _.IsNearring.isPartialEquivalence
d_isPartialEquivalence_1684 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_1684 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isPartialEquivalence_1684 v5
du_isPartialEquivalence_1684 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_1684 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isQuasiring_2578 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_2222
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v2) in
          coe
            (let v4 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v3) in
             coe
               (coe
                  MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v4))))))
-- _.IsNearring.isQuasiring
d_isQuasiring_1686 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200
d_isQuasiring_1686 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isQuasiring_2578 (coe v0)
-- _.IsNearring.refl
d_refl_1688 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_1688 = erased
-- _.IsNearring.reflexive
d_reflexive_1690 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_1690 = erased
-- _.IsNearring.setoid
d_setoid_1692 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_1692 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_setoid_1692 v5
du_setoid_1692 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_1692 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isQuasiring_2578 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_2222
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v2) in
          coe
            (coe
               MAlonzo.Code.Algebra.Structures.du_setoid_200
               (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v3)))))
-- _.IsNearring.sym
d_sym_1694 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_1694 = erased
-- _.IsNearring.trans
d_trans_1696 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_1696 = erased
-- _.IsNearring.zero
d_zero_1698 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_zero_1698 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_zero_2232
      (coe MAlonzo.Code.Algebra.Structures.d_isQuasiring_2578 (coe v0))
-- _.IsNearring.zeroʳ
d_zero'691'_1700 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'691'_1700 = erased
-- _.IsNearring.zeroˡ
d_zero'737'_1702 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'737'_1702 = erased
-- _.IsNearring.⁻¹-cong
d_'8315''185''45'cong_1704 ::
  MAlonzo.Code.Algebra.Structures.T_IsNearring_2560 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8315''185''45'cong_1704 = erased
-- _.IsNonAssociativeRing._//_
d__'47''47'__1708 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d__'47''47'__1708 v0 ~v1 v2 ~v3 ~v4 ~v5 = du__'47''47'__1708 v0 v2
du__'47''47'__1708 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
du__'47''47'__1708 v0 v1
  = coe
      MAlonzo.Code.Algebra.Structures.du__'47''47'__1098 (coe v0)
      (coe v1)
-- _.IsNonAssociativeRing.*-cong
d_'42''45'cong_1710 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'cong_1710 = erased
-- _.IsNonAssociativeRing.∙-congʳ
d_'8729''45'cong'691'_1712 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1712 = erased
-- _.IsNonAssociativeRing.∙-congˡ
d_'8729''45'cong'737'_1714 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1714 = erased
-- _.IsNonAssociativeRing.*-identity
d_'42''45'identity_1716 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_'42''45'identity_1716 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'42''45'identity_2456 (coe v0)
-- _.IsNonAssociativeRing.*-identityʳ
d_'42''45'identity'691'_1718 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'identity'691'_1718 = erased
-- _.IsNonAssociativeRing.*-identityˡ
d_'42''45'identity'737'_1720 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'identity'737'_1720 = erased
-- _.IsNonAssociativeRing.*-isMagma
d_'42''45'isMagma_1722 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_'42''45'isMagma_1722 v0 v1 v2 v3 v4 v5
  = coe MAlonzo.Code.Algebra.Structures.du_'42''45'isMagma_2536 v5
-- _.IsNonAssociativeRing.*-isUnitalMagma
d_'42''45'isUnitalMagma_1724 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_'42''45'isUnitalMagma_1724 v0 v1 v2 v3 v4 v5
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isUnitalMagma_2542 v5
-- _.IsNonAssociativeRing.assoc
d_assoc_1726 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_1726 = erased
-- _.IsNonAssociativeRing.comm
d_comm_1728 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_1728 = erased
-- _.IsNonAssociativeRing.∙-cong
d_'8729''45'cong_1730 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_1730 = erased
-- _.IsNonAssociativeRing.∙-congʳ
d_'8729''45'cong'691'_1732 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1732 = erased
-- _.IsNonAssociativeRing.∙-congˡ
d_'8729''45'cong'737'_1734 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1734 = erased
-- _.IsNonAssociativeRing.identity
d_identity_1736 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_1736 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
         (coe
            MAlonzo.Code.Algebra.Structures.d_isGroup_1144
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2452
               (coe v0))))
-- _.IsNonAssociativeRing.identityʳ
d_identity'691'_1738 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1738 = erased
-- _.IsNonAssociativeRing.identityˡ
d_identity'737'_1740 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1740 = erased
-- _.IsNonAssociativeRing.+-isAbelianGroup
d_'43''45'isAbelianGroup_1742 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132
d_'43''45'isAbelianGroup_1742 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2452
      (coe v0)
-- _.IsNonAssociativeRing.isCommutativeMagma
d_isCommutativeMagma_1744 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_1744 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isCommutativeMagma_1744 v5
du_isCommutativeMagma_1744 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_1744 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2452
              (coe v0) in
    coe
      (let v2
             = coe
                 MAlonzo.Code.Algebra.Structures.du_isCommutativeMonoid_1204
                 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
            (coe
               MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
               (coe v2))))
-- _.IsNonAssociativeRing.isCommutativeMonoid
d_isCommutativeMonoid_1746 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
d_isCommutativeMonoid_1746 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isCommutativeMonoid_1746 v5
du_isCommutativeMonoid_1746 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
du_isCommutativeMonoid_1746 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isCommutativeMonoid_1204
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2452
         (coe v0))
-- _.IsNonAssociativeRing.isCommutativeSemigroup
d_isCommutativeSemigroup_1748 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_isCommutativeSemigroup_1748 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isCommutativeSemigroup_1748 v5
du_isCommutativeSemigroup_1748 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
du_isCommutativeSemigroup_1748 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2452
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeMonoid_1204
            (coe v1)))
-- _.IsNonAssociativeRing.isGroup
d_isGroup_1750 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036
d_isGroup_1750 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isGroup_1144
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2452
         (coe v0))
-- _.IsNonAssociativeRing.isInvertibleMagma
d_isInvertibleMagma_1752 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924
d_isInvertibleMagma_1752 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isInvertibleMagma_1752 v5
du_isInvertibleMagma_1752 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924
du_isInvertibleMagma_1752 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2452
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isInvertibleMagma_1122
         (coe MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v1)))
-- _.IsNonAssociativeRing.isInvertibleUnitalMagma
d_isInvertibleUnitalMagma_1754 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976
d_isInvertibleUnitalMagma_1754 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isInvertibleUnitalMagma_1754 v5
du_isInvertibleUnitalMagma_1754 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976
du_isInvertibleUnitalMagma_1754 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2452
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isInvertibleUnitalMagma_1124
         (coe MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v1)))
-- _.IsNonAssociativeRing.isMagma
d_isMagma_1756 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_1756 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe
            MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
            (coe
               MAlonzo.Code.Algebra.Structures.d_isGroup_1144
               (coe
                  MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2452
                  (coe v0)))))
-- _.IsNonAssociativeRing.isMonoid
d_isMonoid_1758 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_isMonoid_1758 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
      (coe
         MAlonzo.Code.Algebra.Structures.d_isGroup_1144
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2452
            (coe v0)))
-- _.IsNonAssociativeRing.isSemigroup
d_isSemigroup_1760 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_1760 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
         (coe
            MAlonzo.Code.Algebra.Structures.d_isGroup_1144
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2452
               (coe v0))))
-- _.IsNonAssociativeRing.isUnitalMagma
d_isUnitalMagma_1762 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_1762 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isUnitalMagma_1762 v5
du_isUnitalMagma_1762 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_1762 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2452
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
            (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v2))))
-- _.IsNonAssociativeRing.⁻¹-cong
d_'8315''185''45'cong_1764 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8315''185''45'cong_1764 = erased
-- _.IsNonAssociativeRing.inverse
d_inverse_1766 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_inverse_1766 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_inverse_1052
      (coe
         MAlonzo.Code.Algebra.Structures.d_isGroup_1144
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2452
            (coe v0)))
-- _.IsNonAssociativeRing.inverseʳ
d_inverse'691'_1768 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_inverse'691'_1768 = erased
-- _.IsNonAssociativeRing.inverseˡ
d_inverse'737'_1770 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_inverse'737'_1770 = erased
-- _.IsNonAssociativeRing.distrib
d_distrib_1772 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_distrib_1772 v0
  = coe MAlonzo.Code.Algebra.Structures.d_distrib_2458 (coe v0)
-- _.IsNonAssociativeRing.distribʳ
d_distrib'691'_1774 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'691'_1774 = erased
-- _.IsNonAssociativeRing.distribˡ
d_distrib'737'_1776 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'737'_1776 = erased
-- _.IsNonAssociativeRing.isEquivalence
d_isEquivalence_1778 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_1778 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe
               MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isGroup_1144
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2452
                     (coe v0))))))
-- _.IsNonAssociativeRing.isPartialEquivalence
d_isPartialEquivalence_1780 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_1780 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isPartialEquivalence_1780 v5
du_isPartialEquivalence_1780 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_1780 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2452
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v3) in
             coe
               (let v5 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v4) in
                coe
                  (coe
                     MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
                     (coe
                        MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v5)))))))
-- _.IsNonAssociativeRing.refl
d_refl_1782 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_1782 = erased
-- _.IsNonAssociativeRing.reflexive
d_reflexive_1784 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_1784 = erased
-- _.IsNonAssociativeRing.setoid
d_setoid_1786 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_1786 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_setoid_1786 v5
du_setoid_1786 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_1786 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2452
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v3) in
             coe
               (coe
                  MAlonzo.Code.Algebra.Structures.du_setoid_200
                  (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v4))))))
-- _.IsNonAssociativeRing.sym
d_sym_1788 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_1788 = erased
-- _.IsNonAssociativeRing.trans
d_trans_1790 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_1790 = erased
-- _.IsNonAssociativeRing.uniqueʳ-⁻¹
d_unique'691''45''8315''185'_1792 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_unique'691''45''8315''185'_1792 = erased
-- _.IsNonAssociativeRing.uniqueˡ-⁻¹
d_unique'737''45''8315''185'_1794 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_unique'737''45''8315''185'_1794 = erased
-- _.IsNonAssociativeRing.zero
d_zero_1796 ::
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_zero_1796 v0
  = coe MAlonzo.Code.Algebra.Structures.d_zero_2460 (coe v0)
-- _.IsNonAssociativeRing.zeroʳ
d_zero'691'_1798 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'691'_1798 = erased
-- _.IsNonAssociativeRing.zeroˡ
d_zero'737'_1800 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsNonAssociativeRing_2430 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'737'_1800 = erased
-- _.IsQuasigroup.//-cong
d_'47''47''45'cong_1804 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong_1804 = erased
-- _.IsQuasigroup.//-congʳ
d_'47''47''45'cong'691'_1806 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong'691'_1806 = erased
-- _.IsQuasigroup.//-congˡ
d_'47''47''45'cong'737'_1808 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong'737'_1808 = erased
-- _.IsQuasigroup.\\-cong
d_'92''92''45'cong_1810 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong_1810 = erased
-- _.IsQuasigroup.\\-congʳ
d_'92''92''45'cong'691'_1812 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong'691'_1812 = erased
-- _.IsQuasigroup.\\-congˡ
d_'92''92''45'cong'737'_1814 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong'737'_1814 = erased
-- _.IsQuasigroup.isEquivalence
d_isEquivalence_1816 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_1816 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_2984 (coe v0))
-- _.IsQuasigroup.isMagma
d_isMagma_1818 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_1818 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isMagma_2984 (coe v0)
-- _.IsQuasigroup.isPartialEquivalence
d_isPartialEquivalence_1820 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_1820 ~v0 ~v1 ~v2 v3
  = du_isPartialEquivalence_1820 v3
du_isPartialEquivalence_1820 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_1820 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isMagma_2984 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
         (coe MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v1)))
-- _.IsQuasigroup.leftDivides
d_leftDivides_1822 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_leftDivides_1822 v0
  = coe MAlonzo.Code.Algebra.Structures.d_leftDivides_2990 (coe v0)
-- _.IsQuasigroup.leftDividesʳ
d_leftDivides'691'_1824 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_leftDivides'691'_1824 = erased
-- _.IsQuasigroup.leftDividesˡ
d_leftDivides'737'_1826 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_leftDivides'737'_1826 = erased
-- _.IsQuasigroup.refl
d_refl_1828 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_1828 = erased
-- _.IsQuasigroup.reflexive
d_reflexive_1830 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_1830 = erased
-- _.IsQuasigroup.rightDivides
d_rightDivides_1832 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_rightDivides_1832 v0
  = coe MAlonzo.Code.Algebra.Structures.d_rightDivides_2992 (coe v0)
-- _.IsQuasigroup.rightDividesʳ
d_rightDivides'691'_1834 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_rightDivides'691'_1834 = erased
-- _.IsQuasigroup.rightDividesˡ
d_rightDivides'737'_1836 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_rightDivides'737'_1836 = erased
-- _.IsQuasigroup.setoid
d_setoid_1838 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_1838 ~v0 ~v1 ~v2 v3 = du_setoid_1838 v3
du_setoid_1838 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_1838 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_setoid_200
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_2984 (coe v0))
-- _.IsQuasigroup.sym
d_sym_1840 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_1840 = erased
-- _.IsQuasigroup.trans
d_trans_1842 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_1842 = erased
-- _.IsQuasigroup.∙-cong
d_'8729''45'cong_1844 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_1844 = erased
-- _.IsQuasigroup.∙-congʳ
d_'8729''45'cong'691'_1846 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1846 = erased
-- _.IsQuasigroup.∙-congˡ
d_'8729''45'cong'737'_1848 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1848 = erased
-- _.IsQuasiring.*-assoc
d_'42''45'assoc_1852 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'assoc_1852 = erased
-- _.IsQuasiring.*-cong
d_'42''45'cong_1854 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'cong_1854 = erased
-- _.IsQuasiring.∙-congʳ
d_'8729''45'cong'691'_1856 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1856 = erased
-- _.IsQuasiring.∙-congˡ
d_'8729''45'cong'737'_1858 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1858 = erased
-- _.IsQuasiring.*-identity
d_'42''45'identity_1860 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_'42''45'identity_1860 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'42''45'identity_2228 (coe v0)
-- _.IsQuasiring.identityʳ
d_identity'691'_1862 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1862 = erased
-- _.IsQuasiring.identityˡ
d_identity'737'_1864 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1864 = erased
-- _.IsQuasiring.*-isMagma
d_'42''45'isMagma_1866 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_'42''45'isMagma_1866 v0 v1 v2 v3 v4
  = coe MAlonzo.Code.Algebra.Structures.du_'42''45'isMagma_2282 v4
-- _.IsQuasiring.*-isMonoid
d_'42''45'isMonoid_1868 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_'42''45'isMonoid_1868 v0 v1 v2 v3 v4
  = coe MAlonzo.Code.Algebra.Structures.du_'42''45'isMonoid_2286 v4
-- _.IsQuasiring.*-isSemigroup
d_'42''45'isSemigroup_1870 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_'42''45'isSemigroup_1870 v0 v1 v2 v3 v4
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isSemigroup_2284 v4
-- _.IsQuasiring.assoc
d_assoc_1872 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_1872 = erased
-- _.IsQuasiring.∙-cong
d_'8729''45'cong_1874 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_1874 = erased
-- _.IsQuasiring.∙-congʳ
d_'8729''45'cong'691'_1876 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1876 = erased
-- _.IsQuasiring.∙-congˡ
d_'8729''45'cong'737'_1878 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1878 = erased
-- _.IsQuasiring.identity
d_identity_1880 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_1880 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_2222 (coe v0))
-- _.IsQuasiring.identityʳ
d_identity'691'_1882 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1882 = erased
-- _.IsQuasiring.identityˡ
d_identity'737'_1884 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1884 = erased
-- _.IsQuasiring.isMagma
d_isMagma_1886 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_1886 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_2222 (coe v0)))
-- _.IsQuasiring.+-isMonoid
d_'43''45'isMonoid_1888 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_'43''45'isMonoid_1888 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_2222 (coe v0)
-- _.IsQuasiring.isSemigroup
d_isSemigroup_1890 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_1890 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_2222 (coe v0))
-- _.IsQuasiring.isUnitalMagma
d_isUnitalMagma_1892 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_1892 ~v0 ~v1 ~v2 ~v3 v4 = du_isUnitalMagma_1892 v4
du_isUnitalMagma_1892 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_1892 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_2222 (coe v0))
-- _.IsQuasiring.distrib
d_distrib_1894 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_distrib_1894 v0
  = coe MAlonzo.Code.Algebra.Structures.d_distrib_2230 (coe v0)
-- _.IsQuasiring.distribʳ
d_distrib'691'_1896 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'691'_1896 = erased
-- _.IsQuasiring.distribˡ
d_distrib'737'_1898 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'737'_1898 = erased
-- _.IsQuasiring.identityʳ
d_identity'691'_1900 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1900 = erased
-- _.IsQuasiring.identityˡ
d_identity'737'_1902 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1902 = erased
-- _.IsQuasiring.isEquivalence
d_isEquivalence_1904 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_1904 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_2222 (coe v0))))
-- _.IsQuasiring.isPartialEquivalence
d_isPartialEquivalence_1906 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_1906 ~v0 ~v1 ~v2 ~v3 v4
  = du_isPartialEquivalence_1906 v4
du_isPartialEquivalence_1906 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_1906 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_2222
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v1) in
       coe
         (let v3 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v2) in
          coe
            (coe
               MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v3)))))
-- _.IsQuasiring.refl
d_refl_1908 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_1908 = erased
-- _.IsQuasiring.reflexive
d_reflexive_1910 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_1910 = erased
-- _.IsQuasiring.setoid
d_setoid_1912 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_1912 ~v0 ~v1 ~v2 ~v3 v4 = du_setoid_1912 v4
du_setoid_1912 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_1912 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isMonoid_2222
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_setoid_200
            (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v2))))
-- _.IsQuasiring.sym
d_sym_1914 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_1914 = erased
-- _.IsQuasiring.trans
d_trans_1916 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_1916 = erased
-- _.IsQuasiring.zero
d_zero_1918 ::
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_zero_1918 v0
  = coe MAlonzo.Code.Algebra.Structures.d_zero_2232 (coe v0)
-- _.IsQuasiring.zeroʳ
d_zero'691'_1920 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'691'_1920 = erased
-- _.IsQuasiring.zeroˡ
d_zero'737'_1922 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasiring_2200 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'737'_1922 = erased
-- _.IsRightBolLoop.//-cong
d_'47''47''45'cong_1926 ::
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong_1926 = erased
-- _.IsRightBolLoop.//-congʳ
d_'47''47''45'cong'691'_1928 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong'691'_1928 = erased
-- _.IsRightBolLoop.//-congˡ
d_'47''47''45'cong'737'_1930 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'47''47''45'cong'737'_1930 = erased
-- _.IsRightBolLoop.\\-cong
d_'92''92''45'cong_1932 ::
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong_1932 = erased
-- _.IsRightBolLoop.\\-congʳ
d_'92''92''45'cong'691'_1934 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong'691'_1934 = erased
-- _.IsRightBolLoop.\\-congˡ
d_'92''92''45'cong'737'_1936 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'92''92''45'cong'737'_1936 = erased
-- _.IsRightBolLoop.identity
d_identity_1938 ::
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_1938 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_3064
      (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3222 (coe v0))
-- _.IsRightBolLoop.identityʳ
d_identity'691'_1940 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1940 = erased
-- _.IsRightBolLoop.identityˡ
d_identity'737'_1942 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_1942 = erased
-- _.IsRightBolLoop.isEquivalence
d_isEquivalence_1944 ::
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_1944 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_2984
         (coe
            MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
            (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3222 (coe v0))))
-- _.IsRightBolLoop.isLoop
d_isLoop_1946 ::
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Algebra.Structures.T_IsLoop_3048
d_isLoop_1946 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isLoop_3222 (coe v0)
-- _.IsRightBolLoop.isMagma
d_isMagma_1948 ::
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_1948 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_2984
      (coe
         MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
         (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3222 (coe v0)))
-- _.IsRightBolLoop.isPartialEquivalence
d_isPartialEquivalence_1950 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_1950 ~v0 ~v1 ~v2 ~v3 v4
  = du_isPartialEquivalence_1950 v4
du_isPartialEquivalence_1950 ::
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_1950 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isLoop_3222 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isMagma_2984 (coe v2) in
          coe
            (coe
               MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v3)))))
-- _.IsRightBolLoop.isQuasigroup
d_isQuasigroup_1952 ::
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Algebra.Structures.T_IsQuasigroup_2966
d_isQuasigroup_1952 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
      (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3222 (coe v0))
-- _.IsRightBolLoop.leftDivides
d_leftDivides_1954 ::
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_leftDivides_1954 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_leftDivides_2990
      (coe
         MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
         (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3222 (coe v0)))
-- _.IsRightBolLoop.leftDividesʳ
d_leftDivides'691'_1956 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_leftDivides'691'_1956 = erased
-- _.IsRightBolLoop.leftDividesˡ
d_leftDivides'737'_1958 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_leftDivides'737'_1958 = erased
-- _.IsRightBolLoop.refl
d_refl_1960 ::
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_1960 = erased
-- _.IsRightBolLoop.reflexive
d_reflexive_1962 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_1962 = erased
-- _.IsRightBolLoop.rightBol
d_rightBol_1964 ::
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_rightBol_1964 = erased
-- _.IsRightBolLoop.rightDivides
d_rightDivides_1966 ::
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_rightDivides_1966 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_rightDivides_2992
      (coe
         MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062
         (coe MAlonzo.Code.Algebra.Structures.d_isLoop_3222 (coe v0)))
-- _.IsRightBolLoop.rightDividesʳ
d_rightDivides'691'_1968 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_rightDivides'691'_1968 = erased
-- _.IsRightBolLoop.rightDividesˡ
d_rightDivides'737'_1970 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_rightDivides'737'_1970 = erased
-- _.IsRightBolLoop.setoid
d_setoid_1972 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_1972 ~v0 ~v1 ~v2 ~v3 v4 = du_setoid_1972 v4
du_setoid_1972 ::
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_1972 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isLoop_3222 (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isQuasigroup_3062 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_setoid_200
            (coe MAlonzo.Code.Algebra.Structures.d_isMagma_2984 (coe v2))))
-- _.IsRightBolLoop.sym
d_sym_1974 ::
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_1974 = erased
-- _.IsRightBolLoop.trans
d_trans_1976 ::
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_1976 = erased
-- _.IsRightBolLoop.∙-cong
d_'8729''45'cong_1978 ::
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_1978 = erased
-- _.IsRightBolLoop.∙-congʳ
d_'8729''45'cong'691'_1980 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1980 = erased
-- _.IsRightBolLoop.∙-congˡ
d_'8729''45'cong'737'_1982 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRightBolLoop_3208 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1982 = erased
-- _.IsRing._//_
d__'47''47'__1986 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d__'47''47'__1986 v0 ~v1 v2 ~v3 ~v4 ~v5 = du__'47''47'__1986 v0 v2
du__'47''47'__1986 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
du__'47''47'__1986 v0 v1
  = coe
      MAlonzo.Code.Algebra.Structures.du__'47''47'__1098 (coe v0)
      (coe v1)
-- _.IsRing.*-assoc
d_'42''45'assoc_1988 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'assoc_1988 = erased
-- _.IsRing.*-cong
d_'42''45'cong_1990 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'cong_1990 = erased
-- _.IsRing.∙-congʳ
d_'8729''45'cong'691'_1992 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_1992 = erased
-- _.IsRing.∙-congˡ
d_'8729''45'cong'737'_1994 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_1994 = erased
-- _.IsRing.*-identity
d_'42''45'identity_1996 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_'42''45'identity_1996 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'42''45'identity_2700 (coe v0)
-- _.IsRing.identityʳ
d_identity'691'_1998 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_1998 = erased
-- _.IsRing.identityˡ
d_identity'737'_2000 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_2000 = erased
-- _.IsRing.*-isMagma
d_'42''45'isMagma_2002 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_'42''45'isMagma_2002 v0 v1 v2 v3 ~v4 v5
  = du_'42''45'isMagma_2002 v0 v1 v2 v3 v5
du_'42''45'isMagma_2002 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
du_'42''45'isMagma_2002 v0 v1 v2 v3 v4
  = let v5
          = coe
              MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
              (coe v4) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_'42''45'isMagma_1282
         (coe
            MAlonzo.Code.Algebra.Structures.du_isNearSemiring_2408 (coe v0)
            (coe v1) (coe v2) (coe v3) (coe v5)))
-- _.IsRing.*-isMonoid
d_'42''45'isMonoid_2004 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_'42''45'isMonoid_2004 v0 v1 v2 v3 v4 v5
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isMonoid_2792 v0 v1 v2
      v3 v5
-- _.IsRing.*-isSemigroup
d_'42''45'isSemigroup_2006 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_'42''45'isSemigroup_2006 v0 v1 v2 v3 ~v4 v5
  = du_'42''45'isSemigroup_2006 v0 v1 v2 v3 v5
du_'42''45'isSemigroup_2006 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
du_'42''45'isSemigroup_2006 v0 v1 v2 v3 v4
  = let v5
          = coe
              MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
              (coe v4) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_'42''45'isSemigroup_1284
         (coe
            MAlonzo.Code.Algebra.Structures.du_isNearSemiring_2408 (coe v0)
            (coe v1) (coe v2) (coe v3) (coe v5)))
-- _.IsRing.assoc
d_assoc_2008 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_2008 = erased
-- _.IsRing.comm
d_comm_2010 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_2010 = erased
-- _.IsRing.∙-cong
d_'8729''45'cong_2012 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_2012 = erased
-- _.IsRing.∙-congʳ
d_'8729''45'cong'691'_2014 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_2014 = erased
-- _.IsRing.∙-congˡ
d_'8729''45'cong'737'_2016 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_2016 = erased
-- _.IsRing.identity
d_identity_2018 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_2018 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_identity_2018 v5
du_identity_2018 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
du_identity_2018 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
         (coe
            MAlonzo.Code.Algebra.Structures.d_isGroup_1144
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2694
               (coe v0))))
-- _.IsRing.identityʳ
d_identity'691'_2020 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_2020 = erased
-- _.IsRing.identityˡ
d_identity'737'_2022 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_2022 = erased
-- _.IsRing.+-isAbelianGroup
d_'43''45'isAbelianGroup_2024 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132
d_'43''45'isAbelianGroup_2024 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2694
      (coe v0)
-- _.IsRing.isCommutativeMagma
d_isCommutativeMagma_2026 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_2026 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isCommutativeMagma_2026 v5
du_isCommutativeMagma_2026 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_2026 v0
  = let v1
          = coe
              MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
                 (coe v1) in
       coe
         (let v3
                = coe
                    MAlonzo.Code.Algebra.Structures.du_isCommutativeMonoid_1204
                    (coe v2) in
          coe
            (coe
               MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
               (coe
                  MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
                  (coe v3)))))
-- _.IsRing.isCommutativeMonoid
d_isCommutativeMonoid_2028 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
d_isCommutativeMonoid_2028 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isCommutativeMonoid_2028 v5
du_isCommutativeMonoid_2028 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
du_isCommutativeMonoid_2028 v0
  = let v1
          = coe
              MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isCommutativeMonoid_1204
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
            (coe v1)))
-- _.IsRing.isCommutativeSemigroup
d_isCommutativeSemigroup_2030 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_isCommutativeSemigroup_2030 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isCommutativeSemigroup_2030 v5
du_isCommutativeSemigroup_2030 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
du_isCommutativeSemigroup_2030 v0
  = let v1
          = coe
              MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
                 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
            (coe
               MAlonzo.Code.Algebra.Structures.du_isCommutativeMonoid_1204
               (coe v2))))
-- _.IsRing.isGroup
d_isGroup_2032 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036
d_isGroup_2032 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_isGroup_2032 v5
du_isGroup_2032 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036
du_isGroup_2032 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isGroup_1144
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2694
         (coe v0))
-- _.IsRing.isInvertibleMagma
d_isInvertibleMagma_2034 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924
d_isInvertibleMagma_2034 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isInvertibleMagma_2034 v5
du_isInvertibleMagma_2034 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924
du_isInvertibleMagma_2034 v0
  = let v1
          = coe
              MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
                 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isInvertibleMagma_1122
            (coe MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v2))))
-- _.IsRing.isInvertibleUnitalMagma
d_isInvertibleUnitalMagma_2036 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976
d_isInvertibleUnitalMagma_2036 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isInvertibleUnitalMagma_2036 v5
du_isInvertibleUnitalMagma_2036 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976
du_isInvertibleUnitalMagma_2036 v0
  = let v1
          = coe
              MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
                 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isInvertibleUnitalMagma_1124
            (coe MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v2))))
-- _.IsRing.isMagma
d_isMagma_2038 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_2038 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_isMagma_2038 v5
du_isMagma_2038 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
du_isMagma_2038 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe
            MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
            (coe
               MAlonzo.Code.Algebra.Structures.d_isGroup_1144
               (coe
                  MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2694
                  (coe v0)))))
-- _.IsRing.isMonoid
d_isMonoid_2040 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_isMonoid_2040 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_isMonoid_2040 v5
du_isMonoid_2040 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
du_isMonoid_2040 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
      (coe
         MAlonzo.Code.Algebra.Structures.d_isGroup_1144
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2694
            (coe v0)))
-- _.IsRing.isSemigroup
d_isSemigroup_2042 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_2042 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_isSemigroup_2042 v5
du_isSemigroup_2042 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
du_isSemigroup_2042 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
         (coe
            MAlonzo.Code.Algebra.Structures.d_isGroup_1144
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2694
               (coe v0))))
-- _.IsRing.isUnitalMagma
d_isUnitalMagma_2044 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_2044 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isUnitalMagma_2044 v5
du_isUnitalMagma_2044 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_2044 v0
  = let v1
          = coe
              MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v2) in
          coe
            (coe
               MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
               (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v3)))))
-- _.IsRing.⁻¹-cong
d_'8315''185''45'cong_2046 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8315''185''45'cong_2046 = erased
-- _.IsRing.inverse
d_inverse_2048 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_inverse_2048 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_inverse_2048 v5
du_inverse_2048 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
du_inverse_2048 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_inverse_1052
      (coe
         MAlonzo.Code.Algebra.Structures.d_isGroup_1144
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2694
            (coe v0)))
-- _.IsRing.inverseʳ
d_inverse'691'_2050 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_inverse'691'_2050 = erased
-- _.IsRing.inverseˡ
d_inverse'737'_2052 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_inverse'737'_2052 = erased
-- _.IsRing.distrib
d_distrib_2054 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_distrib_2054 v0
  = coe MAlonzo.Code.Algebra.Structures.d_distrib_2702 (coe v0)
-- _.IsRing.distribʳ
d_distrib'691'_2056 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'691'_2056 = erased
-- _.IsRing.distribˡ
d_distrib'737'_2058 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'737'_2058 = erased
-- _.IsRing.isEquivalence
d_isEquivalence_2060 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_2060 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isEquivalence_2060 v5
du_isEquivalence_2060 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
du_isEquivalence_2060 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe
               MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isGroup_1144
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2694
                     (coe v0))))))
-- _.IsRing.isNearSemiring
d_isNearSemiring_2062 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
d_isNearSemiring_2062 v0 v1 v2 v3 ~v4 v5
  = du_isNearSemiring_2062 v0 v1 v2 v3 v5
du_isNearSemiring_2062 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
du_isNearSemiring_2062 v0 v1 v2 v3 v4
  = coe
      MAlonzo.Code.Algebra.Structures.du_isNearSemiring_2408 (coe v0)
      (coe v1) (coe v2) (coe v3)
      (coe
         MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704 (coe v4))
-- _.IsRing.isPartialEquivalence
d_isPartialEquivalence_2064 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_2064 ~v0 ~v1 ~v2 ~v3 ~v4 v5
  = du_isPartialEquivalence_2064 v5
du_isPartialEquivalence_2064 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_2064 v0
  = let v1
          = coe
              MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v3) in
             coe
               (let v5
                      = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v4) in
                coe
                  (let v6 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v5) in
                   coe
                     (coe
                        MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
                        (coe
                           MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v6))))))))
-- _.IsRing.isRingWithoutOne
d_isRingWithoutOne_2066 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306
d_isRingWithoutOne_2066 v0 v1 v2 v3 v4 v5
  = coe MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704 v5
-- _.IsRing.isSemiring
d_isSemiring_2068 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590
d_isSemiring_2068 v0 v1 v2 v3 v4 v5
  = coe
      MAlonzo.Code.Algebra.Structures.du_isSemiring_2802 v0 v1 v2 v3 v5
-- _.IsRing.isSemiringWithoutAnnihilatingZero
d_isSemiringWithoutAnnihilatingZero_2070 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488
d_isSemiringWithoutAnnihilatingZero_2070 v0 v1 v2 v3 v4 v5
  = coe
      MAlonzo.Code.Algebra.Structures.du_isSemiringWithoutAnnihilatingZero_2800
      v5
-- _.IsRing.isSemiringWithoutOne
d_isSemiringWithoutOne_2072 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298
d_isSemiringWithoutOne_2072 v0 v1 v2 v3 ~v4 v5
  = du_isSemiringWithoutOne_2072 v0 v1 v2 v3 v5
du_isSemiringWithoutOne_2072 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298
du_isSemiringWithoutOne_2072 v0 v1 v2 v3 v4
  = coe
      MAlonzo.Code.Algebra.Structures.du_isSemiringWithoutOne_1680
      (coe
         MAlonzo.Code.Algebra.Structures.du_isSemiring_2802 (coe v0)
         (coe v1) (coe v2) (coe v3) (coe v4))
-- _.IsRing.refl
d_refl_2074 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_2074 = erased
-- _.IsRing.reflexive
d_reflexive_2076 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_2076 = erased
-- _.IsRing.setoid
d_setoid_2078 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_2078 ~v0 ~v1 ~v2 ~v3 ~v4 v5 = du_setoid_2078 v5
du_setoid_2078 ::
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_2078 v0
  = let v1
          = coe
              MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v3) in
             coe
               (let v5
                      = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v4) in
                coe
                  (coe
                     MAlonzo.Code.Algebra.Structures.du_setoid_200
                     (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v5)))))))
-- _.IsRing.sym
d_sym_2080 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_2080 = erased
-- _.IsRing.trans
d_trans_2082 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_2082 = erased
-- _.IsRing.uniqueʳ-⁻¹
d_unique'691''45''8315''185'_2084 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_unique'691''45''8315''185'_2084 = erased
-- _.IsRing.uniqueˡ-⁻¹
d_unique'737''45''8315''185'_2086 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_unique'737''45''8315''185'_2086 = erased
-- _.IsRing.zero
d_zero_2088 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_zero_2088 v0 v1 v2 v3 ~v4 v5 = du_zero_2088 v0 v1 v2 v3 v5
du_zero_2088 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
du_zero_2088 v0 v1 v2 v3 v4
  = coe
      MAlonzo.Code.Algebra.Structures.du_zero_2406 (coe v0) (coe v1)
      (coe v2) (coe v3)
      (coe
         MAlonzo.Code.Algebra.Structures.du_isRingWithoutOne_2704 (coe v4))
-- _.IsRing.zeroʳ
d_zero'691'_2090 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'691'_2090 = erased
-- _.IsRing.zeroˡ
d_zero'737'_2092 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRing_2672 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'737'_2092 = erased
-- _.IsRingWithoutOne._//_
d__'47''47'__2096 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d__'47''47'__2096 v0 ~v1 v2 ~v3 ~v4 = du__'47''47'__2096 v0 v2
du__'47''47'__2096 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
du__'47''47'__2096 v0 v1
  = coe
      MAlonzo.Code.Algebra.Structures.du__'47''47'__1098 (coe v0)
      (coe v1)
-- _.IsRingWithoutOne.*-assoc
d_'42''45'assoc_2098 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'assoc_2098 = erased
-- _.IsRingWithoutOne.*-cong
d_'42''45'cong_2100 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'cong_2100 = erased
-- _.IsRingWithoutOne.∙-congʳ
d_'8729''45'cong'691'_2102 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_2102 = erased
-- _.IsRingWithoutOne.∙-congˡ
d_'8729''45'cong'737'_2104 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_2104 = erased
-- _.IsRingWithoutOne.*-isMagma
d_'42''45'isMagma_2106 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_'42''45'isMagma_2106 v0 v1 v2 v3 v4
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isMagma_1282
      (coe
         MAlonzo.Code.Algebra.Structures.du_isNearSemiring_2408 (coe v0)
         (coe v1) (coe v2) (coe v3) (coe v4))
-- _.IsRingWithoutOne.*-isSemigroup
d_'42''45'isSemigroup_2108 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_'42''45'isSemigroup_2108 v0 v1 v2 v3 v4
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isSemigroup_1284
      (coe
         MAlonzo.Code.Algebra.Structures.du_isNearSemiring_2408 (coe v0)
         (coe v1) (coe v2) (coe v3) (coe v4))
-- _.IsRingWithoutOne.assoc
d_assoc_2110 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_2110 = erased
-- _.IsRingWithoutOne.comm
d_comm_2112 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_2112 = erased
-- _.IsRingWithoutOne.∙-cong
d_'8729''45'cong_2114 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_2114 = erased
-- _.IsRingWithoutOne.∙-congʳ
d_'8729''45'cong'691'_2116 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_2116 = erased
-- _.IsRingWithoutOne.∙-congˡ
d_'8729''45'cong'737'_2118 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_2118 = erased
-- _.IsRingWithoutOne.identity
d_identity_2120 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_2120 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
         (coe
            MAlonzo.Code.Algebra.Structures.d_isGroup_1144
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
               (coe v0))))
-- _.IsRingWithoutOne.identityʳ
d_identity'691'_2122 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_2122 = erased
-- _.IsRingWithoutOne.identityˡ
d_identity'737'_2124 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_2124 = erased
-- _.IsRingWithoutOne.+-isAbelianGroup
d_'43''45'isAbelianGroup_2126 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsAbelianGroup_1132
d_'43''45'isAbelianGroup_2126 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
      (coe v0)
-- _.IsRingWithoutOne.isCommutativeMagma
d_isCommutativeMagma_2128 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_2128 ~v0 ~v1 ~v2 ~v3 v4
  = du_isCommutativeMagma_2128 v4
du_isCommutativeMagma_2128 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_2128 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
              (coe v0) in
    coe
      (let v2
             = coe
                 MAlonzo.Code.Algebra.Structures.du_isCommutativeMonoid_1204
                 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
            (coe
               MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
               (coe v2))))
-- _.IsRingWithoutOne.isCommutativeMonoid
d_isCommutativeMonoid_2130 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
d_isCommutativeMonoid_2130 ~v0 ~v1 ~v2 ~v3 v4
  = du_isCommutativeMonoid_2130 v4
du_isCommutativeMonoid_2130 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
du_isCommutativeMonoid_2130 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isCommutativeMonoid_1204
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
         (coe v0))
-- _.IsRingWithoutOne.isCommutativeSemigroup
d_isCommutativeSemigroup_2132 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_isCommutativeSemigroup_2132 ~v0 ~v1 ~v2 ~v3 v4
  = du_isCommutativeSemigroup_2132 v4
du_isCommutativeSemigroup_2132 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
du_isCommutativeSemigroup_2132 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeMonoid_1204
            (coe v1)))
-- _.IsRingWithoutOne.isGroup
d_isGroup_2134 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsGroup_1036
d_isGroup_2134 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isGroup_1144
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
         (coe v0))
-- _.IsRingWithoutOne.isInvertibleMagma
d_isInvertibleMagma_2136 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924
d_isInvertibleMagma_2136 ~v0 ~v1 ~v2 ~v3 v4
  = du_isInvertibleMagma_2136 v4
du_isInvertibleMagma_2136 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleMagma_924
du_isInvertibleMagma_2136 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isInvertibleMagma_1122
         (coe MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v1)))
-- _.IsRingWithoutOne.isInvertibleUnitalMagma
d_isInvertibleUnitalMagma_2138 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976
d_isInvertibleUnitalMagma_2138 ~v0 ~v1 ~v2 ~v3 v4
  = du_isInvertibleUnitalMagma_2138 v4
du_isInvertibleUnitalMagma_2138 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsInvertibleUnitalMagma_976
du_isInvertibleUnitalMagma_2138 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isInvertibleUnitalMagma_1124
         (coe MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v1)))
-- _.IsRingWithoutOne.isMagma
d_isMagma_2140 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_2140 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe
            MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
            (coe
               MAlonzo.Code.Algebra.Structures.d_isGroup_1144
               (coe
                  MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
                  (coe v0)))))
-- _.IsRingWithoutOne.isMonoid
d_isMonoid_2142 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_isMonoid_2142 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
      (coe
         MAlonzo.Code.Algebra.Structures.d_isGroup_1144
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
            (coe v0)))
-- _.IsRingWithoutOne.isSemigroup
d_isSemigroup_2144 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_2144 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
         (coe
            MAlonzo.Code.Algebra.Structures.d_isGroup_1144
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
               (coe v0))))
-- _.IsRingWithoutOne.isUnitalMagma
d_isUnitalMagma_2146 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_2146 ~v0 ~v1 ~v2 ~v3 v4 = du_isUnitalMagma_2146 v4
du_isUnitalMagma_2146 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_2146 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
            (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v2))))
-- _.IsRingWithoutOne.⁻¹-cong
d_'8315''185''45'cong_2148 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8315''185''45'cong_2148 = erased
-- _.IsRingWithoutOne.inverse
d_inverse_2150 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_inverse_2150 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_inverse_1052
      (coe
         MAlonzo.Code.Algebra.Structures.d_isGroup_1144
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
            (coe v0)))
-- _.IsRingWithoutOne.inverseʳ
d_inverse'691'_2152 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_inverse'691'_2152 = erased
-- _.IsRingWithoutOne.inverseˡ
d_inverse'737'_2154 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_inverse'737'_2154 = erased
-- _.IsRingWithoutOne.distrib
d_distrib_2156 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_distrib_2156 v0
  = coe MAlonzo.Code.Algebra.Structures.d_distrib_2330 (coe v0)
-- _.IsRingWithoutOne.distribʳ
d_distrib'691'_2158 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'691'_2158 = erased
-- _.IsRingWithoutOne.distribˡ
d_distrib'737'_2160 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'737'_2160 = erased
-- _.IsRingWithoutOne.isEquivalence
d_isEquivalence_2162 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_2162 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe
               MAlonzo.Code.Algebra.Structures.d_isMonoid_1050
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isGroup_1144
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
                     (coe v0))))))
-- _.IsRingWithoutOne.isNearSemiring
d_isNearSemiring_2164 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
d_isNearSemiring_2164
  = coe MAlonzo.Code.Algebra.Structures.du_isNearSemiring_2408
-- _.IsRingWithoutOne.isPartialEquivalence
d_isPartialEquivalence_2166 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_2166 ~v0 ~v1 ~v2 ~v3 v4
  = du_isPartialEquivalence_2166 v4
du_isPartialEquivalence_2166 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_2166 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v3) in
             coe
               (let v5 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v4) in
                coe
                  (coe
                     MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
                     (coe
                        MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v5)))))))
-- _.IsRingWithoutOne.refl
d_refl_2168 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_2168 = erased
-- _.IsRingWithoutOne.reflexive
d_reflexive_2170 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_2170 = erased
-- _.IsRingWithoutOne.setoid
d_setoid_2172 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_2172 ~v0 ~v1 ~v2 ~v3 v4 = du_setoid_2172 v4
du_setoid_2172 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_2172 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isAbelianGroup_2324
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isGroup_1144 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isMonoid_1050 (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v3) in
             coe
               (coe
                  MAlonzo.Code.Algebra.Structures.du_setoid_200
                  (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v4))))))
-- _.IsRingWithoutOne.sym
d_sym_2174 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_2174 = erased
-- _.IsRingWithoutOne.trans
d_trans_2176 ::
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_2176 = erased
-- _.IsRingWithoutOne.uniqueʳ-⁻¹
d_unique'691''45''8315''185'_2178 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_unique'691''45''8315''185'_2178 = erased
-- _.IsRingWithoutOne.uniqueˡ-⁻¹
d_unique'737''45''8315''185'_2180 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_unique'737''45''8315''185'_2180 = erased
-- _.IsRingWithoutOne.zero
d_zero_2182 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_zero_2182 = coe MAlonzo.Code.Algebra.Structures.du_zero_2406
-- _.IsRingWithoutOne.zeroʳ
d_zero'691'_2184 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'691'_2184 = erased
-- _.IsRingWithoutOne.zeroˡ
d_zero'737'_2186 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsRingWithoutOne_2306 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'737'_2186 = erased
-- _.IsSelectiveMagma.isEquivalence
d_isEquivalence_2190 ::
  MAlonzo.Code.Algebra.Structures.T_IsSelectiveMagma_436 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_2190 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_444 (coe v0))
-- _.IsSelectiveMagma.isMagma
d_isMagma_2192 ::
  MAlonzo.Code.Algebra.Structures.T_IsSelectiveMagma_436 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_2192 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isMagma_444 (coe v0)
-- _.IsSelectiveMagma.isPartialEquivalence
d_isPartialEquivalence_2194 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsSelectiveMagma_436 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_2194 ~v0 v1
  = du_isPartialEquivalence_2194 v1
du_isPartialEquivalence_2194 ::
  MAlonzo.Code.Algebra.Structures.T_IsSelectiveMagma_436 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_2194 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isMagma_444 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
         (coe MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v1)))
-- _.IsSelectiveMagma.refl
d_refl_2196 ::
  MAlonzo.Code.Algebra.Structures.T_IsSelectiveMagma_436 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_2196 = erased
-- _.IsSelectiveMagma.reflexive
d_reflexive_2198 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsSelectiveMagma_436 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_2198 = erased
-- _.IsSelectiveMagma.sel
d_sel_2200 ::
  MAlonzo.Code.Algebra.Structures.T_IsSelectiveMagma_436 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Data.Sum.Base.T__'8846'__30
d_sel_2200 v0
  = coe MAlonzo.Code.Algebra.Structures.d_sel_446 (coe v0)
-- _.IsSelectiveMagma.setoid
d_setoid_2202 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsSelectiveMagma_436 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_2202 ~v0 v1 = du_setoid_2202 v1
du_setoid_2202 ::
  MAlonzo.Code.Algebra.Structures.T_IsSelectiveMagma_436 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_2202 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_setoid_200
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_444 (coe v0))
-- _.IsSelectiveMagma.sym
d_sym_2204 ::
  MAlonzo.Code.Algebra.Structures.T_IsSelectiveMagma_436 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_2204 = erased
-- _.IsSelectiveMagma.trans
d_trans_2206 ::
  MAlonzo.Code.Algebra.Structures.T_IsSelectiveMagma_436 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_2206 = erased
-- _.IsSelectiveMagma.∙-cong
d_'8729''45'cong_2208 ::
  MAlonzo.Code.Algebra.Structures.T_IsSelectiveMagma_436 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_2208 = erased
-- _.IsSelectiveMagma.∙-congʳ
d_'8729''45'cong'691'_2210 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsSelectiveMagma_436 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_2210 = erased
-- _.IsSelectiveMagma.∙-congˡ
d_'8729''45'cong'737'_2212 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsSelectiveMagma_436 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_2212 = erased
-- _.IsSemigroup.assoc
d_assoc_2216 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_2216 = erased
-- _.IsSemigroup.isEquivalence
d_isEquivalence_2218 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_2218 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v0))
-- _.IsSemigroup.isMagma
d_isMagma_2220 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_2220 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v0)
-- _.IsSemigroup.isPartialEquivalence
d_isPartialEquivalence_2222 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_2222 ~v0 v1
  = du_isPartialEquivalence_2222 v1
du_isPartialEquivalence_2222 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_2222 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
         (coe MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v1)))
-- _.IsSemigroup.refl
d_refl_2224 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_2224 = erased
-- _.IsSemigroup.reflexive
d_reflexive_2226 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_2226 = erased
-- _.IsSemigroup.setoid
d_setoid_2228 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_2228 ~v0 v1 = du_setoid_2228 v1
du_setoid_2228 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_2228 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_setoid_200
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v0))
-- _.IsSemigroup.sym
d_sym_2230 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_2230 = erased
-- _.IsSemigroup.trans
d_trans_2232 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_2232 = erased
-- _.IsSemigroup.∙-cong
d_'8729''45'cong_2234 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_2234 = erased
-- _.IsSemigroup.∙-congʳ
d_'8729''45'cong'691'_2236 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_2236 = erased
-- _.IsSemigroup.∙-congˡ
d_'8729''45'cong'737'_2238 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_2238 = erased
-- _.IsSemimedialMagma.isEquivalence
d_isEquivalence_2242 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemimedialMagma_396 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_2242 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_404 (coe v0))
-- _.IsSemimedialMagma.isMagma
d_isMagma_2244 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemimedialMagma_396 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_2244 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isMagma_404 (coe v0)
-- _.IsSemimedialMagma.isPartialEquivalence
d_isPartialEquivalence_2246 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsSemimedialMagma_396 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_2246 ~v0 v1
  = du_isPartialEquivalence_2246 v1
du_isPartialEquivalence_2246 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemimedialMagma_396 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_2246 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isMagma_404 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
         (coe MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v1)))
-- _.IsSemimedialMagma.refl
d_refl_2248 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemimedialMagma_396 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_2248 = erased
-- _.IsSemimedialMagma.reflexive
d_reflexive_2250 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsSemimedialMagma_396 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_2250 = erased
-- _.IsSemimedialMagma.semiMedial
d_semiMedial_2252 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemimedialMagma_396 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_semiMedial_2252 v0
  = coe MAlonzo.Code.Algebra.Structures.d_semiMedial_406 (coe v0)
-- _.IsSemimedialMagma.semimedialʳ
d_semimedial'691'_2254 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsSemimedialMagma_396 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_semimedial'691'_2254 = erased
-- _.IsSemimedialMagma.semimedialˡ
d_semimedial'737'_2256 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsSemimedialMagma_396 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_semimedial'737'_2256 = erased
-- _.IsSemimedialMagma.setoid
d_setoid_2258 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsSemimedialMagma_396 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_2258 ~v0 v1 = du_setoid_2258 v1
du_setoid_2258 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemimedialMagma_396 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_2258 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_setoid_200
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_404 (coe v0))
-- _.IsSemimedialMagma.sym
d_sym_2260 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemimedialMagma_396 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_2260 = erased
-- _.IsSemimedialMagma.trans
d_trans_2262 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemimedialMagma_396 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_2262 = erased
-- _.IsSemimedialMagma.∙-cong
d_'8729''45'cong_2264 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemimedialMagma_396 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_2264 = erased
-- _.IsSemimedialMagma.∙-congʳ
d_'8729''45'cong'691'_2266 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsSemimedialMagma_396 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_2266 = erased
-- _.IsSemimedialMagma.∙-congˡ
d_'8729''45'cong'737'_2268 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Algebra.Structures.T_IsSemimedialMagma_396 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_2268 = erased
-- _.IsSemiring.*-assoc
d_'42''45'assoc_2272 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'assoc_2272 = erased
-- _.IsSemiring.*-cong
d_'42''45'cong_2274 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'cong_2274 = erased
-- _.IsSemiring.∙-congʳ
d_'8729''45'cong'691'_2276 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_2276 = erased
-- _.IsSemiring.∙-congˡ
d_'8729''45'cong'737'_2278 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_2278 = erased
-- _.IsSemiring.*-identity
d_'42''45'identity_2280 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_'42''45'identity_2280 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'42''45'identity_1514
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe v0))
-- _.IsSemiring.identityʳ
d_identity'691'_2282 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_2282 = erased
-- _.IsSemiring.identityˡ
d_identity'737'_2284 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_2284 = erased
-- _.IsSemiring.*-isMagma
d_'42''45'isMagma_2286 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_'42''45'isMagma_2286 ~v0 ~v1 ~v2 ~v3 v4
  = du_'42''45'isMagma_2286 v4
du_'42''45'isMagma_2286 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
du_'42''45'isMagma_2286 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isMagma_1566
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe v0))
-- _.IsSemiring.*-isMonoid
d_'42''45'isMonoid_2288 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_'42''45'isMonoid_2288 ~v0 ~v1 ~v2 ~v3 v4
  = du_'42''45'isMonoid_2288 v4
du_'42''45'isMonoid_2288 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
du_'42''45'isMonoid_2288 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isMonoid_1570
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe v0))
-- _.IsSemiring.*-isSemigroup
d_'42''45'isSemigroup_2290 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_'42''45'isSemigroup_2290 ~v0 ~v1 ~v2 ~v3 v4
  = du_'42''45'isSemigroup_2290 v4
du_'42''45'isSemigroup_2290 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
du_'42''45'isSemigroup_2290 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isSemigroup_1568
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe v0))
-- _.IsSemiring.assoc
d_assoc_2292 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_2292 = erased
-- _.IsSemiring.comm
d_comm_2294 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_2294 = erased
-- _.IsSemiring.∙-cong
d_'8729''45'cong_2296 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_2296 = erased
-- _.IsSemiring.∙-congʳ
d_'8729''45'cong'691'_2298 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_2298 = erased
-- _.IsSemiring.∙-congˡ
d_'8729''45'cong'737'_2300 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_2300 = erased
-- _.IsSemiring.identity
d_identity_2302 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_2302 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_746
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
               (coe v0))))
-- _.IsSemiring.identityʳ
d_identity'691'_2304 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_2304 = erased
-- _.IsSemiring.identityˡ
d_identity'737'_2306 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_2306 = erased
-- _.IsSemiring.isCommutativeMagma
d_isCommutativeMagma_2308 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_2308 ~v0 ~v1 ~v2 ~v3 v4
  = du_isCommutativeMagma_2308 v4
du_isCommutativeMagma_2308 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_2308 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
            (coe
               MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
               (coe v2))))
-- _.IsSemiring.+-isCommutativeMonoid
d_'43''45'isCommutativeMonoid_2310 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
d_'43''45'isCommutativeMonoid_2310 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe v0))
-- _.IsSemiring.isCommutativeSemigroup
d_isCommutativeSemigroup_2312 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_isCommutativeSemigroup_2312 ~v0 ~v1 ~v2 ~v3 v4
  = du_isCommutativeSemigroup_2312 v4
du_isCommutativeSemigroup_2312 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
du_isCommutativeSemigroup_2312 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
            (coe v1)))
-- _.IsSemiring.isMagma
d_isMagma_2314 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_2314 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe
            MAlonzo.Code.Algebra.Structures.d_isMonoid_746
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                  (coe v0)))))
-- _.IsSemiring.isMonoid
d_isMonoid_2316 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_isMonoid_2316 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMonoid_746
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
            (coe v0)))
-- _.IsSemiring.isSemigroup
d_isSemigroup_2318 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_2318 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_746
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
               (coe v0))))
-- _.IsSemiring.isUnitalMagma
d_isUnitalMagma_2320 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_2320 ~v0 ~v1 ~v2 ~v3 v4 = du_isUnitalMagma_2320 v4
du_isUnitalMagma_2320 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_2320 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                 (coe v1) in
       coe
         (coe
            MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
            (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v2))))
-- _.IsSemiring.distrib
d_distrib_2322 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_distrib_2322 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_distrib_1516
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
         (coe v0))
-- _.IsSemiring.distribʳ
d_distrib'691'_2324 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'691'_2324 = erased
-- _.IsSemiring.distribˡ
d_distrib'737'_2326 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'737'_2326 = erased
-- _.IsSemiring.isEquivalence
d_isEquivalence_2328 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_2328 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe
               MAlonzo.Code.Algebra.Structures.d_isMonoid_746
               (coe
                  MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
                     (coe v0))))))
-- _.IsSemiring.isNearSemiring
d_isNearSemiring_2330 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
d_isNearSemiring_2330 ~v0 ~v1 ~v2 ~v3 v4
  = du_isNearSemiring_2330 v4
du_isNearSemiring_2330 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
du_isNearSemiring_2330 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isNearSemiring_1384
      (coe
         MAlonzo.Code.Algebra.Structures.du_isSemiringWithoutOne_1680
         (coe v0))
-- _.IsSemiring.isPartialEquivalence
d_isPartialEquivalence_2332 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_2332 ~v0 ~v1 ~v2 ~v3 v4
  = du_isPartialEquivalence_2332 v4
du_isPartialEquivalence_2332 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_2332 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v3) in
             coe
               (let v5 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v4) in
                coe
                  (coe
                     MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
                     (coe
                        MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v5)))))))
-- _.IsSemiring.isSemiringWithoutAnnihilatingZero
d_isSemiringWithoutAnnihilatingZero_2334 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488
d_isSemiringWithoutAnnihilatingZero_2334 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
      (coe v0)
-- _.IsSemiring.isSemiringWithoutOne
d_isSemiringWithoutOne_2336 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298
d_isSemiringWithoutOne_2336 v0 v1 v2 v3 v4
  = coe
      MAlonzo.Code.Algebra.Structures.du_isSemiringWithoutOne_1680 v4
-- _.IsSemiring.refl
d_refl_2338 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_2338 = erased
-- _.IsSemiring.reflexive
d_reflexive_2340 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_2340 = erased
-- _.IsSemiring.setoid
d_setoid_2342 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_2342 ~v0 ~v1 ~v2 ~v3 v4 = du_setoid_2342 v4
du_setoid_2342 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_2342 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isSemiringWithoutAnnihilatingZero_1604
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v2) in
          coe
            (let v4
                   = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v3) in
             coe
               (coe
                  MAlonzo.Code.Algebra.Structures.du_setoid_200
                  (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v4))))))
-- _.IsSemiring.sym
d_sym_2344 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_2344 = erased
-- _.IsSemiring.trans
d_trans_2346 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_2346 = erased
-- _.IsSemiring.zero
d_zero_2348 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_zero_2348 v0
  = coe MAlonzo.Code.Algebra.Structures.d_zero_1606 (coe v0)
-- _.IsSemiring.zeroʳ
d_zero'691'_2350 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'691'_2350 = erased
-- _.IsSemiring.zeroˡ
d_zero'737'_2352 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiring_1590 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'737'_2352 = erased
-- _.IsSemiringWithoutAnnihilatingZero.*-assoc
d_'42''45'assoc_2356 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'assoc_2356 = erased
-- _.IsSemiringWithoutAnnihilatingZero.*-cong
d_'42''45'cong_2358 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'cong_2358 = erased
-- _.IsSemiringWithoutAnnihilatingZero.∙-congʳ
d_'8729''45'cong'691'_2360 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_2360 = erased
-- _.IsSemiringWithoutAnnihilatingZero.∙-congˡ
d_'8729''45'cong'737'_2362 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_2362 = erased
-- _.IsSemiringWithoutAnnihilatingZero.*-identity
d_'42''45'identity_2364 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_'42''45'identity_2364 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'42''45'identity_1514 (coe v0)
-- _.IsSemiringWithoutAnnihilatingZero.identityʳ
d_identity'691'_2366 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_2366 = erased
-- _.IsSemiringWithoutAnnihilatingZero.identityˡ
d_identity'737'_2368 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_2368 = erased
-- _.IsSemiringWithoutAnnihilatingZero.*-isMagma
d_'42''45'isMagma_2370 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_'42''45'isMagma_2370 v0 v1 v2 v3 v4
  = coe MAlonzo.Code.Algebra.Structures.du_'42''45'isMagma_1566 v4
-- _.IsSemiringWithoutAnnihilatingZero.*-isMonoid
d_'42''45'isMonoid_2372 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_'42''45'isMonoid_2372 v0 v1 v2 v3 v4
  = coe MAlonzo.Code.Algebra.Structures.du_'42''45'isMonoid_1570 v4
-- _.IsSemiringWithoutAnnihilatingZero.*-isSemigroup
d_'42''45'isSemigroup_2374 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_'42''45'isSemigroup_2374 v0 v1 v2 v3 v4
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isSemigroup_1568 v4
-- _.IsSemiringWithoutAnnihilatingZero.assoc
d_assoc_2376 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_2376 = erased
-- _.IsSemiringWithoutAnnihilatingZero.comm
d_comm_2378 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_2378 = erased
-- _.IsSemiringWithoutAnnihilatingZero.∙-cong
d_'8729''45'cong_2380 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_2380 = erased
-- _.IsSemiringWithoutAnnihilatingZero.∙-congʳ
d_'8729''45'cong'691'_2382 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_2382 = erased
-- _.IsSemiringWithoutAnnihilatingZero.∙-congˡ
d_'8729''45'cong'737'_2384 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_2384 = erased
-- _.IsSemiringWithoutAnnihilatingZero.identity
d_identity_2386 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_2386 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_746
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
            (coe v0)))
-- _.IsSemiringWithoutAnnihilatingZero.identityʳ
d_identity'691'_2388 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_2388 = erased
-- _.IsSemiringWithoutAnnihilatingZero.identityˡ
d_identity'737'_2390 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_2390 = erased
-- _.IsSemiringWithoutAnnihilatingZero.isCommutativeMagma
d_isCommutativeMagma_2392 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_2392 ~v0 ~v1 ~v2 ~v3 v4
  = du_isCommutativeMagma_2392 v4
du_isCommutativeMagma_2392 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_2392 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
            (coe v1)))
-- _.IsSemiringWithoutAnnihilatingZero.+-isCommutativeMonoid
d_'43''45'isCommutativeMonoid_2394 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
d_'43''45'isCommutativeMonoid_2394 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
      (coe v0)
-- _.IsSemiringWithoutAnnihilatingZero.isCommutativeSemigroup
d_isCommutativeSemigroup_2396 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_isCommutativeSemigroup_2396 ~v0 ~v1 ~v2 ~v3 v4
  = du_isCommutativeSemigroup_2396 v4
du_isCommutativeSemigroup_2396 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
du_isCommutativeSemigroup_2396 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
         (coe v0))
-- _.IsSemiringWithoutAnnihilatingZero.isMagma
d_isMagma_2398 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_2398 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMagma_480
      (coe
         MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
         (coe
            MAlonzo.Code.Algebra.Structures.d_isMonoid_746
            (coe
               MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
               (coe v0))))
-- _.IsSemiringWithoutAnnihilatingZero.isMonoid
d_isMonoid_2400 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_isMonoid_2400 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMonoid_746
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
         (coe v0))
-- _.IsSemiringWithoutAnnihilatingZero.isSemigroup
d_isSemigroup_2402 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_isSemigroup_2402 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_746
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
            (coe v0)))
-- _.IsSemiringWithoutAnnihilatingZero.isUnitalMagma
d_isUnitalMagma_2404 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
d_isUnitalMagma_2404 ~v0 ~v1 ~v2 ~v3 v4 = du_isUnitalMagma_2404 v4
du_isUnitalMagma_2404 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642
du_isUnitalMagma_2404 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isUnitalMagma_730
         (coe MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v1)))
-- _.IsSemiringWithoutAnnihilatingZero.distrib
d_distrib_2406 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_distrib_2406 v0
  = coe MAlonzo.Code.Algebra.Structures.d_distrib_1516 (coe v0)
-- _.IsSemiringWithoutAnnihilatingZero.distribʳ
d_distrib'691'_2408 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'691'_2408 = erased
-- _.IsSemiringWithoutAnnihilatingZero.distribˡ
d_distrib'737'_2410 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'737'_2410 = erased
-- _.IsSemiringWithoutAnnihilatingZero.isEquivalence
d_isEquivalence_2412 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_2412 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe
               MAlonzo.Code.Algebra.Structures.d_isMonoid_746
               (coe
                  MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
                  (coe v0)))))
-- _.IsSemiringWithoutAnnihilatingZero.isPartialEquivalence
d_isPartialEquivalence_2414 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_2414 ~v0 ~v1 ~v2 ~v3 v4
  = du_isPartialEquivalence_2414 v4
du_isPartialEquivalence_2414 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_2414 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v2) in
          coe
            (let v4 = MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v3) in
             coe
               (coe
                  MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v4))))))
-- _.IsSemiringWithoutAnnihilatingZero.refl
d_refl_2416 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_2416 = erased
-- _.IsSemiringWithoutAnnihilatingZero.reflexive
d_reflexive_2418 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_2418 = erased
-- _.IsSemiringWithoutAnnihilatingZero.setoid
d_setoid_2420 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_2420 ~v0 ~v1 ~v2 ~v3 v4 = du_setoid_2420 v4
du_setoid_2420 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_2420 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1508
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v2) in
          coe
            (coe
               MAlonzo.Code.Algebra.Structures.du_setoid_200
               (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v3)))))
-- _.IsSemiringWithoutAnnihilatingZero.sym
d_sym_2422 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_2422 = erased
-- _.IsSemiringWithoutAnnihilatingZero.trans
d_trans_2424 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutAnnihilatingZero_1488 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_2424 = erased
-- _.IsSemiringWithoutOne.*-assoc
d_'42''45'assoc_2428 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'assoc_2428 = erased
-- _.IsSemiringWithoutOne.*-cong
d_'42''45'cong_2430 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'42''45'cong_2430 = erased
-- _.IsSemiringWithoutOne.∙-congʳ
d_'8729''45'cong'691'_2432 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_2432 = erased
-- _.IsSemiringWithoutOne.∙-congˡ
d_'8729''45'cong'737'_2434 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_2434 = erased
-- _.IsSemiringWithoutOne.*-isMagma
d_'42''45'isMagma_2436 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_'42''45'isMagma_2436 v0 v1 v2 v3
  = coe MAlonzo.Code.Algebra.Structures.du_'42''45'isMagma_1366 v3
-- _.IsSemiringWithoutOne.*-isSemigroup
d_'42''45'isSemigroup_2438 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemigroup_472
d_'42''45'isSemigroup_2438 v0 v1 v2 v3
  = coe
      MAlonzo.Code.Algebra.Structures.du_'42''45'isSemigroup_1368 v3
-- _.IsSemiringWithoutOne.assoc
d_assoc_2440 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_assoc_2440 = erased
-- _.IsSemiringWithoutOne.comm
d_comm_2442 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_comm_2442 = erased
-- _.IsSemiringWithoutOne.∙-cong
d_'8729''45'cong_2444 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_2444 = erased
-- _.IsSemiringWithoutOne.∙-congʳ
d_'8729''45'cong'691'_2446 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_2446 = erased
-- _.IsSemiringWithoutOne.∙-congˡ
d_'8729''45'cong'737'_2448 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_2448 = erased
-- _.IsSemiringWithoutOne.identity
d_identity_2450 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_2450 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_identity_698
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMonoid_746
         (coe
            MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1316
            (coe v0)))
-- _.IsSemiringWithoutOne.identityʳ
d_identity'691'_2452 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_2452 = erased
-- _.IsSemiringWithoutOne.identityˡ
d_identity'737'_2454 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_2454 = erased
-- _.IsSemiringWithoutOne.isCommutativeMagma
d_isCommutativeMagma_2456 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
d_isCommutativeMagma_2456 ~v0 ~v1 ~v2 v3
  = du_isCommutativeMagma_2456 v3
du_isCommutativeMagma_2456 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMagma_212
du_isCommutativeMagma_2456 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1316
              (coe v0) in
    coe
      (coe
         MAlonzo.Code.Algebra.Structures.du_isCommutativeMagma_586
         (coe
            MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
            (coe v1)))
-- _.IsSemiringWithoutOne.+-isCommutativeMonoid
d_'43''45'isCommutativeMonoid_2458 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeMonoid_736
d_'43''45'isCommutativeMonoid_2458 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1316
      (coe v0)
-- _.IsSemiringWithoutOne.isCommutativeSemigroup
d_isCommutativeSemigroup_2460 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
d_isCommutativeSemigroup_2460 ~v0 ~v1 ~v2 v3
  = du_isCommutativeSemigroup_2460 v3
du_isCommutativeSemigroup_2460 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeSemigroup_548
du_isCommutativeSemigroup_2460 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_isCommutativeSemigroup_786
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1316
         (coe v0))
-- _.IsSemiringWithoutOne.isMonoid
d_isMonoid_2462 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Algebra.Structures.T_IsMonoid_686
d_isMonoid_2462 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isMonoid_746
      (coe
         MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1316
         (coe v0))
-- _.IsSemiringWithoutOne.distrib
d_distrib_2464 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_distrib_2464 v0
  = coe MAlonzo.Code.Algebra.Structures.d_distrib_1322 (coe v0)
-- _.IsSemiringWithoutOne.distribʳ
d_distrib'691'_2466 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'691'_2466 = erased
-- _.IsSemiringWithoutOne.distribˡ
d_distrib'737'_2468 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_distrib'737'_2468 = erased
-- _.IsSemiringWithoutOne.isEquivalence
d_isEquivalence_2470 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_2470 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe
         MAlonzo.Code.Algebra.Structures.d_isMagma_480
         (coe
            MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
            (coe
               MAlonzo.Code.Algebra.Structures.d_isMonoid_746
               (coe
                  MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1316
                  (coe v0)))))
-- _.IsSemiringWithoutOne.isNearSemiring
d_isNearSemiring_2472 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Algebra.Structures.T_IsNearSemiring_1218
d_isNearSemiring_2472 v0 v1 v2 v3
  = coe MAlonzo.Code.Algebra.Structures.du_isNearSemiring_1384 v3
-- _.IsSemiringWithoutOne.isPartialEquivalence
d_isPartialEquivalence_2474 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_2474 ~v0 ~v1 ~v2 v3
  = du_isPartialEquivalence_2474 v3
du_isPartialEquivalence_2474 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_2474 v0
  = coe
      MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
      (coe
         MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
         (coe
            MAlonzo.Code.Algebra.Structures.d_isMagma_480
            (coe
               MAlonzo.Code.Algebra.Structures.d_isSemigroup_696
               (coe
                  MAlonzo.Code.Algebra.Structures.d_isMonoid_746
                  (coe
                     MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1316
                     (coe v0))))))
-- _.IsSemiringWithoutOne.refl
d_refl_2476 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_2476 = erased
-- _.IsSemiringWithoutOne.reflexive
d_reflexive_2478 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_2478 = erased
-- _.IsSemiringWithoutOne.setoid
d_setoid_2480 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_2480 ~v0 ~v1 ~v2 v3 = du_setoid_2480 v3
du_setoid_2480 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_2480 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_'43''45'isCommutativeMonoid_1316
              (coe v0) in
    coe
      (let v2
             = MAlonzo.Code.Algebra.Structures.d_isMonoid_746 (coe v1) in
       coe
         (let v3
                = MAlonzo.Code.Algebra.Structures.d_isSemigroup_696 (coe v2) in
          coe
            (coe
               MAlonzo.Code.Algebra.Structures.du_setoid_200
               (coe MAlonzo.Code.Algebra.Structures.d_isMagma_480 (coe v3)))))
-- _.IsSemiringWithoutOne.sym
d_sym_2482 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_2482 = erased
-- _.IsSemiringWithoutOne.trans
d_trans_2484 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_2484 = erased
-- _.IsSemiringWithoutOne.zero
d_zero_2486 ::
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_zero_2486 v0
  = coe MAlonzo.Code.Algebra.Structures.d_zero_1324 (coe v0)
-- _.IsSemiringWithoutOne.zeroʳ
d_zero'691'_2488 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'691'_2488 = erased
-- _.IsSemiringWithoutOne.zeroˡ
d_zero'737'_2490 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSemiringWithoutOne_1298 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_zero'737'_2490 = erased
-- _.IsSuccessorSet.isEquivalence
d_isEquivalence_2494 ::
  MAlonzo.Code.Algebra.Structures.T_IsSuccessorSet_146 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_2494 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isEquivalence_156 (coe v0)
-- _.IsSuccessorSet.isPartialEquivalence
d_isPartialEquivalence_2496 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSuccessorSet_146 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_2496 ~v0 ~v1 v2
  = du_isPartialEquivalence_2496 v2
du_isPartialEquivalence_2496 ::
  MAlonzo.Code.Algebra.Structures.T_IsSuccessorSet_146 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_2496 v0
  = coe
      MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
      (coe MAlonzo.Code.Algebra.Structures.d_isEquivalence_156 (coe v0))
-- _.IsSuccessorSet.refl
d_refl_2498 ::
  MAlonzo.Code.Algebra.Structures.T_IsSuccessorSet_146 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_2498 = erased
-- _.IsSuccessorSet.reflexive
d_reflexive_2500 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSuccessorSet_146 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_2500 = erased
-- _.IsSuccessorSet.setoid
d_setoid_2502 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsSuccessorSet_146 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_2502 v0 v1 v2
  = coe MAlonzo.Code.Algebra.Structures.du_setoid_172 v2
-- _.IsSuccessorSet.suc#-cong
d_suc'35''45'cong_2504 ::
  MAlonzo.Code.Algebra.Structures.T_IsSuccessorSet_146 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_suc'35''45'cong_2504 = erased
-- _.IsSuccessorSet.sym
d_sym_2506 ::
  MAlonzo.Code.Algebra.Structures.T_IsSuccessorSet_146 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_2506 = erased
-- _.IsSuccessorSet.trans
d_trans_2508 ::
  MAlonzo.Code.Algebra.Structures.T_IsSuccessorSet_146 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_2508 = erased
-- _.IsUnitalMagma.identity
d_identity_2512 ::
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642 ->
  MAlonzo.Code.Agda.Builtin.Sigma.T_Σ_14
d_identity_2512 v0
  = coe MAlonzo.Code.Algebra.Structures.d_identity_654 (coe v0)
-- _.IsUnitalMagma.identityʳ
d_identity'691'_2514 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'691'_2514 = erased
-- _.IsUnitalMagma.identityˡ
d_identity'737'_2516 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_identity'737'_2516 = erased
-- _.IsUnitalMagma.isEquivalence
d_isEquivalence_2518 ::
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsEquivalence_26
d_isEquivalence_2518 v0
  = coe
      MAlonzo.Code.Algebra.Structures.d_isEquivalence_184
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_652 (coe v0))
-- _.IsUnitalMagma.isMagma
d_isMagma_2520 ::
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642 ->
  MAlonzo.Code.Algebra.Structures.T_IsMagma_176
d_isMagma_2520 v0
  = coe MAlonzo.Code.Algebra.Structures.d_isMagma_652 (coe v0)
-- _.IsUnitalMagma.isPartialEquivalence
d_isPartialEquivalence_2522 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
d_isPartialEquivalence_2522 ~v0 ~v1 v2
  = du_isPartialEquivalence_2522 v2
du_isPartialEquivalence_2522 ::
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642 ->
  MAlonzo.Code.Relation.Binary.Structures.T_IsPartialEquivalence_16
du_isPartialEquivalence_2522 v0
  = let v1
          = MAlonzo.Code.Algebra.Structures.d_isMagma_652 (coe v0) in
    coe
      (coe
         MAlonzo.Code.Relation.Binary.Structures.du_isPartialEquivalence_42
         (coe MAlonzo.Code.Algebra.Structures.d_isEquivalence_184 (coe v1)))
-- _.IsUnitalMagma.refl
d_refl_2524 ::
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_refl_2524 = erased
-- _.IsUnitalMagma.reflexive
d_reflexive_2526 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_reflexive_2526 = erased
-- _.IsUnitalMagma.setoid
d_setoid_2528 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
d_setoid_2528 ~v0 ~v1 v2 = du_setoid_2528 v2
du_setoid_2528 ::
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642 ->
  MAlonzo.Code.Relation.Binary.Bundles.T_Setoid_44
du_setoid_2528 v0
  = coe
      MAlonzo.Code.Algebra.Structures.du_setoid_200
      (coe MAlonzo.Code.Algebra.Structures.d_isMagma_652 (coe v0))
-- _.IsUnitalMagma.sym
d_sym_2530 ::
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_sym_2530 = erased
-- _.IsUnitalMagma.trans
d_trans_2532 ::
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_trans_2532 = erased
-- _.IsUnitalMagma.∙-cong
d_'8729''45'cong_2534 ::
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong_2534 = erased
-- _.IsUnitalMagma.∙-congʳ
d_'8729''45'cong'691'_2536 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'691'_2536 = erased
-- _.IsUnitalMagma.∙-congˡ
d_'8729''45'cong'737'_2538 ::
  (MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
   MAlonzo.Code.Agda.Builtin.Float.T_Float_6) ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Algebra.Structures.T_IsUnitalMagma_642 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12 ->
  MAlonzo.Code.Agda.Builtin.Equality.T__'8801'__12
d_'8729''45'cong'737'_2538 = erased
-- Implementations.Real.+-*-isCommutativeRing
d_'43''45''42''45'isCommutativeRing_2540
  = error
      "MAlonzo Runtime Error: postulate evaluated: Implementations.Real.+-*-isCommutativeRing"
-- Implementations.Real.Base.realImplementation
d_realImplementation_2544 :: MAlonzo.Code.Real.T_Real_2
d_realImplementation_2544
  = coe
      MAlonzo.Code.Real.C_Real'46'constructor_37887
      MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
      (coe
         MAlonzo.Code.Agda.Builtin.Float.d_primFloatACos_74
         (coe
            MAlonzo.Code.Agda.Builtin.Float.d_primFloatNegate_58
            (coe
               MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
               (1 :: Integer))))
      MAlonzo.Code.Agda.Builtin.Float.d_primFloatPlus_48
      MAlonzo.Code.Agda.Builtin.Float.d_primFloatMinus_50
      MAlonzo.Code.Agda.Builtin.Float.d_primFloatTimes_52
      MAlonzo.Code.Agda.Builtin.Float.d_primFloatDiv_54
      MAlonzo.Code.Agda.Builtin.Float.d_primFloatNegate_58
      MAlonzo.Code.Agda.Builtin.Float.d_primFloatCos_68
      MAlonzo.Code.Agda.Builtin.Float.d_primFloatSin_66
      d_'43''45''42''45'isCommutativeRing_2540
-- Implementations.Real._._*_
d__'42'__2548 ::
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d__'42'__2548
  = coe MAlonzo.Code.Agda.Builtin.Float.d_primFloatTimes_52
-- Implementations.Real._._+_
d__'43'__2550 ::
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d__'43'__2550
  = coe MAlonzo.Code.Agda.Builtin.Float.d_primFloatPlus_48
-- Implementations.Real._._-_
d__'45'__2552 ::
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d__'45'__2552
  = coe MAlonzo.Code.Agda.Builtin.Float.d_primFloatMinus_50
-- Implementations.Real._._/_
d__'47'__2554 ::
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d__'47'__2554
  = coe MAlonzo.Code.Agda.Builtin.Float.d_primFloatDiv_54
-- Implementations.Real._._ᵣ
d__'7523'_2556 ::
  Integer -> MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d__'7523'_2556
  = coe MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
-- Implementations.Real._.+-*-isCommutativeRing
d_'43''45''42''45'isCommutativeRing_2558 ::
  MAlonzo.Code.Algebra.Structures.T_IsCommutativeRing_2818
d_'43''45''42''45'isCommutativeRing_2558
  = coe d_'43''45''42''45'isCommutativeRing_2540
-- Implementations.Real._.-_
d_'45'__2560 ::
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d_'45'__2560
  = coe MAlonzo.Code.Agda.Builtin.Float.d_primFloatNegate_58
-- Implementations.Real._.-1ℝ
d_'45'1ℝ_2562 :: MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d_'45'1ℝ_2562
  = coe
      MAlonzo.Code.Real.d_'45'1ℝ_2720 (coe d_realImplementation_2544)
-- Implementations.Real._.0ℝ
d_0ℝ_2564 :: MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d_0ℝ_2564
  = coe MAlonzo.Code.Real.d_0ℝ_2718 (coe d_realImplementation_2544)
-- Implementations.Real._.1ℝ
d_1ℝ_2566 :: MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d_1ℝ_2566
  = coe MAlonzo.Code.Real.d_1ℝ_2722 (coe d_realImplementation_2544)
-- Implementations.Real._.cos
d_cos_2568 ::
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d_cos_2568 = coe MAlonzo.Code.Agda.Builtin.Float.d_primFloatCos_68
-- Implementations.Real._.sin
d_sin_2570 ::
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d_sin_2570 = coe MAlonzo.Code.Agda.Builtin.Float.d_primFloatSin_66
-- Implementations.Real._.π
d_π_2572 :: MAlonzo.Code.Agda.Builtin.Float.T_Float_6
d_π_2572
  = coe
      MAlonzo.Code.Agda.Builtin.Float.d_primFloatACos_74
      (coe
         MAlonzo.Code.Agda.Builtin.Float.d_primFloatNegate_58
         (coe
            MAlonzo.Code.Agda.Builtin.Float.d_primNatToFloat_24
            (1 :: Integer)))
-- Implementations.Real._.ℝ
d_ℝ_2574 :: ()
d_ℝ_2574 = erased
-- Implementations.Real.showℝ
d_showℝ_2576 ::
  MAlonzo.Code.Agda.Builtin.Float.T_Float_6 ->
  MAlonzo.Code.Agda.Builtin.String.T_String_6
d_showℝ_2576
  = coe MAlonzo.Code.Agda.Builtin.Float.d_primShowFloat_46
